/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'blance_leg/blance_leg_model/Solver Configuration1'.
 */

#ifdef __cplusplus

extern "C"
{

#endif

#ifndef SSC_ML_FUN_H
#define SSC_ML_FUN_H                   1
#endif

#ifdef __cplusplus

}

;

#endif
