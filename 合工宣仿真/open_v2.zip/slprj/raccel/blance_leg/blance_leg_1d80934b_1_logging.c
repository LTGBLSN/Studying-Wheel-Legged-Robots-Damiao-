/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'blance_leg/blance_leg_model/Solver Configuration1'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"
#include "blance_leg_1d80934b_1_geometries.h"

PmfMessageId blance_leg_1d80934b_1_recordLog(const RuntimeDerivedValuesBundle
  *rtdv, const int *eqnEnableFlags, const double *state, const int *modeVector,
  const double *input, const double *inputDot, const double *inputDdot, double
  *logVector, double *errorResult, NeuDiagnosticManager *neDiagMgr)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  boolean_T bb[1];
  int ii[4];
  double xx[737];
  (void) rtdvd;
  (void) rtdvi;
  (void) eqnEnableFlags;
  (void) modeVector;
  (void) inputDot;
  (void) inputDdot;
  (void) neDiagMgr;
  xx[0] = 57.29577951308232;
  xx[1] = 0.7071067811865476;
  xx[2] = 0.5;
  xx[3] = xx[2] * state[6];
  xx[4] = xx[1] * cos(xx[3]);
  xx[5] = xx[4] * xx[4];
  xx[6] = xx[1] * sin(xx[3]);
  xx[3] = xx[6] * xx[6];
  xx[7] = 2.0;
  xx[8] = 1.0;
  xx[9] = (xx[5] + xx[3]) * xx[7] - xx[8];
  xx[10] = xx[4] * xx[6];
  xx[11] = xx[9];
  xx[12] = - ((xx[10] + xx[10]) * xx[7]);
  xx[13] = xx[7] * (xx[3] - xx[5]);
  xx[14] = xx[7] * (xx[10] - xx[10]);
  xx[15] = (xx[5] + xx[5]) * xx[7] - xx[8];
  xx[16] = - ((xx[10] + xx[10]) * xx[7]);
  xx[17] = (xx[3] + xx[5]) * xx[7];
  xx[18] = xx[7] * (xx[10] - xx[10]);
  xx[19] = xx[9];
  xx[3] = xx[2] * state[24];
  xx[5] = xx[1] * cos(xx[3]);
  xx[9] = xx[5] * xx[5];
  xx[10] = xx[1] * sin(xx[3]);
  xx[3] = xx[10] * xx[10];
  xx[20] = (xx[9] + xx[3]) * xx[7] - xx[8];
  xx[21] = xx[5] * xx[10];
  xx[22] = xx[7] * (xx[21] - xx[21]);
  xx[23] = (xx[3] + xx[9]) * xx[7];
  xx[24] = xx[21] + xx[21];
  xx[21] = xx[24] * xx[7];
  xx[25] = (xx[9] + xx[9]) * xx[7] - xx[8];
  xx[26] = xx[3] - xx[9];
  xx[3] = xx[7] * xx[26];
  xx[27] = xx[20];
  xx[28] = xx[22];
  xx[29] = xx[23];
  xx[30] = xx[21];
  xx[31] = xx[25];
  xx[32] = xx[22];
  xx[33] = xx[3];
  xx[34] = xx[21];
  xx[35] = xx[20];
  xx[9] = 0.135;
  xx[36] = 0.375;
  xx[37] = xx[2] * state[26];
  xx[38] = cos(xx[37]);
  xx[39] = xx[38] * xx[38];
  xx[40] = xx[7] * xx[39] - xx[8];
  xx[41] = xx[36] * xx[40];
  xx[42] = 0.09386245501799279;
  xx[43] = sin(xx[37]);
  xx[37] = xx[38] * xx[43];
  xx[44] = xx[7] * xx[37];
  xx[45] = xx[42] * xx[44];
  xx[46] = xx[41] * xx[40] + xx[45] * xx[44];
  xx[47] = xx[9] + xx[46];
  xx[48] = 0.2;
  xx[49] = 0.125;
  xx[50] = xx[49] * xx[43];
  xx[51] = xx[7] * xx[50] * xx[43];
  xx[52] = xx[48] - xx[51];
  xx[53] = xx[36] * xx[44];
  xx[54] = xx[42] * xx[40];
  xx[55] = xx[53] * xx[40] - xx[54] * xx[44];
  xx[56] = xx[38] * xx[50];
  xx[50] = xx[7] * xx[56];
  xx[57] = xx[52] * xx[55] - xx[46] * xx[50];
  xx[46] = 0.0117328068772491;
  xx[58] = (xx[39] + xx[43] * xx[43]) * xx[7] - xx[8];
  xx[39] = xx[46] * xx[44] * xx[58];
  xx[59] = xx[57] + xx[39];
  xx[60] = 0.075;
  xx[61] = xx[59] + xx[60] * xx[55];
  xx[62] = 2.5425e-4;
  xx[63] = 1.466600859656138e-3;
  xx[64] = xx[46] * xx[40] * xx[58];
  xx[65] = xx[50] * xx[39] + xx[52] * xx[64];
  xx[39] = xx[53] * xx[44] + xx[54] * xx[40];
  xx[53] = xx[41] * xx[44] - xx[45] * xx[40];
  xx[41] = xx[39] * xx[52] - xx[50] * xx[53];
  xx[45] = xx[62] + xx[63] * xx[58] * xx[58] - xx[65] - xx[65] + xx[52] * xx[41]
    - xx[57] * xx[50];
  xx[54] = xx[41] - xx[64];
  xx[41] = xx[45] + xx[54] * xx[60];
  xx[57] = xx[9] + xx[39];
  xx[39] = xx[54] + xx[57] * xx[60];
  xx[64] = xx[41] + xx[39] * xx[60];
  ii[0] = factorSymmetricPosDef(xx + 64, 1, xx + 65);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "sm:compiler:messages:simulationErrors:DegenerateMass",
      "'blance_leg/blance_leg_model/right joint 4' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[65] = xx[61] / xx[64];
  xx[66] = xx[47] - xx[61] * xx[65];
  xx[67] = xx[39] * xx[65];
  xx[68] = xx[55] - xx[67];
  xx[69] = xx[53] - xx[67];
  xx[67] = xx[39] / xx[64];
  xx[70] = xx[57] - xx[39] * xx[67];
  xx[71] = xx[36] * xx[58] * xx[58];
  xx[58] = xx[9] + xx[71];
  xx[72] = xx[66] * xx[20] + xx[22] * xx[68];
  xx[73] = xx[21] * xx[66] + xx[25] * xx[68];
  xx[74] = xx[3] * xx[66] + xx[21] * xx[68];
  xx[75] = xx[20] * xx[69] + xx[22] * xx[70];
  xx[76] = xx[21] * xx[69] + xx[70] * xx[25];
  xx[77] = xx[3] * xx[69] + xx[21] * xx[70];
  xx[78] = xx[58] * xx[23];
  xx[79] = xx[58] * xx[22];
  xx[80] = xx[58] * xx[20];
  pm_math_Matrix3x3_compose_ra(xx + 27, xx + 72, xx + 81);
  xx[66] = xx[2] * state[18];
  xx[68] = xx[1] * cos(xx[66]);
  xx[69] = xx[68] * xx[68];
  xx[70] = xx[1] * sin(xx[66]);
  xx[66] = xx[70] * xx[70];
  xx[72] = (xx[69] + xx[66]) * xx[7] - xx[8];
  xx[73] = xx[68] * xx[70];
  xx[74] = xx[7] * (xx[73] - xx[73]);
  xx[75] = (xx[66] + xx[69]) * xx[7];
  xx[76] = xx[73] + xx[73];
  xx[73] = xx[76] * xx[7];
  xx[77] = (xx[69] + xx[69]) * xx[7] - xx[8];
  xx[78] = xx[66] - xx[69];
  xx[66] = xx[7] * xx[78];
  xx[90] = xx[72];
  xx[91] = xx[74];
  xx[92] = xx[75];
  xx[93] = xx[73];
  xx[94] = xx[77];
  xx[95] = xx[74];
  xx[96] = xx[66];
  xx[97] = xx[73];
  xx[98] = xx[72];
  xx[69] = xx[2] * state[20];
  xx[79] = cos(xx[69]);
  xx[80] = xx[79] * xx[79];
  xx[99] = xx[7] * xx[80] - xx[8];
  xx[100] = 0.465;
  xx[101] = 1.18;
  xx[102] = xx[2] * state[22];
  xx[103] = cos(xx[102]);
  xx[104] = xx[103] * xx[103];
  xx[105] = xx[7] * xx[104] - xx[8];
  xx[106] = xx[101] * xx[105];
  xx[107] = xx[106] * xx[105];
  xx[108] = sin(xx[102]);
  xx[102] = xx[7] * xx[103] * xx[108];
  xx[109] = xx[101] * xx[102];
  xx[110] = xx[109] * xx[102];
  xx[111] = xx[107] + xx[110];
  xx[112] = xx[100] + xx[111];
  xx[113] = xx[109] * xx[105];
  xx[109] = xx[106] * xx[102];
  xx[106] = xx[113] - xx[109];
  xx[114] = xx[49] * xx[106];
  xx[115] = xx[114] + xx[114];
  xx[116] = 2.42575e-3;
  xx[117] = xx[110] + xx[107];
  xx[107] = xx[117] * xx[49];
  xx[110] = xx[49] * xx[107];
  xx[118] = xx[116] + xx[110];
  xx[119] = xx[118] + xx[110];
  xx[110] = xx[100] + xx[117];
  xx[120] = xx[107] + xx[110] * xx[49];
  xx[121] = xx[119] + xx[120] * xx[49];
  ii[0] = factorSymmetricPosDef(xx + 121, 1, xx + 122);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "sm:compiler:messages:simulationErrors:DegenerateMass",
      "'blance_leg/blance_leg_model/Revolute Joint6' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[122] = xx[115] / xx[121];
  xx[123] = xx[112] - xx[115] * xx[122];
  xx[124] = sin(xx[69]);
  xx[69] = xx[79] * xx[124];
  xx[125] = xx[7] * xx[69];
  xx[126] = xx[120] * xx[122];
  xx[127] = xx[106] - xx[126];
  xx[128] = xx[123] * xx[99] - xx[125] * xx[127];
  xx[129] = xx[109] - xx[113];
  xx[109] = xx[129] - xx[126];
  xx[113] = xx[120] / xx[121];
  xx[126] = xx[110] - xx[120] * xx[113];
  xx[130] = xx[99] * xx[109] - xx[125] * xx[126];
  xx[131] = xx[99] * xx[128] - xx[125] * xx[130];
  xx[132] = xx[9] + xx[131];
  xx[133] = (xx[80] + xx[124] * xx[124]) * xx[7] - xx[8];
  xx[80] = xx[114] - xx[119] * xx[122];
  xx[134] = xx[107] - xx[119] * xx[113];
  xx[135] = xx[133] * (xx[80] * xx[99] - xx[125] * xx[134]);
  xx[136] = xx[49] * xx[124];
  xx[137] = xx[7] * xx[136] * xx[124];
  xx[138] = xx[48] - xx[137];
  xx[139] = xx[125] * xx[123] + xx[99] * xx[127];
  xx[123] = xx[125] * xx[109] + xx[126] * xx[99];
  xx[109] = xx[139] * xx[99] - xx[123] * xx[125];
  xx[126] = xx[79] * xx[136];
  xx[127] = xx[7] * xx[126];
  xx[136] = xx[138] * xx[109] - xx[127] * xx[131];
  xx[131] = xx[135] + xx[136];
  xx[140] = xx[131] + xx[60] * xx[109];
  xx[141] = xx[119] / xx[121];
  xx[142] = (xx[125] * xx[80] + xx[134] * xx[99]) * xx[133];
  xx[80] = xx[138] * xx[142] - xx[127] * xx[135];
  xx[134] = xx[139] * xx[125] + xx[123] * xx[99];
  xx[123] = xx[125] * xx[128] + xx[99] * xx[130];
  xx[128] = xx[134] * xx[138] - xx[123] * xx[127];
  xx[130] = xx[62] + (xx[118] - xx[119] * xx[141]) * xx[133] * xx[133] + xx[80]
    + xx[80] + xx[128] * xx[138] - xx[136] * xx[127];
  xx[80] = xx[142] + xx[128];
  xx[118] = xx[130] + xx[80] * xx[60];
  xx[128] = xx[9] + xx[134];
  xx[134] = xx[80] + xx[128] * xx[60];
  xx[135] = xx[118] + xx[134] * xx[60];
  ii[0] = factorSymmetricPosDef(xx + 135, 1, xx + 136);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "sm:compiler:messages:simulationErrors:DegenerateMass",
      "'blance_leg/blance_leg_model/right joint1' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[136] = xx[140] / xx[135];
  xx[139] = xx[132] - xx[140] * xx[136];
  xx[142] = xx[134] * xx[136];
  xx[143] = xx[109] - xx[142];
  xx[144] = xx[123] - xx[142];
  xx[142] = xx[134] / xx[135];
  xx[145] = xx[128] - xx[134] * xx[142];
  xx[146] = (xx[104] + xx[108] * xx[108]) * xx[7] - xx[8];
  xx[104] = xx[101] * xx[146] * xx[146];
  xx[146] = xx[100] + xx[104];
  xx[147] = xx[146] * xx[133] * xx[133];
  xx[148] = xx[9] + xx[147];
  xx[149] = xx[139] * xx[72] + xx[74] * xx[143];
  xx[150] = xx[73] * xx[139] + xx[77] * xx[143];
  xx[151] = xx[66] * xx[139] + xx[73] * xx[143];
  xx[152] = xx[144] * xx[72] + xx[74] * xx[145];
  xx[153] = xx[73] * xx[144] + xx[145] * xx[77];
  xx[154] = xx[66] * xx[144] + xx[73] * xx[145];
  xx[155] = xx[148] * xx[75];
  xx[156] = xx[148] * xx[74];
  xx[157] = xx[148] * xx[72];
  pm_math_Matrix3x3_compose_ra(xx + 90, xx + 149, xx + 158);
  xx[139] = xx[2] * state[14];
  xx[143] = xx[1] * cos(xx[139]);
  xx[144] = xx[143] * xx[143];
  xx[145] = xx[1] * sin(xx[139]);
  xx[139] = xx[145] * xx[145];
  xx[149] = (xx[144] + xx[139]) * xx[7] - xx[8];
  xx[150] = xx[143] * xx[145];
  xx[151] = xx[7] * (xx[150] - xx[150]);
  xx[152] = (xx[139] + xx[144]) * xx[7];
  xx[153] = xx[150] + xx[150];
  xx[150] = xx[153] * xx[7];
  xx[154] = (xx[144] + xx[144]) * xx[7] - xx[8];
  xx[155] = xx[139] - xx[144];
  xx[139] = xx[7] * xx[155];
  xx[167] = xx[149];
  xx[168] = xx[151];
  xx[169] = xx[152];
  xx[170] = xx[150];
  xx[171] = xx[154];
  xx[172] = xx[151];
  xx[173] = xx[139];
  xx[174] = xx[150];
  xx[175] = xx[149];
  xx[144] = xx[2] * state[16];
  xx[156] = cos(xx[144]);
  xx[157] = xx[156] * xx[156];
  xx[176] = xx[7] * xx[157] - xx[8];
  xx[177] = xx[36] * xx[176];
  xx[178] = sin(xx[144]);
  xx[144] = xx[156] * xx[178];
  xx[179] = xx[7] * xx[144];
  xx[180] = xx[42] * xx[179];
  xx[181] = xx[177] * xx[176] + xx[180] * xx[179];
  xx[182] = xx[9] + xx[181];
  xx[183] = xx[49] * xx[178];
  xx[184] = xx[7] * xx[183] * xx[178];
  xx[185] = xx[48] - xx[184];
  xx[186] = xx[36] * xx[179];
  xx[187] = xx[42] * xx[176];
  xx[42] = xx[186] * xx[176] - xx[187] * xx[179];
  xx[188] = xx[156] * xx[183];
  xx[183] = xx[7] * xx[188];
  xx[189] = xx[185] * xx[42] - xx[181] * xx[183];
  xx[181] = (xx[157] + xx[178] * xx[178]) * xx[7] - xx[8];
  xx[157] = xx[46] * xx[179] * xx[181];
  xx[190] = xx[189] + xx[157];
  xx[191] = xx[190] + xx[60] * xx[42];
  xx[192] = xx[46] * xx[176] * xx[181];
  xx[46] = xx[183] * xx[157] + xx[185] * xx[192];
  xx[157] = xx[186] * xx[179] + xx[187] * xx[176];
  xx[186] = xx[177] * xx[179] - xx[180] * xx[176];
  xx[177] = xx[157] * xx[185] - xx[183] * xx[186];
  xx[180] = xx[62] + xx[63] * xx[181] * xx[181] - xx[46] - xx[46] + xx[185] *
    xx[177] - xx[189] * xx[183];
  xx[46] = xx[177] - xx[192];
  xx[63] = xx[180] + xx[46] * xx[60];
  xx[177] = xx[9] + xx[157];
  xx[157] = xx[46] + xx[177] * xx[60];
  xx[187] = xx[63] + xx[157] * xx[60];
  ii[0] = factorSymmetricPosDef(xx + 187, 1, xx + 189);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "sm:compiler:messages:simulationErrors:DegenerateMass",
      "'blance_leg/blance_leg_model/left joint 4 ' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[189] = xx[191] / xx[187];
  xx[192] = xx[182] - xx[191] * xx[189];
  xx[193] = xx[157] * xx[189];
  xx[194] = xx[42] - xx[193];
  xx[195] = xx[186] - xx[193];
  xx[193] = xx[157] / xx[187];
  xx[196] = xx[177] - xx[157] * xx[193];
  xx[197] = xx[36] * xx[181] * xx[181];
  xx[181] = xx[9] + xx[197];
  xx[198] = xx[192] * xx[149] + xx[151] * xx[194];
  xx[199] = xx[150] * xx[192] + xx[154] * xx[194];
  xx[200] = xx[139] * xx[192] + xx[150] * xx[194];
  xx[201] = xx[149] * xx[195] + xx[151] * xx[196];
  xx[202] = xx[150] * xx[195] + xx[196] * xx[154];
  xx[203] = xx[139] * xx[195] + xx[150] * xx[196];
  xx[204] = xx[181] * xx[152];
  xx[205] = xx[181] * xx[151];
  xx[206] = xx[181] * xx[149];
  pm_math_Matrix3x3_compose_ra(xx + 167, xx + 198, xx + 207);
  xx[192] = xx[2] * state[8];
  xx[194] = xx[1] * cos(xx[192]);
  xx[195] = xx[194] * xx[194];
  xx[196] = xx[1] * sin(xx[192]);
  xx[192] = xx[196] * xx[196];
  xx[198] = (xx[195] + xx[192]) * xx[7] - xx[8];
  xx[199] = xx[194] * xx[196];
  xx[200] = xx[7] * (xx[199] - xx[199]);
  xx[201] = (xx[192] + xx[195]) * xx[7];
  xx[202] = xx[199] + xx[199];
  xx[199] = xx[202] * xx[7];
  xx[203] = (xx[195] + xx[195]) * xx[7] - xx[8];
  xx[204] = xx[192] - xx[195];
  xx[192] = xx[7] * xx[204];
  xx[216] = xx[198];
  xx[217] = xx[200];
  xx[218] = xx[201];
  xx[219] = xx[199];
  xx[220] = xx[203];
  xx[221] = xx[200];
  xx[222] = xx[192];
  xx[223] = xx[199];
  xx[224] = xx[198];
  xx[195] = xx[2] * state[10];
  xx[205] = cos(xx[195]);
  xx[206] = xx[205] * xx[205];
  xx[225] = xx[7] * xx[206] - xx[8];
  xx[226] = xx[2] * state[12];
  xx[227] = cos(xx[226]);
  xx[228] = xx[227] * xx[227];
  xx[229] = xx[7] * xx[228] - xx[8];
  xx[230] = xx[101] * xx[229];
  xx[231] = xx[230] * xx[229];
  xx[232] = sin(xx[226]);
  xx[226] = xx[7] * xx[227] * xx[232];
  xx[233] = xx[101] * xx[226];
  xx[234] = xx[233] * xx[226];
  xx[235] = xx[231] + xx[234];
  xx[236] = xx[100] + xx[235];
  xx[237] = xx[233] * xx[229];
  xx[233] = xx[230] * xx[226];
  xx[230] = xx[237] - xx[233];
  xx[238] = xx[49] * xx[230];
  xx[239] = xx[238] + xx[238];
  xx[240] = xx[234] + xx[231];
  xx[231] = xx[240] * xx[49];
  xx[234] = xx[49] * xx[231];
  xx[241] = xx[116] + xx[234];
  xx[242] = xx[241] + xx[234];
  xx[234] = xx[100] + xx[240];
  xx[243] = xx[231] + xx[234] * xx[49];
  xx[244] = xx[242] + xx[243] * xx[49];
  ii[0] = factorSymmetricPosDef(xx + 244, 1, xx + 245);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "sm:compiler:messages:simulationErrors:DegenerateMass",
      "'blance_leg/blance_leg_model/Revolute Joint3' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[245] = xx[239] / xx[244];
  xx[246] = xx[236] - xx[239] * xx[245];
  xx[247] = sin(xx[195]);
  xx[195] = xx[205] * xx[247];
  xx[248] = xx[7] * xx[195];
  xx[249] = xx[243] * xx[245];
  xx[250] = xx[230] - xx[249];
  xx[251] = xx[246] * xx[225] - xx[248] * xx[250];
  xx[252] = xx[233] - xx[237];
  xx[233] = xx[252] - xx[249];
  xx[237] = xx[243] / xx[244];
  xx[249] = xx[234] - xx[243] * xx[237];
  xx[253] = xx[225] * xx[233] - xx[248] * xx[249];
  xx[254] = xx[225] * xx[251] - xx[248] * xx[253];
  xx[255] = xx[9] + xx[254];
  xx[256] = (xx[206] + xx[247] * xx[247]) * xx[7] - xx[8];
  xx[206] = xx[238] - xx[242] * xx[245];
  xx[257] = xx[231] - xx[242] * xx[237];
  xx[258] = xx[256] * (xx[206] * xx[225] - xx[248] * xx[257]);
  xx[259] = xx[49] * xx[247];
  xx[260] = xx[7] * xx[259] * xx[247];
  xx[261] = xx[48] - xx[260];
  xx[262] = xx[248] * xx[246] + xx[225] * xx[250];
  xx[246] = xx[248] * xx[233] + xx[249] * xx[225];
  xx[233] = xx[262] * xx[225] - xx[246] * xx[248];
  xx[249] = xx[205] * xx[259];
  xx[250] = xx[7] * xx[249];
  xx[259] = xx[261] * xx[233] - xx[250] * xx[254];
  xx[254] = xx[258] + xx[259];
  xx[263] = xx[254] + xx[60] * xx[233];
  xx[264] = xx[242] / xx[244];
  xx[265] = (xx[248] * xx[206] + xx[257] * xx[225]) * xx[256];
  xx[206] = xx[261] * xx[265] - xx[250] * xx[258];
  xx[257] = xx[262] * xx[248] + xx[246] * xx[225];
  xx[246] = xx[248] * xx[251] + xx[225] * xx[253];
  xx[251] = xx[257] * xx[261] - xx[246] * xx[250];
  xx[253] = xx[62] + (xx[241] - xx[242] * xx[264]) * xx[256] * xx[256] + xx[206]
    + xx[206] + xx[251] * xx[261] - xx[259] * xx[250];
  xx[206] = xx[265] + xx[251];
  xx[241] = xx[253] + xx[206] * xx[60];
  xx[251] = xx[9] + xx[257];
  xx[257] = xx[206] + xx[251] * xx[60];
  xx[258] = xx[241] + xx[257] * xx[60];
  ii[0] = factorSymmetricPosDef(xx + 258, 1, xx + 259);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "sm:compiler:messages:simulationErrors:DegenerateMass",
      "'blance_leg/blance_leg_model/left joint 1' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[259] = xx[263] / xx[258];
  xx[262] = xx[255] - xx[263] * xx[259];
  xx[265] = xx[257] * xx[259];
  xx[266] = xx[233] - xx[265];
  xx[267] = xx[246] - xx[265];
  xx[265] = xx[257] / xx[258];
  xx[268] = xx[251] - xx[257] * xx[265];
  xx[269] = (xx[228] + xx[232] * xx[232]) * xx[7] - xx[8];
  xx[228] = xx[101] * xx[269] * xx[269];
  xx[269] = xx[100] + xx[228];
  xx[100] = xx[269] * xx[256] * xx[256];
  xx[270] = xx[9] + xx[100];
  xx[271] = xx[262] * xx[198] + xx[200] * xx[266];
  xx[272] = xx[199] * xx[262] + xx[203] * xx[266];
  xx[273] = xx[192] * xx[262] + xx[199] * xx[266];
  xx[274] = xx[267] * xx[198] + xx[200] * xx[268];
  xx[275] = xx[199] * xx[267] + xx[268] * xx[203];
  xx[276] = xx[192] * xx[267] + xx[199] * xx[268];
  xx[277] = xx[270] * xx[201];
  xx[278] = xx[270] * xx[200];
  xx[279] = xx[270] * xx[198];
  pm_math_Matrix3x3_compose_ra(xx + 216, xx + 271, xx + 280);
  xx[9] = xx[50] * xx[71];
  xx[262] = xx[52] * xx[71];
  xx[71] = xx[59] - xx[41] * xx[65];
  xx[266] = xx[54] - xx[41] * xx[67];
  xx[271] = xx[23] * xx[9];
  xx[272] = xx[22] * xx[9];
  xx[273] = xx[9] * xx[20];
  xx[274] = - (xx[23] * xx[262]);
  xx[275] = - (xx[262] * xx[22]);
  xx[276] = - (xx[262] * xx[20]);
  xx[277] = xx[20] * xx[71] + xx[22] * xx[266];
  xx[278] = xx[21] * xx[71] + xx[266] * xx[25];
  xx[279] = xx[3] * xx[71] + xx[21] * xx[266];
  pm_math_Matrix3x3_compose_ra(xx + 27, xx + 271, xx + 289);
  xx[71] = 0.195;
  xx[266] = xx[60] * xx[5];
  xx[267] = xx[266] * xx[5];
  xx[268] = xx[60] * xx[10];
  xx[271] = xx[268] * xx[10];
  xx[272] = xx[268] * xx[5];
  xx[268] = (xx[272] + xx[266] * xx[10]) * xx[7];
  xx[266] = 0.05400000000000001;
  xx[273] = xx[268] - xx[266];
  xx[274] = 0.03;
  xx[275] = xx[7] * (xx[267] - xx[271]);
  xx[276] = xx[274] - xx[275];
  xx[277] = xx[71] - ((xx[267] + xx[271]) * xx[7] - xx[60]);
  xx[278] = xx[273];
  xx[279] = xx[276];
  pm_math_Matrix3x3_postCross_ra(xx + 81, xx + 277, xx + 298);
  xx[267] = 0.035;
  xx[307] = xx[267] * xx[107];
  xx[308] = xx[117] * xx[267];
  xx[117] = xx[49] * xx[308];
  xx[309] = xx[307] + xx[117];
  xx[310] = xx[267] * xx[106];
  xx[311] = xx[309] * xx[122] - xx[310];
  xx[312] = xx[309] * xx[113] - xx[308];
  xx[313] = xx[311] * xx[99] - xx[125] * xx[312];
  xx[314] = xx[111] * xx[267];
  xx[111] = xx[267] * xx[114];
  xx[315] = xx[267] * xx[129];
  xx[316] = xx[49] * xx[315];
  xx[317] = xx[111] + xx[316];
  xx[318] = xx[314] - xx[317] * xx[122];
  xx[319] = xx[315] - xx[317] * xx[113];
  xx[320] = xx[318] * xx[99] - xx[125] * xx[319];
  xx[321] = xx[99] * xx[313] - xx[125] * xx[320];
  xx[322] = xx[309] / xx[121];
  xx[323] = xx[119] * xx[322];
  xx[324] = (xx[323] - xx[307]) * xx[133];
  xx[307] = xx[317] / xx[121];
  xx[325] = xx[119] * xx[307];
  xx[326] = xx[133] * (xx[111] - xx[325]);
  xx[111] = xx[125] * xx[311] + xx[312] * xx[99];
  xx[311] = xx[125] * xx[318] + xx[319] * xx[99];
  xx[312] = xx[111] * xx[99] - xx[311] * xx[125];
  xx[318] = xx[138] * xx[312] - xx[127] * xx[321];
  xx[319] = xx[324] * xx[99] - xx[125] * xx[326] + xx[318];
  xx[327] = xx[319] + xx[60] * xx[312];
  xx[328] = xx[321] - xx[327] * xx[136];
  xx[329] = xx[312] - xx[327] * xx[142];
  xx[330] = xx[49] * xx[104];
  xx[104] = xx[330] * xx[133];
  xx[331] = xx[125] * xx[104];
  xx[332] = xx[127] * xx[147];
  xx[333] = xx[331] + xx[332];
  xx[334] = xx[125] * xx[313] + xx[99] * xx[320];
  xx[313] = xx[111] * xx[125] + xx[311] * xx[99];
  xx[111] = xx[313] * xx[138] - xx[334] * xx[127];
  xx[311] = xx[125] * xx[324] + xx[326] * xx[99] + xx[111];
  xx[320] = xx[311] + xx[313] * xx[60];
  xx[324] = xx[334] - xx[320] * xx[136];
  xx[326] = xx[313] - xx[320] * xx[142];
  xx[335] = xx[104] * xx[99];
  xx[104] = xx[138] * xx[147];
  xx[147] = xx[335] + xx[104];
  xx[336] = xx[131] - xx[118] * xx[136];
  xx[337] = xx[80] - xx[118] * xx[142];
  xx[338] = xx[72] * xx[328] + xx[74] * xx[329] + xx[75] * xx[333];
  xx[339] = xx[73] * xx[328] + xx[77] * xx[329] + xx[74] * xx[333];
  xx[340] = xx[66] * xx[328] + xx[73] * xx[329] + xx[72] * xx[333];
  xx[341] = xx[324] * xx[72] + xx[74] * xx[326] - xx[147] * xx[75];
  xx[342] = xx[73] * xx[324] + xx[326] * xx[77] - xx[147] * xx[74];
  xx[343] = xx[66] * xx[324] + xx[73] * xx[326] - xx[147] * xx[72];
  xx[344] = xx[336] * xx[72] + xx[74] * xx[337];
  xx[345] = xx[73] * xx[336] + xx[337] * xx[77];
  xx[346] = xx[66] * xx[336] + xx[73] * xx[337];
  pm_math_Matrix3x3_compose_ra(xx + 90, xx + 338, xx + 347);
  xx[72] = xx[60] * xx[68];
  xx[74] = xx[72] * xx[68];
  xx[75] = xx[60] * xx[70];
  xx[324] = xx[75] * xx[70];
  xx[326] = xx[75] * xx[68];
  xx[75] = (xx[326] + xx[72] * xx[70]) * xx[7];
  xx[72] = xx[266] + xx[75];
  xx[328] = xx[7] * (xx[74] - xx[324]);
  xx[329] = xx[274] - xx[328];
  xx[336] = xx[71] - ((xx[74] + xx[324]) * xx[7] - xx[60]);
  xx[337] = xx[72];
  xx[338] = xx[329];
  pm_math_Matrix3x3_postCross_ra(xx + 158, xx + 336, xx + 356);
  xx[74] = xx[183] * xx[197];
  xx[339] = xx[185] * xx[197];
  xx[197] = xx[190] - xx[63] * xx[189];
  xx[340] = xx[46] - xx[63] * xx[193];
  xx[365] = xx[152] * xx[74];
  xx[366] = xx[151] * xx[74];
  xx[367] = xx[74] * xx[149];
  xx[368] = - (xx[152] * xx[339]);
  xx[369] = - (xx[339] * xx[151]);
  xx[370] = - (xx[339] * xx[149]);
  xx[371] = xx[149] * xx[197] + xx[151] * xx[340];
  xx[372] = xx[150] * xx[197] + xx[340] * xx[154];
  xx[373] = xx[139] * xx[197] + xx[150] * xx[340];
  pm_math_Matrix3x3_compose_ra(xx + 167, xx + 365, xx + 374);
  xx[197] = xx[60] * xx[143];
  xx[340] = xx[197] * xx[143];
  xx[341] = xx[60] * xx[145];
  xx[342] = xx[341] * xx[145];
  xx[343] = xx[341] * xx[143];
  xx[341] = (xx[343] + xx[197] * xx[145]) * xx[7];
  xx[197] = xx[341] - xx[266];
  xx[344] = xx[7] * (xx[340] - xx[342]);
  xx[345] = xx[274] - xx[344];
  xx[365] = - (xx[71] + (xx[340] + xx[342]) * xx[7] - xx[60]);
  xx[366] = xx[197];
  xx[367] = xx[345];
  pm_math_Matrix3x3_postCross_ra(xx + 207, xx + 365, xx + 383);
  xx[340] = 0.04;
  xx[346] = xx[340] * xx[230];
  xx[368] = xx[340] * xx[231];
  xx[369] = xx[240] * xx[340];
  xx[240] = xx[49] * xx[369];
  xx[370] = xx[368] + xx[240];
  xx[371] = xx[346] - xx[370] * xx[245];
  xx[372] = xx[369] - xx[370] * xx[237];
  xx[373] = xx[371] * xx[225] - xx[248] * xx[372];
  xx[392] = xx[340] * xx[238];
  xx[393] = xx[340] * xx[252];
  xx[394] = xx[49] * xx[393];
  xx[395] = xx[392] + xx[394];
  xx[396] = xx[235] * xx[340];
  xx[235] = xx[395] * xx[245] - xx[396];
  xx[397] = xx[395] * xx[237] - xx[393];
  xx[398] = xx[225] * xx[235] - xx[248] * xx[397];
  xx[399] = xx[225] * xx[373] - xx[248] * xx[398];
  xx[400] = xx[370] / xx[244];
  xx[401] = xx[242] * xx[400];
  xx[402] = (xx[368] - xx[401]) * xx[256];
  xx[368] = xx[395] / xx[244];
  xx[403] = xx[242] * xx[368];
  xx[404] = xx[256] * (xx[403] - xx[392]);
  xx[392] = xx[248] * xx[371] + xx[372] * xx[225];
  xx[371] = xx[248] * xx[235] + xx[225] * xx[397];
  xx[235] = xx[392] * xx[225] - xx[371] * xx[248];
  xx[372] = xx[261] * xx[235] - xx[250] * xx[399];
  xx[397] = xx[402] * xx[225] - xx[248] * xx[404] + xx[372];
  xx[405] = xx[397] + xx[60] * xx[235];
  xx[406] = xx[399] - xx[405] * xx[259];
  xx[407] = xx[235] - xx[405] * xx[265];
  xx[408] = xx[49] * xx[228];
  xx[228] = xx[408] * xx[256];
  xx[409] = xx[248] * xx[228];
  xx[410] = xx[250] * xx[100];
  xx[411] = xx[409] + xx[410];
  xx[412] = xx[248] * xx[373] + xx[225] * xx[398];
  xx[373] = xx[392] * xx[248] + xx[371] * xx[225];
  xx[371] = xx[373] * xx[261] - xx[412] * xx[250];
  xx[392] = xx[248] * xx[402] + xx[404] * xx[225] + xx[371];
  xx[398] = xx[392] + xx[373] * xx[60];
  xx[402] = xx[412] - xx[398] * xx[259];
  xx[404] = xx[373] - xx[398] * xx[265];
  xx[413] = xx[228] * xx[225];
  xx[228] = xx[261] * xx[100];
  xx[100] = xx[413] + xx[228];
  xx[414] = xx[254] - xx[241] * xx[259];
  xx[415] = xx[206] - xx[241] * xx[265];
  xx[416] = xx[198] * xx[406] + xx[200] * xx[407] + xx[201] * xx[411];
  xx[417] = xx[199] * xx[406] + xx[203] * xx[407] + xx[200] * xx[411];
  xx[418] = xx[192] * xx[406] + xx[199] * xx[407] + xx[198] * xx[411];
  xx[419] = xx[402] * xx[198] + xx[200] * xx[404] - xx[100] * xx[201];
  xx[420] = xx[199] * xx[402] + xx[404] * xx[203] - xx[100] * xx[200];
  xx[421] = xx[192] * xx[402] + xx[199] * xx[404] - xx[100] * xx[198];
  xx[422] = xx[414] * xx[198] + xx[200] * xx[415];
  xx[423] = xx[199] * xx[414] + xx[415] * xx[203];
  xx[424] = xx[192] * xx[414] + xx[199] * xx[415];
  pm_math_Matrix3x3_compose_ra(xx + 216, xx + 416, xx + 425);
  xx[198] = xx[60] * xx[194];
  xx[200] = xx[198] * xx[194];
  xx[201] = xx[60] * xx[196];
  xx[402] = xx[201] * xx[196];
  xx[404] = xx[201] * xx[194];
  xx[201] = (xx[404] + xx[198] * xx[196]) * xx[7];
  xx[198] = xx[266] + xx[201];
  xx[266] = xx[7] * (xx[200] - xx[402]);
  xx[406] = xx[274] - xx[266];
  xx[414] = - (xx[71] + (xx[200] + xx[402]) * xx[7] - xx[60]);
  xx[415] = xx[198];
  xx[416] = xx[406];
  pm_math_Matrix3x3_postCross_ra(xx + 280, xx + 414, xx + 434);
  xx[71] = xx[289] - xx[298] + xx[347] - xx[356] + xx[374] - xx[383] + xx[425] -
    xx[434];
  xx[200] = xx[82] + xx[159] + xx[208] + xx[281];
  xx[82] = 0.03000000000000001;
  xx[159] = xx[71] + xx[200] * xx[82];
  xx[208] = 8.156250000000017e-6;
  xx[281] = 2.265625000000013e-5;
  xx[407] = xx[281] * xx[40];
  xx[417] = 1.97265625e-3;
  xx[418] = xx[417] * xx[44];
  xx[419] = xx[208] + xx[407] * xx[40] + xx[418] * xx[44] + xx[50] * xx[9];
  xx[420] = xx[281] * xx[44];
  xx[421] = xx[417] * xx[40];
  xx[422] = xx[420] * xx[40] - xx[421] * xx[44] - xx[262] * xx[50];
  xx[423] = xx[407] * xx[44] - xx[418] * xx[40] - xx[52] * xx[9];
  xx[407] = 2.6015625e-4;
  xx[418] = xx[407] + xx[420] * xx[44] + xx[421] * xx[40] + xx[52] * xx[262];
  xx[420] = xx[41] / xx[64];
  xx[421] = xx[45] - xx[41] * xx[420];
  xx[443] = xx[419] * xx[20] + xx[422] * xx[22];
  xx[444] = xx[419] * xx[21] + xx[422] * xx[25];
  xx[445] = xx[419] * xx[3] + xx[422] * xx[21];
  xx[446] = xx[423] * xx[20] + xx[418] * xx[22];
  xx[447] = xx[423] * xx[21] + xx[418] * xx[25];
  xx[448] = xx[423] * xx[3] + xx[418] * xx[21];
  xx[449] = xx[23] * xx[421];
  xx[450] = xx[22] * xx[421];
  xx[451] = xx[421] * xx[20];
  pm_math_Matrix3x3_compose_ra(xx + 27, xx + 443, xx + 452);
  pm_math_Matrix3x3_postCross_ra(xx + 289, xx + 277, xx + 27);
  pm_math_Matrix3x3_preCross_ra(xx + 298, xx + 277, xx + 443);
  xx[20] = 2.809375000000016e-5;
  xx[22] = 2.339153333333333e-3;
  xx[23] = xx[22] * xx[105];
  xx[45] = xx[23] * xx[105];
  xx[289] = xx[22] * xx[102];
  xx[298] = xx[289] * xx[102];
  xx[421] = xx[20] + xx[45] + xx[298] + xx[267] * xx[308];
  xx[424] = xx[421] - xx[309] * xx[322];
  xx[461] = xx[289] * xx[105];
  xx[105] = xx[23] * xx[102];
  xx[23] = xx[461] - xx[105] - xx[267] * xx[315];
  xx[102] = xx[317] * xx[322];
  xx[289] = xx[23] + xx[102];
  xx[462] = xx[424] * xx[99] - xx[289] * xx[125];
  xx[463] = xx[105] - xx[461] - xx[267] * xx[310];
  xx[105] = xx[463] + xx[102];
  xx[102] = 2.44609375e-3;
  xx[461] = xx[102] + xx[298] + xx[45] + xx[267] * xx[314] + xx[49] * xx[330];
  xx[45] = xx[461] - xx[317] * xx[307];
  xx[298] = xx[105] * xx[99] - xx[125] * xx[45];
  xx[464] = xx[127] * xx[331];
  xx[465] = xx[208] + xx[99] * xx[462] - xx[125] * xx[298] + xx[464] + xx[464] +
    xx[127] * xx[332];
  xx[464] = xx[327] / xx[135];
  xx[466] = xx[125] * xx[424] + xx[289] * xx[99];
  xx[289] = xx[105] * xx[125] + xx[45] * xx[99];
  xx[45] = xx[138] * xx[331];
  xx[105] = xx[127] * xx[335];
  xx[331] = xx[466] * xx[99] - xx[289] * xx[125] - xx[45] - xx[105] - xx[104] *
    xx[127];
  xx[424] = xx[320] * xx[464];
  xx[467] = xx[118] * xx[464];
  xx[468] = xx[125] * xx[462] + xx[298] * xx[99] - xx[105] - xx[45] - xx[138] *
    xx[332];
  xx[45] = xx[138] * xx[335];
  xx[105] = xx[407] + xx[466] * xx[125] + xx[289] * xx[99] + xx[45] + xx[45] +
    xx[138] * xx[104];
  xx[45] = xx[320] / xx[135];
  xx[104] = xx[118] * xx[45];
  xx[289] = xx[323] - xx[117];
  xx[298] = xx[316] - xx[325];
  xx[323] = xx[133] * (xx[289] * xx[99] - xx[125] * xx[298]) + xx[318];
  xx[318] = (xx[125] * xx[289] + xx[298] * xx[99]) * xx[133] + xx[111];
  xx[111] = xx[118] / xx[135];
  xx[469] = xx[465] - xx[327] * xx[464];
  xx[470] = xx[331] - xx[424];
  xx[471] = xx[319] - xx[467];
  xx[472] = xx[468] - xx[424];
  xx[473] = xx[105] - xx[320] * xx[45];
  xx[474] = xx[311] - xx[104];
  xx[475] = xx[323] - xx[467];
  xx[476] = xx[318] - xx[104];
  xx[477] = xx[130] - xx[118] * xx[111];
  pm_math_Matrix3x3_composeTranspose_ra(xx + 469, xx + 90, xx + 478);
  pm_math_Matrix3x3_compose_ra(xx + 90, xx + 478, xx + 469);
  pm_math_Matrix3x3_postCross_ra(xx + 347, xx + 336, xx + 90);
  pm_math_Matrix3x3_preCross_ra(xx + 356, xx + 336, xx + 478);
  xx[104] = xx[281] * xx[176];
  xx[130] = xx[417] * xx[179];
  xx[133] = xx[208] + xx[104] * xx[176] + xx[130] * xx[179] + xx[183] * xx[74];
  xx[289] = xx[281] * xx[179];
  xx[298] = xx[417] * xx[176];
  xx[311] = xx[289] * xx[176] - xx[298] * xx[179] - xx[339] * xx[183];
  xx[319] = xx[104] * xx[179] - xx[130] * xx[176] - xx[185] * xx[74];
  xx[104] = xx[407] + xx[289] * xx[179] + xx[298] * xx[176] + xx[185] * xx[339];
  xx[130] = xx[63] / xx[187];
  xx[289] = xx[180] - xx[63] * xx[130];
  xx[487] = xx[133] * xx[149] + xx[311] * xx[151];
  xx[488] = xx[133] * xx[150] + xx[311] * xx[154];
  xx[489] = xx[133] * xx[139] + xx[311] * xx[150];
  xx[490] = xx[319] * xx[149] + xx[104] * xx[151];
  xx[491] = xx[319] * xx[150] + xx[104] * xx[154];
  xx[492] = xx[319] * xx[139] + xx[104] * xx[150];
  xx[493] = xx[152] * xx[289];
  xx[494] = xx[151] * xx[289];
  xx[495] = xx[289] * xx[149];
  pm_math_Matrix3x3_compose_ra(xx + 167, xx + 487, xx + 496);
  pm_math_Matrix3x3_postCross_ra(xx + 374, xx + 365, xx + 167);
  pm_math_Matrix3x3_preCross_ra(xx + 383, xx + 365, xx + 487);
  xx[149] = xx[22] * xx[229];
  xx[151] = xx[149] * xx[229];
  xx[152] = xx[22] * xx[226];
  xx[180] = xx[152] * xx[226];
  xx[289] = xx[20] + xx[151] + xx[180] + xx[340] * xx[369];
  xx[298] = xx[289] - xx[370] * xx[400];
  xx[325] = xx[152] * xx[229];
  xx[152] = xx[149] * xx[226];
  xx[149] = xx[325] - xx[152] - xx[340] * xx[393];
  xx[226] = xx[395] * xx[400];
  xx[229] = xx[149] + xx[226];
  xx[332] = xx[298] * xx[225] - xx[229] * xx[248];
  xx[335] = xx[152] - xx[325] - xx[340] * xx[346];
  xx[152] = xx[335] + xx[226];
  xx[226] = xx[102] + xx[180] + xx[151] + xx[340] * xx[396] + xx[49] * xx[408];
  xx[151] = xx[226] - xx[395] * xx[368];
  xx[180] = xx[152] * xx[225] - xx[248] * xx[151];
  xx[325] = xx[250] * xx[409];
  xx[347] = xx[208] + xx[225] * xx[332] - xx[248] * xx[180] + xx[325] + xx[325]
    + xx[250] * xx[410];
  xx[325] = xx[405] / xx[258];
  xx[356] = xx[248] * xx[298] + xx[229] * xx[225];
  xx[229] = xx[152] * xx[248] + xx[151] * xx[225];
  xx[151] = xx[261] * xx[409];
  xx[152] = xx[250] * xx[413];
  xx[298] = xx[356] * xx[225] - xx[229] * xx[248] - xx[151] - xx[152] - xx[228] *
    xx[250];
  xx[374] = xx[398] * xx[325];
  xx[383] = xx[241] * xx[325];
  xx[409] = xx[248] * xx[332] + xx[180] * xx[225] - xx[152] - xx[151] - xx[261] *
    xx[410];
  xx[151] = xx[261] * xx[413];
  xx[152] = xx[407] + xx[356] * xx[248] + xx[229] * xx[225] + xx[151] + xx[151]
    + xx[261] * xx[228];
  xx[151] = xx[398] / xx[258];
  xx[180] = xx[241] * xx[151];
  xx[228] = xx[240] - xx[401];
  xx[229] = xx[403] - xx[394];
  xx[332] = xx[256] * (xx[228] * xx[225] - xx[248] * xx[229]) + xx[372];
  xx[356] = (xx[248] * xx[228] + xx[225] * xx[229]) * xx[256] + xx[371];
  xx[228] = xx[241] / xx[258];
  xx[505] = xx[347] - xx[405] * xx[325];
  xx[506] = xx[298] - xx[374];
  xx[507] = xx[397] - xx[383];
  xx[508] = xx[409] - xx[374];
  xx[509] = xx[152] - xx[398] * xx[151];
  xx[510] = xx[392] - xx[180];
  xx[511] = xx[332] - xx[383];
  xx[512] = xx[356] - xx[180];
  xx[513] = xx[253] - xx[241] * xx[228];
  pm_math_Matrix3x3_composeTranspose_ra(xx + 505, xx + 216, xx + 514);
  pm_math_Matrix3x3_compose_ra(xx + 216, xx + 514, xx + 505);
  pm_math_Matrix3x3_postCross_ra(xx + 425, xx + 414, xx + 216);
  pm_math_Matrix3x3_preCross_ra(xx + 434, xx + 414, xx + 514);
  xx[180] = xx[290] - xx[301] + xx[348] - xx[359] + xx[375] - xx[386] + xx[426]
    - xx[437];
  xx[229] = xx[452] - xx[27] - xx[27] - xx[443] + xx[469] - xx[90] - xx[90] -
    xx[478] + xx[496] - xx[167] - xx[167] - xx[487] + xx[505] - xx[216] - xx[216]
    - xx[514] + xx[180] * xx[82] + 0.08961000000000001;
  xx[253] = 10.3;
  xx[256] = xx[85] + xx[162] + xx[211] + xx[284] + xx[253];
  xx[85] = xx[180] + xx[256] * xx[82];
  xx[162] = xx[229] + xx[85] * xx[82];
  ii[0] = factorSymmetricPosDef(xx + 162, 1, xx + 211);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "sm:compiler:messages:simulationErrors:DegenerateMass",
      "'blance_leg/blance_leg_model/pitch' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[211] = xx[159] / xx[162];
  xx[284] = xx[85] * xx[211];
  xx[290] = xx[83] + xx[160] + xx[209] + xx[282];
  xx[83] = xx[291] - xx[304] + xx[349] - xx[362] + xx[376] - xx[389] + xx[427] -
    xx[440];
  xx[160] = xx[88] + xx[165] + xx[214] + xx[287];
  xx[88] = xx[83] + xx[160] * xx[82];
  xx[165] = xx[88] * xx[211];
  xx[209] = xx[85] / xx[162];
  xx[214] = xx[86] + xx[163] + xx[212] + xx[285];
  xx[86] = xx[88] * xx[209];
  xx[163] = xx[89] + xx[166] + xx[215] + xx[288] + xx[253];
  xx[89] = xx[88] / xx[162];
  xx[523] = xx[81] + xx[158] + xx[207] + xx[280] - xx[159] * xx[211] + xx[253];
  xx[524] = xx[200] - xx[284];
  xx[525] = xx[290] - xx[165];
  xx[526] = xx[84] + xx[161] + xx[210] + xx[283] - xx[284];
  xx[527] = xx[256] - xx[85] * xx[209];
  xx[528] = xx[214] - xx[86];
  xx[529] = xx[87] + xx[164] + xx[213] + xx[286] - xx[165];
  xx[530] = xx[160] - xx[86];
  xx[531] = xx[163] - xx[88] * xx[89];
  pm_math_Matrix3x3_composeTranspose_ra(xx + 523, xx + 11, xx + 532);
  pm_math_Matrix3x3_compose_ra(xx + 11, xx + 532, xx + 523);
  xx[532] = xx[523];
  xx[533] = xx[524];
  xx[534] = xx[525];
  xx[535] = xx[524];
  xx[536] = xx[527];
  xx[537] = xx[528];
  xx[538] = xx[525];
  xx[539] = xx[528];
  xx[540] = xx[531];
  ii[0] = factorSymmetricPosDef(xx + 532, 3, xx + 164);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "sm:compiler:messages:simulationErrors:DegenerateMass",
      "'blance_leg/blance_leg_model/Cartesian Joint1' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[81] = - xx[6];
  xx[282] = - xx[4];
  xx[283] = xx[81];
  xx[284] = xx[4];
  xx[285] = xx[81];
  xx[424] = xx[5];
  xx[425] = xx[10];
  xx[426] = xx[5];
  xx[427] = xx[10];
  xx[81] = xx[5] * state[7];
  xx[84] = xx[10] * state[7];
  xx[86] = (xx[5] * xx[81] + xx[10] * xx[84]) * xx[7];
  xx[87] = state[7] - xx[86];
  xx[158] = xx[7] * (xx[10] * xx[81] - xx[5] * xx[84]);
  xx[81] = xx[86] + state[25];
  xx[164] = xx[87];
  xx[165] = xx[158];
  xx[166] = xx[81];
  xx[286] = - (xx[81] * xx[50]);
  xx[287] = xx[81] * xx[52];
  xx[288] = - (xx[52] * xx[158] - xx[50] * xx[87]);
  pm_math_Vector3_cross_ra(xx + 164, xx + 286, xx + 374);
  xx[84] = xx[375] * xx[43];
  xx[160] = xx[374] * xx[43];
  xx[161] = xx[81] + state[27];
  xx[200] = xx[49] * state[27];
  xx[207] = xx[36] * (xx[374] + xx[7] * (xx[38] * xx[84] - xx[160] * xx[43]) -
                      (xx[81] + xx[161]) * xx[200]);
  xx[210] = xx[36] * (xx[375] - (xx[38] * xx[160] + xx[84] * xx[43]) * xx[7]);
  xx[84] = 0.046875;
  xx[160] = xx[158] * xx[43];
  xx[212] = xx[43] * xx[87];
  xx[213] = xx[87] + xx[7] * (xx[38] * xx[160] - xx[212] * xx[43]);
  xx[215] = xx[158] - (xx[38] * xx[212] + xx[160] * xx[43]) * xx[7];
  xx[286] = xx[213];
  xx[287] = xx[215];
  xx[288] = xx[161];
  xx[160] = 1.95625e-3;
  xx[541] = xx[213] * xx[281];
  xx[542] = xx[417] * xx[215];
  xx[543] = xx[161] * xx[160];
  pm_math_Vector3_cross_ra(xx + 286, xx + 541, xx + 544);
  xx[161] = xx[546] + xx[49] * xx[210];
  xx[212] = xx[49] - xx[51];
  xx[541] = xx[10];
  xx[542] = xx[5];
  xx[543] = xx[10];
  xx[253] = xx[10] * xx[212];
  xx[256] = xx[10] * xx[50];
  xx[280] = - xx[256];
  xx[291] = xx[5] * xx[50];
  xx[301] = xx[253] + xx[291];
  xx[547] = - xx[253];
  xx[548] = xx[280];
  xx[549] = xx[301];
  pm_math_Vector3_cross_ra(xx + 541, xx + 547, xx + 550);
  xx[253] = xx[5] * xx[256];
  xx[256] = xx[5] * xx[43];
  xx[304] = xx[38] * xx[10];
  xx[348] = xx[256] + xx[304];
  xx[349] = xx[348] * xx[49];
  xx[359] = xx[304] + xx[256];
  xx[256] = xx[359] * xx[49];
  xx[304] = (xx[348] * xx[349] + xx[359] * xx[256]) * xx[7];
  xx[362] = xx[212] + xx[7] * (xx[551] - xx[253]) - xx[304] + xx[49];
  xx[371] = - xx[196];
  xx[372] = - xx[194];
  xx[547] = xx[371];
  xx[548] = xx[372];
  xx[549] = xx[371];
  xx[383] = xx[261] * xx[196];
  xx[386] = xx[196] * xx[250];
  xx[389] = xx[194] * xx[250];
  xx[392] = xx[383] + xx[389];
  xx[553] = xx[383];
  xx[554] = xx[386];
  xx[555] = - xx[392];
  pm_math_Vector3_cross_ra(xx + 547, xx + 553, xx + 556);
  xx[383] = xx[194] * xx[386];
  xx[397] = xx[194] * xx[247];
  xx[401] = xx[205] * xx[196];
  xx[403] = xx[397] + xx[401];
  xx[410] = xx[403] * xx[49];
  xx[413] = xx[401] + xx[397];
  xx[397] = xx[413] * xx[49];
  xx[401] = (xx[403] * xx[410] + xx[413] * xx[397]) * xx[7];
  xx[434] = xx[261] + (xx[557] - xx[383]) * xx[7] - (xx[402] + xx[402]) * xx[7]
    - xx[401] + xx[48];
  xx[402] = xx[49] - xx[260];
  xx[437] = xx[196] * xx[402];
  xx[440] = xx[437] + xx[389];
  xx[553] = xx[437];
  xx[554] = xx[386];
  xx[555] = - xx[440];
  pm_math_Vector3_cross_ra(xx + 547, xx + 553, xx + 559);
  xx[386] = xx[402] + xx[7] * (xx[560] - xx[383]) - xx[401] + xx[49];
  xx[383] = xx[386] / xx[244];
  xx[389] = xx[243] * xx[383];
  xx[401] = xx[239] * xx[383];
  xx[437] = xx[401] * xx[247];
  xx[462] = xx[389] * xx[247];
  xx[466] = xx[389] + xx[7] * (xx[205] * xx[437] - xx[462] * xx[247]);
  xx[389] = xx[401] - (xx[205] * xx[462] + xx[437] * xx[247]) * xx[7];
  xx[401] = xx[242] * xx[383] + xx[466] * xx[261] - xx[250] * xx[389];
  xx[437] = (xx[434] - (xx[401] + xx[466] * xx[60])) / xx[258];
  xx[553] = xx[325];
  xx[554] = xx[151];
  xx[555] = xx[228];
  xx[151] = xx[49] - xx[184];
  xx[228] = - xx[145];
  xx[325] = - xx[143];
  xx[562] = xx[228];
  xx[563] = xx[325];
  xx[564] = xx[228];
  xx[462] = xx[145] * xx[151];
  xx[467] = xx[145] * xx[183];
  xx[565] = xx[143] * xx[183];
  xx[566] = xx[462] + xx[565];
  xx[567] = xx[462];
  xx[568] = xx[467];
  xx[569] = - xx[566];
  pm_math_Vector3_cross_ra(xx + 562, xx + 567, xx + 570);
  xx[462] = xx[143] * xx[467];
  xx[567] = xx[143] * xx[178];
  xx[568] = xx[156] * xx[145];
  xx[569] = xx[567] + xx[568];
  xx[573] = xx[569] * xx[49];
  xx[574] = xx[568] + xx[567];
  xx[567] = xx[574] * xx[49];
  xx[568] = (xx[569] * xx[573] + xx[574] * xx[567]) * xx[7];
  xx[575] = xx[151] + xx[7] * (xx[571] - xx[462]) - xx[568] + xx[49];
  xx[576] = 7.815625e-3;
  xx[577] = xx[575] / xx[576];
  xx[578] = xx[84] * xx[577];
  xx[579] = xx[578] * xx[178];
  xx[580] = xx[7] * xx[579] * xx[178] - xx[578];
  xx[578] = xx[7] * xx[156] * xx[579];
  xx[579] = xx[185] * xx[580] - xx[183] * xx[578] - xx[160] * xx[577];
  xx[581] = xx[185] * xx[145];
  xx[582] = xx[581] + xx[565];
  xx[583] = xx[581];
  xx[584] = xx[467];
  xx[585] = - xx[582];
  pm_math_Vector3_cross_ra(xx + 562, xx + 583, xx + 586);
  xx[467] = xx[185] + (xx[587] - xx[462]) * xx[7] - (xx[342] + xx[342]) * xx[7]
    - xx[568] + xx[48];
  xx[342] = (xx[579] + xx[60] * xx[580] + xx[467]) / xx[187];
  xx[462] = xx[579] - xx[63] * xx[342];
  xx[565] = xx[578] - xx[191] * xx[342];
  xx[568] = xx[580] - xx[157] * xx[342];
  xx[578] = xx[145] * xx[568];
  xx[579] = xx[145] * xx[565];
  xx[580] = xx[143] * xx[565] - xx[578];
  xx[583] = xx[578];
  xx[584] = - xx[579];
  xx[585] = xx[580];
  pm_math_Vector3_cross_ra(xx + 562, xx + 583, xx + 589);
  xx[581] = xx[565] + xx[7] * (xx[589] - xx[143] * xx[578]);
  xx[565] = xx[568] + (xx[143] * xx[579] + xx[590]) * xx[7];
  xx[568] = (xx[591] - xx[143] * xx[580]) * xx[7];
  xx[578] = xx[581];
  xx[579] = xx[565];
  xx[580] = xx[568];
  pm_math_Vector3_cross_ra(xx + 365, xx + 578, xx + 583);
  xx[589] = xx[372];
  xx[590] = xx[371];
  xx[591] = xx[372];
  xx[592] = xx[371];
  xx[371] = xx[395] * xx[383];
  xx[372] = xx[371] * xx[247];
  xx[578] = xx[370] * xx[383];
  xx[579] = xx[578] * xx[247];
  xx[593] = xx[7] * (xx[205] * xx[372] - xx[579] * xx[247]) + xx[578] + xx[405] *
    xx[437];
  xx[594] = (xx[205] * xx[579] + xx[372] * xx[247]) * xx[7] - xx[371] + xx[398] *
    xx[437];
  xx[595] = xx[401] + xx[241] * xx[437];
  pm_math_Quaternion_xform_ra(xx + 589, xx + 593, xx + 578);
  xx[371] = xx[389] + xx[263] * xx[437];
  xx[372] = xx[466] + xx[257] * xx[437];
  xx[389] = xx[372] * xx[196];
  xx[401] = xx[371] * xx[196];
  xx[466] = xx[371] * xx[194] - xx[389];
  xx[593] = xx[389];
  xx[594] = - xx[401];
  xx[595] = xx[466];
  pm_math_Vector3_cross_ra(xx + 547, xx + 593, xx + 596);
  xx[579] = xx[371] + xx[7] * (xx[596] - xx[389] * xx[194]);
  xx[371] = xx[372] + (xx[401] * xx[194] + xx[597]) * xx[7];
  xx[372] = (xx[598] - xx[194] * xx[466]) * xx[7];
  xx[593] = xx[579];
  xx[594] = xx[371];
  xx[595] = xx[372];
  pm_math_Vector3_cross_ra(xx + 414, xx + 593, xx + 596);
  xx[389] = xx[565] + xx[371];
  xx[371] = ((xx[143] * xx[143] * xx[462] + xx[145] * xx[145] * xx[462]) * xx[7]
             + xx[583] + xx[578] + xx[596] + xx[389] * xx[82]) / xx[162];
  xx[583] = xx[211];
  xx[584] = xx[209];
  xx[585] = xx[89];
  xx[593] = xx[581] + xx[579] - xx[159] * xx[371];
  xx[594] = xx[389] - xx[85] * xx[371];
  xx[595] = xx[568] + xx[372] - xx[88] * xx[371];
  pm_math_Quaternion_xform_ra(xx + 282, xx + 593, xx + 578);
  xx[593] = - xx[578];
  xx[594] = - xx[579];
  xx[595] = - xx[580];
  solveSymmetricPosDef(xx + 532, xx + 593, 3, 1, xx + 578, xx + 596);
  pm_math_Quaternion_inverseXform_ra(xx + 282, xx + 578, xx + 593);
  xx[372] = xx[371] + pm_math_Vector3_dot_ra(xx + 583, xx + 593);
  xx[371] = xx[372] * xx[194];
  xx[389] = xx[372] * xx[196];
  xx[401] = (xx[371] * xx[194] + xx[389] * xx[196]) * xx[7];
  xx[462] = xx[401] - xx[372];
  xx[466] = xx[7] * (xx[389] * xx[194] - xx[371] * xx[196]);
  xx[578] = xx[462];
  xx[579] = xx[466];
  xx[580] = - xx[401];
  xx[371] = xx[594] - xx[372] * xx[82];
  xx[596] = xx[593];
  xx[597] = xx[371] + xx[372] * xx[406];
  xx[598] = xx[595] - xx[372] * xx[198];
  pm_math_Quaternion_inverseXform_ra(xx + 589, xx + 596, xx + 599);
  xx[389] = xx[437] - (pm_math_Vector3_dot_ra(xx + 553, xx + 578) + xx[259] *
                       xx[599] + xx[265] * xx[600]);
  xx[578] = xx[400];
  xx[579] = - xx[368];
  xx[580] = xx[264];
  xx[264] = xx[466] * xx[247];
  xx[368] = xx[247] * xx[462];
  xx[400] = xx[389] - xx[401];
  xx[596] = xx[462] + xx[7] * (xx[205] * xx[264] - xx[368] * xx[247]);
  xx[597] = xx[466] - (xx[205] * xx[368] + xx[264] * xx[247]) * xx[7];
  xx[598] = xx[400];
  xx[264] = xx[599] - xx[250] * xx[400];
  xx[368] = xx[600] + xx[60] * xx[389] + xx[261] * xx[400];
  xx[400] = xx[368] * xx[247];
  xx[401] = xx[264] * xx[247];
  xx[599] = xx[325];
  xx[600] = xx[228];
  xx[601] = xx[325];
  xx[602] = xx[228];
  xx[603] = xx[593];
  xx[604] = xx[371] + xx[372] * xx[345];
  xx[605] = xx[595] - xx[372] * xx[197];
  pm_math_Quaternion_inverseXform_ra(xx + 599, xx + 603, xx + 593);
  xx[228] = (xx[372] * xx[143] * xx[143] + xx[372] * xx[145] * xx[145]) * xx[7];
  xx[325] = xx[342] + xx[189] * xx[593] + xx[193] * xx[594] - xx[130] * xx[228];
  xx[342] = 5.997600959616154;
  xx[371] = xx[228] + xx[325];
  xx[228] = xx[594] - xx[325] * xx[60] - xx[371] * xx[185];
  xx[372] = 0.2502998800479808;
  xx[437] = xx[205] * xx[194] - xx[196] * xx[247];
  xx[462] = (xx[397] * xx[437] + xx[410] * xx[437]) * xx[7];
  xx[397] = (xx[194] * xx[392] + xx[558]) * xx[7] + (xx[404] + xx[404]) * xx[7]
    + xx[462];
  xx[392] = (xx[440] * xx[194] + xx[561]) * xx[7] + xx[462];
  xx[404] = xx[392] / xx[244];
  xx[410] = xx[243] * xx[404];
  xx[440] = xx[239] * xx[404];
  xx[462] = xx[440] * xx[247];
  xx[466] = xx[410] * xx[247];
  xx[556] = xx[410] + xx[7] * (xx[205] * xx[462] - xx[466] * xx[247]);
  xx[410] = xx[440] - (xx[205] * xx[466] + xx[462] * xx[247]) * xx[7];
  xx[440] = xx[242] * xx[404] + xx[556] * xx[261] - xx[250] * xx[410];
  xx[462] = (xx[397] - (xx[440] + xx[556] * xx[60])) / xx[258];
  xx[466] = xx[156] * xx[143] - xx[145] * xx[178];
  xx[557] = (xx[567] * xx[466] + xx[573] * xx[466]) * xx[7];
  xx[558] = (xx[566] * xx[143] + xx[572]) * xx[7] + xx[557];
  xx[559] = xx[558] / xx[576];
  xx[560] = xx[84] * xx[559];
  xx[561] = xx[560] * xx[178];
  xx[565] = xx[7] * xx[561] * xx[178] - xx[560];
  xx[560] = xx[7] * xx[156] * xx[561];
  xx[561] = xx[185] * xx[565] - xx[183] * xx[560] - xx[160] * xx[559];
  xx[566] = (xx[143] * xx[582] + xx[588]) * xx[7] + (xx[343] + xx[343]) * xx[7]
    + xx[557];
  xx[343] = (xx[561] + xx[60] * xx[565] + xx[566]) / xx[187];
  xx[557] = xx[561] - xx[63] * xx[343];
  xx[561] = xx[560] - xx[191] * xx[343];
  xx[560] = xx[565] - xx[157] * xx[343];
  xx[565] = xx[145] * xx[560];
  xx[567] = xx[145] * xx[561];
  xx[568] = xx[143] * xx[561] - xx[565];
  xx[570] = xx[565];
  xx[571] = - xx[567];
  xx[572] = xx[568];
  pm_math_Vector3_cross_ra(xx + 562, xx + 570, xx + 586);
  xx[570] = xx[561] + xx[7] * (xx[586] - xx[143] * xx[565]);
  xx[561] = xx[560] + (xx[143] * xx[567] + xx[587]) * xx[7];
  xx[560] = (xx[588] - xx[143] * xx[568]) * xx[7];
  xx[571] = xx[570];
  xx[572] = xx[561];
  xx[573] = xx[560];
  pm_math_Vector3_cross_ra(xx + 365, xx + 571, xx + 586);
  xx[565] = xx[395] * xx[404];
  xx[567] = xx[565] * xx[247];
  xx[568] = xx[370] * xx[404];
  xx[571] = xx[568] * xx[247];
  xx[603] = xx[7] * (xx[205] * xx[567] - xx[571] * xx[247]) + xx[568] + xx[405] *
    xx[462];
  xx[604] = (xx[205] * xx[571] + xx[567] * xx[247]) * xx[7] - xx[565] + xx[398] *
    xx[462];
  xx[605] = xx[440] + xx[241] * xx[462];
  pm_math_Quaternion_xform_ra(xx + 589, xx + 603, xx + 571);
  xx[440] = xx[410] + xx[263] * xx[462];
  xx[410] = xx[556] + xx[257] * xx[462];
  xx[556] = xx[410] * xx[196];
  xx[565] = xx[440] * xx[196];
  xx[567] = xx[440] * xx[194] - xx[556];
  xx[603] = xx[556];
  xx[604] = - xx[565];
  xx[605] = xx[567];
  pm_math_Vector3_cross_ra(xx + 547, xx + 603, xx + 606);
  xx[568] = xx[440] + xx[7] * (xx[606] - xx[556] * xx[194]);
  xx[440] = xx[410] + (xx[565] * xx[194] + xx[607]) * xx[7];
  xx[410] = (xx[608] - xx[194] * xx[567]) * xx[7];
  xx[603] = xx[568];
  xx[604] = xx[440];
  xx[605] = xx[410];
  pm_math_Vector3_cross_ra(xx + 414, xx + 603, xx + 606);
  xx[556] = xx[561] + xx[440];
  xx[440] = ((xx[143] * xx[143] * xx[557] + xx[145] * xx[145] * xx[557]) * xx[7]
             + xx[586] + xx[571] + xx[606] + xx[556] * xx[82]) / xx[162];
  xx[571] = xx[570] + xx[568] - xx[159] * xx[440];
  xx[572] = xx[556] - xx[85] * xx[440];
  xx[573] = xx[560] + xx[410] - xx[88] * xx[440];
  pm_math_Quaternion_xform_ra(xx + 282, xx + 571, xx + 586);
  xx[570] = - xx[586];
  xx[571] = - xx[587];
  xx[572] = - xx[588];
  solveSymmetricPosDef(xx + 532, xx + 570, 3, 1, xx + 586, xx + 603);
  pm_math_Quaternion_inverseXform_ra(xx + 282, xx + 586, xx + 570);
  xx[410] = xx[440] + pm_math_Vector3_dot_ra(xx + 583, xx + 570);
  xx[440] = xx[410] * xx[194];
  xx[556] = xx[410] * xx[196];
  xx[557] = (xx[440] * xx[194] + xx[556] * xx[196]) * xx[7];
  xx[560] = xx[557] - xx[410];
  xx[561] = xx[7] * (xx[556] * xx[194] - xx[440] * xx[196]);
  xx[586] = xx[560];
  xx[587] = xx[561];
  xx[588] = - xx[557];
  xx[440] = xx[571] - xx[410] * xx[82];
  xx[603] = xx[570];
  xx[604] = xx[440] + xx[410] * xx[406];
  xx[605] = xx[572] - xx[410] * xx[198];
  pm_math_Quaternion_inverseXform_ra(xx + 589, xx + 603, xx + 606);
  xx[556] = xx[462] - (pm_math_Vector3_dot_ra(xx + 553, xx + 586) + xx[259] *
                       xx[606] + xx[265] * xx[607]);
  xx[462] = xx[561] * xx[247];
  xx[565] = xx[247] * xx[560];
  xx[567] = xx[556] - xx[557];
  xx[586] = xx[560] + xx[7] * (xx[205] * xx[462] - xx[565] * xx[247]);
  xx[587] = xx[561] - (xx[205] * xx[565] + xx[462] * xx[247]) * xx[7];
  xx[588] = xx[567];
  xx[462] = xx[606] - xx[250] * xx[567];
  xx[557] = xx[607] + xx[60] * xx[556] + xx[261] * xx[567];
  xx[560] = xx[557] * xx[247];
  xx[561] = xx[462] * xx[247];
  xx[565] = xx[404] - (pm_math_Vector3_dot_ra(xx + 578, xx + 586) + (xx[462] +
    xx[7] * (xx[205] * xx[560] - xx[561] * xx[247])) * xx[245] + xx[237] * (xx
    [557] - (xx[205] * xx[561] + xx[560] * xx[247]) * xx[7]));
  xx[586] = xx[570];
  xx[587] = xx[440] + xx[410] * xx[345];
  xx[588] = xx[572] - xx[410] * xx[197];
  pm_math_Quaternion_inverseXform_ra(xx + 599, xx + 586, xx + 570);
  xx[404] = (xx[410] * xx[143] * xx[143] + xx[410] * xx[145] * xx[145]) * xx[7];
  xx[410] = xx[343] + xx[189] * xx[570] + xx[193] * xx[571] - xx[130] * xx[404];
  xx[343] = xx[404] + xx[410];
  xx[404] = xx[571] - xx[410] * xx[60] - xx[343] * xx[185];
  xx[440] = xx[559] + xx[342] * (xx[404] - (xx[156] * xx[178] * (xx[570] + xx
    [343] * xx[183]) + xx[178] * xx[404] * xx[178]) * xx[7]) - xx[343] * xx[372];
  xx[343] = xx[434] * xx[556] + xx[386] * xx[565] + xx[410] * xx[467] + xx[440] *
    xx[575];
  xx[404] = xx[362] / xx[576];
  xx[462] = xx[84] * xx[404];
  xx[557] = xx[462] * xx[43];
  xx[559] = xx[7] * xx[38] * xx[557];
  xx[560] = xx[7] * xx[557] * xx[43] - xx[462];
  xx[462] = xx[52] * xx[560] - xx[50] * xx[559] - xx[160] * xx[404];
  xx[557] = xx[52] * xx[10];
  xx[561] = xx[557] + xx[291];
  xx[570] = - xx[557];
  xx[571] = xx[280];
  xx[572] = xx[561];
  pm_math_Vector3_cross_ra(xx + 541, xx + 570, xx + 586);
  xx[280] = xx[52] + (xx[587] - xx[253]) * xx[7] - (xx[271] + xx[271]) * xx[7] -
    xx[304] + xx[48];
  xx[253] = (xx[462] + xx[60] * xx[560] + xx[280]) / xx[64];
  xx[271] = xx[559] - xx[61] * xx[253];
  xx[291] = xx[560] - xx[39] * xx[253];
  xx[304] = xx[10] * xx[291];
  xx[557] = xx[10] * xx[271];
  xx[559] = xx[304] - xx[5] * xx[271];
  xx[570] = - xx[304];
  xx[571] = xx[557];
  xx[572] = xx[559];
  pm_math_Vector3_cross_ra(xx + 541, xx + 570, xx + 603);
  xx[560] = xx[271] + xx[7] * (xx[603] - xx[5] * xx[304]);
  xx[271] = xx[49] - xx[137];
  xx[570] = xx[70];
  xx[571] = xx[68];
  xx[572] = xx[70];
  xx[304] = xx[70] * xx[271];
  xx[567] = xx[70] * xx[127];
  xx[568] = - xx[567];
  xx[573] = xx[68] * xx[127];
  xx[581] = xx[304] + xx[573];
  xx[606] = - xx[304];
  xx[607] = xx[568];
  xx[608] = xx[581];
  pm_math_Vector3_cross_ra(xx + 570, xx + 606, xx + 609);
  xx[304] = xx[68] * xx[567];
  xx[567] = xx[68] * xx[124];
  xx[582] = xx[79] * xx[70];
  xx[594] = xx[567] + xx[582];
  xx[595] = xx[594] * xx[49];
  xx[606] = xx[582] + xx[567];
  xx[567] = xx[606] * xx[49];
  xx[582] = (xx[594] * xx[595] + xx[606] * xx[567]) * xx[7];
  xx[607] = xx[271] + xx[7] * (xx[610] - xx[304]) - xx[582] + xx[49];
  xx[608] = xx[607] / xx[121];
  xx[612] = xx[115] * xx[608];
  xx[613] = xx[120] * xx[608];
  xx[614] = xx[613] * xx[124];
  xx[615] = xx[612] * xx[124];
  xx[616] = xx[612] - (xx[79] * xx[614] + xx[615] * xx[124]) * xx[7];
  xx[612] = xx[138] * xx[70];
  xx[617] = xx[612] + xx[573];
  xx[618] = - xx[612];
  xx[619] = xx[568];
  xx[620] = xx[617];
  pm_math_Vector3_cross_ra(xx + 570, xx + 618, xx + 621);
  xx[568] = xx[138] + (xx[622] - xx[304]) * xx[7] - (xx[324] + xx[324]) * xx[7]
    - xx[582] + xx[48];
  xx[48] = xx[613] + xx[7] * (xx[79] * xx[615] - xx[614] * xx[124]);
  xx[304] = xx[119] * xx[608] + xx[48] * xx[138] - xx[127] * xx[616];
  xx[324] = (xx[568] - (xx[304] + xx[48] * xx[60])) / xx[135];
  xx[573] = xx[616] + xx[140] * xx[324];
  xx[582] = xx[48] + xx[134] * xx[324];
  xx[48] = xx[582] * xx[70];
  xx[612] = xx[573] * xx[70];
  xx[613] = xx[48] - xx[573] * xx[68];
  xx[614] = - xx[48];
  xx[615] = xx[612];
  xx[616] = xx[613];
  pm_math_Vector3_cross_ra(xx + 570, xx + 614, xx + 618);
  xx[614] = xx[573] + xx[7] * (xx[618] - xx[48] * xx[68]);
  xx[48] = xx[462] - xx[41] * xx[253];
  xx[462] = xx[291] + (xx[5] * xx[557] + xx[604]) * xx[7];
  xx[291] = (xx[5] * xx[559] + xx[605]) * xx[7];
  xx[603] = xx[560];
  xx[604] = xx[462];
  xx[605] = xx[291];
  pm_math_Vector3_cross_ra(xx + 277, xx + 603, xx + 624);
  xx[625] = xx[68];
  xx[626] = xx[70];
  xx[627] = xx[68];
  xx[628] = xx[70];
  xx[557] = xx[309] * xx[608];
  xx[559] = xx[557] * xx[124];
  xx[573] = xx[317] * xx[608];
  xx[603] = xx[573] * xx[124];
  xx[629] = xx[7] * (xx[559] * xx[124] - xx[79] * xx[603]) - xx[557] + xx[327] *
    xx[324];
  xx[630] = xx[573] - (xx[79] * xx[559] + xx[603] * xx[124]) * xx[7] + xx[320] *
    xx[324];
  xx[631] = xx[304] + xx[118] * xx[324];
  pm_math_Quaternion_xform_ra(xx + 625, xx + 629, xx + 603);
  xx[304] = xx[582] + (xx[612] * xx[68] + xx[619]) * xx[7];
  xx[557] = (xx[68] * xx[613] + xx[620]) * xx[7];
  xx[618] = xx[614];
  xx[619] = xx[304];
  xx[620] = xx[557];
  pm_math_Vector3_cross_ra(xx + 336, xx + 618, xx + 629);
  xx[559] = xx[462] + xx[304];
  xx[304] = ((xx[5] * xx[5] * xx[48] + xx[10] * xx[10] * xx[48]) * xx[7] + xx
             [624] + xx[603] + xx[629] + xx[559] * xx[82]) / xx[162];
  xx[603] = xx[560] + xx[614] - xx[159] * xx[304];
  xx[604] = xx[559] - xx[85] * xx[304];
  xx[605] = xx[291] + xx[557] - xx[88] * xx[304];
  pm_math_Quaternion_xform_ra(xx + 282, xx + 603, xx + 612);
  xx[603] = - xx[612];
  xx[604] = - xx[613];
  xx[605] = - xx[614];
  solveSymmetricPosDef(xx + 532, xx + 603, 3, 1, xx + 612, xx + 618);
  pm_math_Quaternion_inverseXform_ra(xx + 282, xx + 612, xx + 603);
  xx[48] = xx[304] + pm_math_Vector3_dot_ra(xx + 583, xx + 603);
  xx[291] = xx[604] - xx[48] * xx[82];
  xx[612] = xx[603];
  xx[613] = xx[291] + xx[48] * xx[345];
  xx[614] = xx[605] - xx[48] * xx[197];
  pm_math_Quaternion_inverseXform_ra(xx + 599, xx + 612, xx + 618);
  xx[304] = (xx[48] * xx[143] * xx[143] + xx[48] * xx[145] * xx[145]) * xx[7];
  xx[462] = xx[189] * xx[618] + xx[193] * xx[619] - xx[130] * xx[304];
  xx[557] = xx[48] * xx[194];
  xx[559] = xx[48] * xx[196];
  xx[560] = (xx[557] * xx[194] + xx[559] * xx[196]) * xx[7];
  xx[573] = xx[560] - xx[48];
  xx[582] = xx[7] * (xx[559] * xx[194] - xx[557] * xx[196]);
  xx[612] = xx[573];
  xx[613] = xx[582];
  xx[614] = - xx[560];
  xx[629] = xx[603];
  xx[630] = xx[291] + xx[48] * xx[406];
  xx[631] = xx[605] - xx[48] * xx[198];
  pm_math_Quaternion_inverseXform_ra(xx + 589, xx + 629, xx + 632);
  xx[557] = pm_math_Vector3_dot_ra(xx + 553, xx + 612) + xx[259] * xx[632] + xx
    [265] * xx[633];
  xx[559] = xx[582] * xx[247];
  xx[604] = xx[247] * xx[573];
  xx[612] = xx[560] + xx[557];
  xx[613] = xx[573] + xx[7] * (xx[205] * xx[559] - xx[604] * xx[247]);
  xx[614] = xx[582] - (xx[205] * xx[604] + xx[559] * xx[247]) * xx[7];
  xx[615] = - xx[612];
  xx[559] = xx[632] + xx[612] * xx[250];
  xx[560] = xx[633] - xx[557] * xx[60] - xx[612] * xx[261];
  xx[573] = xx[247] * xx[560];
  xx[582] = xx[247] * xx[559];
  xx[604] = pm_math_Vector3_dot_ra(xx + 578, xx + 613) + (xx[559] + xx[7] * (xx
    [205] * xx[573] - xx[582] * xx[247])) * xx[245] + xx[237] * (xx[560] - (xx
    [205] * xx[582] + xx[573] * xx[247]) * xx[7]);
  xx[559] = xx[304] + xx[462];
  xx[304] = xx[619] - xx[60] * xx[462] - xx[559] * xx[185];
  xx[560] = xx[342] * (xx[304] - (xx[156] * xx[178] * (xx[618] + xx[559] * xx
    [183]) + xx[178] * xx[304] * xx[178]) * xx[7]) - xx[559] * xx[372];
  xx[304] = xx[467] * xx[462] - (xx[557] * xx[434] + xx[604] * xx[386]) + xx[575]
    * xx[560];
  xx[550] = xx[10] * xx[43] - xx[38] * xx[5];
  xx[551] = (xx[256] * xx[550] + xx[349] * xx[550]) * xx[7];
  xx[256] = (xx[301] * xx[5] + xx[552]) * xx[7] - xx[551];
  xx[301] = xx[256] / xx[576];
  xx[349] = xx[84] * xx[301];
  xx[552] = xx[349] * xx[43];
  xx[559] = xx[7] * xx[38] * xx[552];
  xx[573] = xx[7] * xx[552] * xx[43] - xx[349];
  xx[349] = xx[52] * xx[573] - xx[50] * xx[559] - xx[160] * xx[301];
  xx[552] = (xx[5] * xx[561] + xx[588]) * xx[7] + (xx[272] + xx[272]) * xx[7] -
    xx[551];
  xx[272] = (xx[349] + xx[60] * xx[573] + xx[552]) / xx[64];
  xx[551] = xx[559] - xx[61] * xx[272];
  xx[559] = xx[573] - xx[39] * xx[272];
  xx[561] = xx[10] * xx[559];
  xx[573] = xx[10] * xx[551];
  xx[582] = xx[561] - xx[5] * xx[551];
  xx[586] = - xx[561];
  xx[587] = xx[573];
  xx[588] = xx[582];
  pm_math_Vector3_cross_ra(xx + 541, xx + 586, xx + 612);
  xx[586] = xx[551] + xx[7] * (xx[612] - xx[5] * xx[561]);
  xx[551] = xx[70] * xx[124] - xx[79] * xx[68];
  xx[561] = (xx[567] * xx[551] + xx[595] * xx[551]) * xx[7];
  xx[567] = (xx[581] * xx[68] + xx[611]) * xx[7] - xx[561];
  xx[581] = xx[567] / xx[121];
  xx[587] = xx[115] * xx[581];
  xx[588] = xx[120] * xx[581];
  xx[595] = xx[588] * xx[124];
  xx[609] = xx[587] * xx[124];
  xx[610] = xx[587] - (xx[79] * xx[595] + xx[609] * xx[124]) * xx[7];
  xx[587] = (xx[68] * xx[617] + xx[623]) * xx[7] + (xx[326] + xx[326]) * xx[7] -
    xx[561];
  xx[326] = xx[588] + xx[7] * (xx[79] * xx[609] - xx[595] * xx[124]);
  xx[561] = xx[119] * xx[581] + xx[326] * xx[138] - xx[127] * xx[610];
  xx[588] = (xx[587] - (xx[561] + xx[326] * xx[60])) / xx[135];
  xx[595] = xx[610] + xx[140] * xx[588];
  xx[609] = xx[326] + xx[134] * xx[588];
  xx[326] = xx[609] * xx[70];
  xx[610] = xx[595] * xx[70];
  xx[611] = xx[326] - xx[595] * xx[68];
  xx[615] = - xx[326];
  xx[616] = xx[610];
  xx[617] = xx[611];
  pm_math_Vector3_cross_ra(xx + 570, xx + 615, xx + 618);
  xx[615] = xx[595] + xx[7] * (xx[618] - xx[326] * xx[68]);
  xx[326] = xx[349] - xx[41] * xx[272];
  xx[349] = xx[559] + (xx[5] * xx[573] + xx[613]) * xx[7];
  xx[559] = (xx[5] * xx[582] + xx[614]) * xx[7];
  xx[612] = xx[586];
  xx[613] = xx[349];
  xx[614] = xx[559];
  pm_math_Vector3_cross_ra(xx + 277, xx + 612, xx + 621);
  xx[573] = xx[309] * xx[581];
  xx[582] = xx[573] * xx[124];
  xx[595] = xx[317] * xx[581];
  xx[612] = xx[595] * xx[124];
  xx[622] = xx[7] * (xx[582] * xx[124] - xx[79] * xx[612]) - xx[573] + xx[327] *
    xx[588];
  xx[623] = xx[595] - (xx[79] * xx[582] + xx[612] * xx[124]) * xx[7] + xx[320] *
    xx[588];
  xx[624] = xx[561] + xx[118] * xx[588];
  pm_math_Quaternion_xform_ra(xx + 625, xx + 622, xx + 612);
  xx[561] = xx[609] + (xx[610] * xx[68] + xx[619]) * xx[7];
  xx[573] = (xx[68] * xx[611] + xx[620]) * xx[7];
  xx[609] = xx[615];
  xx[610] = xx[561];
  xx[611] = xx[573];
  pm_math_Vector3_cross_ra(xx + 336, xx + 609, xx + 616);
  xx[582] = xx[349] + xx[561];
  xx[349] = ((xx[5] * xx[5] * xx[326] + xx[10] * xx[10] * xx[326]) * xx[7] + xx
             [621] + xx[612] + xx[616] + xx[582] * xx[82]) / xx[162];
  xx[609] = xx[586] + xx[615] - xx[159] * xx[349];
  xx[610] = xx[582] - xx[85] * xx[349];
  xx[611] = xx[559] + xx[573] - xx[88] * xx[349];
  pm_math_Quaternion_xform_ra(xx + 282, xx + 609, xx + 612);
  xx[609] = - xx[612];
  xx[610] = - xx[613];
  xx[611] = - xx[614];
  solveSymmetricPosDef(xx + 532, xx + 609, 3, 1, xx + 612, xx + 615);
  pm_math_Quaternion_inverseXform_ra(xx + 282, xx + 612, xx + 609);
  xx[326] = xx[349] + pm_math_Vector3_dot_ra(xx + 583, xx + 609);
  xx[349] = xx[610] - xx[326] * xx[82];
  xx[612] = xx[609];
  xx[613] = xx[349] + xx[326] * xx[345];
  xx[614] = xx[611] - xx[326] * xx[197];
  pm_math_Quaternion_inverseXform_ra(xx + 599, xx + 612, xx + 615);
  xx[559] = (xx[326] * xx[143] * xx[143] + xx[326] * xx[145] * xx[145]) * xx[7];
  xx[561] = xx[189] * xx[615] + xx[193] * xx[616] - xx[130] * xx[559];
  xx[573] = xx[326] * xx[194];
  xx[582] = xx[326] * xx[196];
  xx[586] = (xx[573] * xx[194] + xx[582] * xx[196]) * xx[7];
  xx[595] = xx[586] - xx[326];
  xx[610] = xx[7] * (xx[582] * xx[194] - xx[573] * xx[196]);
  xx[612] = xx[595];
  xx[613] = xx[610];
  xx[614] = - xx[586];
  xx[617] = xx[609];
  xx[618] = xx[349] + xx[326] * xx[406];
  xx[619] = xx[611] - xx[326] * xx[198];
  pm_math_Quaternion_inverseXform_ra(xx + 589, xx + 617, xx + 620);
  xx[573] = pm_math_Vector3_dot_ra(xx + 553, xx + 612) + xx[259] * xx[620] + xx
    [265] * xx[621];
  xx[582] = xx[610] * xx[247];
  xx[612] = xx[247] * xx[595];
  xx[613] = xx[586] + xx[573];
  xx[617] = xx[595] + xx[7] * (xx[205] * xx[582] - xx[612] * xx[247]);
  xx[618] = xx[610] - (xx[205] * xx[612] + xx[582] * xx[247]) * xx[7];
  xx[619] = - xx[613];
  xx[582] = xx[620] + xx[613] * xx[250];
  xx[586] = xx[621] - xx[573] * xx[60] - xx[613] * xx[261];
  xx[595] = xx[247] * xx[586];
  xx[610] = xx[247] * xx[582];
  xx[612] = pm_math_Vector3_dot_ra(xx + 578, xx + 617) + (xx[582] + xx[7] * (xx
    [205] * xx[595] - xx[610] * xx[247])) * xx[245] + xx[237] * (xx[586] - (xx
    [205] * xx[610] + xx[595] * xx[247]) * xx[7]);
  xx[582] = xx[559] + xx[561];
  xx[559] = xx[616] - xx[60] * xx[561] - xx[582] * xx[185];
  xx[586] = xx[342] * (xx[559] - (xx[156] * xx[178] * (xx[615] + xx[582] * xx
    [183]) + xx[178] * xx[559] * xx[178]) * xx[7]) - xx[582] * xx[372];
  xx[559] = xx[467] * xx[561] - (xx[573] * xx[434] + xx[612] * xx[386]) + xx[575]
    * xx[586];
  xx[582] = xx[566] * xx[462] - (xx[557] * xx[397] + xx[604] * xx[392]) + xx[558]
    * xx[560];
  xx[462] = xx[566] * xx[561] - (xx[573] * xx[397] + xx[612] * xx[392]) + xx[558]
    * xx[586];
  xx[612] = xx[464];
  xx[613] = xx[45];
  xx[614] = xx[111];
  xx[45] = xx[48] * xx[68];
  xx[111] = xx[48] * xx[70];
  xx[464] = (xx[45] * xx[68] + xx[111] * xx[70]) * xx[7];
  xx[557] = xx[464] - xx[48];
  xx[560] = xx[7] * (xx[111] * xx[68] - xx[45] * xx[70]);
  xx[615] = xx[557];
  xx[616] = xx[560];
  xx[617] = - xx[464];
  xx[618] = xx[603];
  xx[619] = xx[291] + xx[48] * xx[329];
  xx[620] = xx[605] - xx[48] * xx[72];
  pm_math_Quaternion_inverseXform_ra(xx + 625, xx + 618, xx + 621);
  xx[45] = xx[324] - (pm_math_Vector3_dot_ra(xx + 612, xx + 615) + xx[136] * xx
                      [621] + xx[142] * xx[622]);
  xx[615] = - xx[322];
  xx[616] = xx[307];
  xx[617] = xx[141];
  xx[111] = xx[560] * xx[124];
  xx[141] = xx[124] * xx[557];
  xx[307] = xx[45] - xx[464];
  xx[618] = xx[557] + xx[7] * (xx[79] * xx[111] - xx[141] * xx[124]);
  xx[619] = xx[560] - (xx[79] * xx[141] + xx[111] * xx[124]) * xx[7];
  xx[620] = xx[307];
  xx[111] = xx[621] - xx[127] * xx[307];
  xx[141] = xx[622] + xx[60] * xx[45] + xx[138] * xx[307];
  xx[307] = xx[141] * xx[124];
  xx[322] = xx[111] * xx[124];
  xx[621] = xx[603];
  xx[622] = xx[291] + xx[48] * xx[276];
  xx[623] = xx[605] - xx[48] * xx[273];
  pm_math_Quaternion_inverseXform_ra(xx + 424, xx + 621, xx + 603);
  xx[291] = (xx[48] * xx[5] * xx[5] + xx[48] * xx[10] * xx[10]) * xx[7];
  xx[48] = xx[253] + xx[65] * xx[603] + xx[67] * xx[604] - xx[420] * xx[291];
  xx[253] = xx[291] + xx[48];
  xx[291] = xx[604] - xx[48] * xx[60] - xx[253] * xx[52];
  xx[324] = xx[326] * xx[68];
  xx[464] = xx[326] * xx[70];
  xx[557] = (xx[324] * xx[68] + xx[464] * xx[70]) * xx[7];
  xx[560] = xx[557] - xx[326];
  xx[561] = xx[7] * (xx[464] * xx[68] - xx[324] * xx[70]);
  xx[621] = xx[560];
  xx[622] = xx[561];
  xx[623] = - xx[557];
  xx[629] = xx[609];
  xx[630] = xx[349] + xx[326] * xx[329];
  xx[631] = xx[611] - xx[326] * xx[72];
  pm_math_Quaternion_inverseXform_ra(xx + 625, xx + 629, xx + 632);
  xx[324] = xx[588] - (pm_math_Vector3_dot_ra(xx + 612, xx + 621) + xx[136] *
                       xx[632] + xx[142] * xx[633]);
  xx[464] = xx[561] * xx[124];
  xx[573] = xx[124] * xx[560];
  xx[586] = xx[324] - xx[557];
  xx[621] = xx[560] + xx[7] * (xx[79] * xx[464] - xx[573] * xx[124]);
  xx[622] = xx[561] - (xx[79] * xx[573] + xx[464] * xx[124]) * xx[7];
  xx[623] = xx[586];
  xx[464] = xx[632] - xx[127] * xx[586];
  xx[557] = xx[633] + xx[60] * xx[324] + xx[138] * xx[586];
  xx[560] = xx[557] * xx[124];
  xx[561] = xx[464] * xx[124];
  xx[573] = xx[581] - (pm_math_Vector3_dot_ra(xx + 615, xx + 621) + (xx[464] +
    xx[7] * (xx[79] * xx[560] - xx[561] * xx[124])) * xx[122] + xx[113] * (xx
    [557] - (xx[79] * xx[561] + xx[560] * xx[124]) * xx[7]));
  xx[621] = xx[609];
  xx[622] = xx[349] + xx[326] * xx[276];
  xx[623] = xx[611] - xx[326] * xx[273];
  pm_math_Quaternion_inverseXform_ra(xx + 424, xx + 621, xx + 609);
  xx[349] = (xx[326] * xx[5] * xx[5] + xx[326] * xx[10] * xx[10]) * xx[7];
  xx[326] = xx[272] + xx[65] * xx[609] + xx[67] * xx[610] - xx[420] * xx[349];
  xx[272] = xx[349] + xx[326];
  xx[349] = xx[610] - xx[326] * xx[60] - xx[272] * xx[52];
  xx[464] = xx[301] + xx[342] * (xx[349] - (xx[38] * xx[43] * (xx[609] + xx[272]
    * xx[50]) + xx[43] * xx[349] * xx[43]) * xx[7]) - xx[272] * xx[372];
  xx[272] = xx[568] * xx[324] + xx[607] * xx[573] + xx[326] * xx[280] + xx[464] *
    xx[362];
  xx[629] = xx[434] * xx[389] + xx[386] * (xx[383] - (pm_math_Vector3_dot_ra(xx
    + 578, xx + 596) + (xx[264] + xx[7] * (xx[205] * xx[400] - xx[401] * xx[247]))
    * xx[245] + xx[237] * (xx[368] - (xx[205] * xx[401] + xx[400] * xx[247]) *
    xx[7]))) + xx[325] * xx[467] + (xx[577] + xx[342] * (xx[228] - (xx[156] *
    xx[178] * (xx[593] + xx[371] * xx[183]) + xx[178] * xx[228] * xx[178]) * xx
    [7]) - xx[371] * xx[372]) * xx[575];
  xx[630] = xx[343];
  xx[631] = xx[304];
  xx[632] = xx[559];
  xx[633] = xx[343];
  xx[634] = xx[397] * xx[556] + xx[565] * xx[392] + xx[410] * xx[566] + xx[440] *
    xx[558];
  xx[635] = xx[582];
  xx[636] = xx[462];
  xx[637] = xx[304];
  xx[638] = xx[582];
  xx[639] = xx[568] * xx[45] + xx[607] * (xx[608] - (pm_math_Vector3_dot_ra(xx +
    615, xx + 618) + (xx[111] + xx[7] * (xx[79] * xx[307] - xx[322] * xx[124])) *
    xx[122] + xx[113] * (xx[141] - (xx[79] * xx[322] + xx[307] * xx[124]) * xx[7])))
    + xx[48] * xx[280] + (xx[404] + xx[342] * (xx[291] - (xx[38] * xx[43] * (xx
    [603] + xx[253] * xx[50]) + xx[43] * xx[291] * xx[43]) * xx[7]) - xx[253] *
    xx[372]) * xx[362];
  xx[640] = xx[272];
  xx[641] = xx[559];
  xx[642] = xx[462];
  xx[643] = xx[272];
  xx[644] = xx[587] * xx[324] + xx[573] * xx[567] + xx[326] * xx[552] + xx[464] *
    xx[256];
  xx[45] = xx[194] * state[7];
  xx[48] = xx[196] * state[7];
  xx[111] = (xx[194] * xx[45] + xx[196] * xx[48]) * xx[7];
  xx[141] = state[7] - xx[111];
  xx[228] = xx[7] * (xx[196] * xx[45] - xx[194] * xx[48]);
  xx[45] = xx[228] * xx[247];
  xx[48] = xx[247] * xx[141];
  xx[253] = xx[141] + xx[7] * (xx[205] * xx[45] - xx[48] * xx[247]);
  xx[264] = xx[228] - (xx[205] * xx[48] + xx[45] * xx[247]) * xx[7];
  xx[45] = xx[111] + state[9];
  xx[48] = xx[45] + state[11];
  xx[324] = xx[253];
  xx[325] = xx[264];
  xx[326] = xx[48];
  xx[559] = xx[253] * xx[20];
  xx[560] = xx[102] * xx[264];
  xx[561] = xx[48] * xx[116];
  pm_math_Vector3_cross_ra(xx + 324, xx + 559, xx + 595);
  xx[272] = xx[232] * xx[264];
  xx[291] = xx[253] * xx[232];
  xx[301] = xx[253] + xx[7] * (xx[227] * xx[272] - xx[291] * xx[232]);
  xx[304] = xx[264] - (xx[227] * xx[291] + xx[272] * xx[232]) * xx[7];
  xx[272] = xx[48] + state[13];
  xx[559] = xx[301];
  xx[560] = xx[304];
  xx[561] = xx[272];
  xx[291] = 4.363639999999999e-3;
  xx[603] = xx[301] * xx[22];
  xx[604] = xx[22] * xx[304];
  xx[605] = xx[272] * xx[291];
  pm_math_Vector3_cross_ra(xx + 559, xx + 603, xx + 608);
  xx[307] = 0.0;
  xx[618] = xx[8];
  xx[619] = xx[307];
  xx[620] = xx[307];
  xx[621] = xx[307];
  xx[622] = xx[307];
  xx[623] = xx[307];
  xx[624] = xx[307];
  xx[322] = xx[1] * xx[4];
  xx[343] = xx[1] * xx[6];
  xx[645] = xx[322] + xx[322];
  xx[646] = xx[343] + xx[343];
  xx[647] = xx[322] - xx[322];
  xx[648] = - (xx[343] - xx[343]);
  pm_math_Quaternion_compose_ra(xx + 645, xx + 589, xx + 649);
  xx[322] = xx[652] * xx[247] - xx[205] * xx[649];
  xx[343] = xx[649] * xx[247] + xx[205] * xx[652];
  xx[349] = xx[205] * xx[650] + xx[651] * xx[247];
  xx[368] = xx[650] * xx[247] - xx[205] * xx[651];
  xx[559] = - xx[349];
  xx[560] = xx[368];
  xx[561] = - xx[343];
  xx[371] = xx[340] * xx[368];
  xx[383] = xx[349] * xx[340] + xx[343] * xx[49];
  xx[389] = xx[49] * xx[368];
  xx[603] = - xx[371];
  xx[604] = - xx[383];
  xx[605] = - xx[389];
  pm_math_Vector3_cross_ra(xx + 559, xx + 603, xx + 653);
  xx[400] = xx[652] * xx[250];
  xx[401] = xx[261] * xx[652];
  xx[404] = xx[261] * xx[651] - xx[650] * xx[250];
  xx[559] = - xx[400];
  xx[560] = xx[401];
  xx[561] = - xx[404];
  pm_math_Vector3_cross_ra(xx + 650, xx + 559, xx + 603);
  pm_math_Quaternion_xform_ra(xx + 645, xx + 414, xx + 559);
  xx[410] = xx[274] * xx[6];
  xx[440] = xx[410] * xx[6];
  xx[462] = xx[274] * xx[4];
  xx[464] = xx[462] * xx[4];
  xx[556] = xx[7] * (xx[440] - xx[464]);
  xx[557] = xx[1] * xx[1] * xx[556];
  xx[565] = xx[274] - (xx[440] + xx[464]) * xx[7];
  xx[274] = xx[1] * xx[1] * xx[565];
  xx[1] = xx[7] * (xx[557] - xx[274]) - xx[556] + state[2];
  xx[440] = (xx[410] * xx[4] + xx[462] * xx[6]) * xx[7];
  xx[4] = xx[440] + state[1];
  xx[6] = (xx[557] + xx[274]) * xx[7] - (xx[565] + state[0]) + 0.4;
  xx[656] = - (xx[227] * xx[322] + xx[343] * xx[232]);
  xx[657] = xx[349] * xx[227] - xx[232] * xx[368];
  xx[658] = - (xx[227] * xx[368] + xx[349] * xx[232]);
  xx[659] = xx[343] * xx[227] - xx[232] * xx[322];
  xx[660] = xx[49] + (xx[653] - xx[371] * xx[322]) * xx[7] + xx[261] + (xx[603]
    - xx[649] * xx[400]) * xx[7] + xx[559] + xx[1];
  xx[661] = (xx[654] - xx[322] * xx[383]) * xx[7] + (xx[649] * xx[401] + xx[604])
    * xx[7] + xx[250] + xx[560] + xx[4];
  xx[662] = xx[7] * (xx[655] - xx[389] * xx[322]) - xx[340] + xx[7] * (xx[605] -
    xx[404] * xx[649]) + xx[561] + xx[6];
  bb[0] = sm_core_compiler_computeProximityInfoBrickCylinder(
    blance_leg_1d80934b_1_geometry_2(NULL), blance_leg_1d80934b_1_geometry_1
    (NULL), (pm_math_Transform3 *)(xx + 618), (pm_math_Transform3 *)(xx + 656),
    xx + 274, (pm_math_Vector3 *)(xx + 559), (pm_math_Vector3 *)(xx + 603),
    (pm_math_Vector3 *)(xx + 649), (pm_math_Vector3 *)(xx + 652));
  xx[663] = state[3];
  xx[664] = state[4];
  xx[665] = state[5];
  pm_math_Quaternion_inverseXform_ra(xx + 282, xx + 663, xx + 666);
  xx[322] = xx[82] * state[7];
  xx[343] = xx[667] + xx[322];
  xx[349] = xx[406] * state[7];
  xx[368] = xx[198] * state[7];
  xx[663] = xx[666];
  xx[664] = xx[343] - xx[349];
  xx[665] = xx[368] + xx[668];
  pm_math_Quaternion_inverseXform_ra(xx + 589, xx + 663, xx + 669);
  xx[371] = xx[45] * xx[250];
  xx[383] = xx[669] - xx[371];
  xx[389] = xx[45] * xx[261];
  xx[400] = xx[60] * state[9];
  xx[401] = xx[389] + xx[670] + xx[400];
  xx[404] = xx[401] * xx[247];
  xx[410] = xx[383] * xx[247];
  xx[462] = xx[340] * xx[264];
  xx[464] = xx[383] + xx[7] * (xx[205] * xx[404] - xx[410] * xx[247]) - xx[462];
  xx[383] = xx[48] * xx[49] + xx[253] * xx[340];
  xx[557] = xx[49] * state[11];
  xx[573] = xx[383] + xx[401] - (xx[205] * xx[410] + xx[404] * xx[247]) * xx[7]
    + xx[557];
  xx[401] = xx[573] * xx[232];
  xx[404] = xx[464] * xx[232];
  xx[410] = xx[261] * xx[228] - xx[250] * xx[141];
  xx[577] = xx[49] * xx[264];
  xx[672] = xx[301];
  xx[673] = xx[304];
  xx[674] = xx[272];
  xx[675] = xx[464] + xx[7] * (xx[227] * xx[401] - xx[404] * xx[232]);
  xx[676] = xx[573] - (xx[227] * xx[404] + xx[401] * xx[232]) * xx[7];
  xx[677] = xx[671] - xx[410] - xx[577];
  xx[272] = 1.0e6;
  xx[401] = 1000.0;
  xx[404] = 1.0e-4;
  xx[464] = 0.3;
  xx[573] = 0.2119573811760597;
  xx[581] = 9.126024771145405e-4;
  sm_core_compiler_computeContactWrenches(
    0, 1, bb[0], xx + 274, (const pm_math_Vector3 *)(xx + 559), (const
    pm_math_Vector3 *)(xx + 603), (const pm_math_Vector3 *)(xx + 649), (const
    pm_math_Vector3 *)(xx + 652),
    (const pm_math_Transform3 *)(xx + 618), (const pm_math_Transform3 *)(xx +
    618), (const pm_math_Transform3 *)(xx + 618), (const pm_math_Transform3 *)
    (xx + 656), NULL, (const pm_math_SpatialVector *)(xx + 672),
    0, 1, xx[272], xx[401], xx[404], xx[464], xx[573], xx[581], NULL, NULL,
    NULL, (pm_math_SpatialVector *)(xx + 678));
  xx[274] = - xx[2];
  xx[559] = 4.0;
  xx[649] = xx[2];
  xx[650] = xx[2];
  xx[651] = xx[274];
  xx[652] = xx[274];
  xx[653] = xx[307];
  xx[654] = xx[559];
  xx[655] = xx[307];
  bb[0] = sm_core_compiler_computeProximityInfoCxpolyCylinder(
    blance_leg_1d80934b_1_geometry_0(NULL), blance_leg_1d80934b_1_geometry_1
    (NULL), (pm_math_Transform3 *)(xx + 649), (pm_math_Transform3 *)(xx + 656),
    xx + 2, (pm_math_Vector3 *)(xx + 603), (pm_math_Vector3 *)(xx + 663),
    (pm_math_Vector3 *)(xx + 669), (pm_math_Vector3 *)(xx + 684));
  sm_core_compiler_computeContactWrenches(
    0, 1, bb[0], xx + 2, (const pm_math_Vector3 *)(xx + 603), (const
    pm_math_Vector3 *)(xx + 663), (const pm_math_Vector3 *)(xx + 669), (const
    pm_math_Vector3 *)(xx + 684),
    (const pm_math_Transform3 *)(xx + 649), (const pm_math_Transform3 *)(xx +
    618), (const pm_math_Transform3 *)(xx + 649), (const pm_math_Transform3 *)
    (xx + 656), NULL, (const pm_math_SpatialVector *)(xx + 672),
    0, 1, xx[272], xx[401], xx[404], xx[464], xx[573], xx[581], NULL, NULL,
    NULL, (pm_math_SpatialVector *)(xx + 687));
  xx[2] = xx[610] - xx[680] - xx[689];
  xx[274] = input[0] - xx[2];
  xx[603] = - xx[462];
  xx[604] = xx[383];
  xx[605] = - xx[577];
  pm_math_Vector3_cross_ra(xx + 324, xx + 603, xx + 656);
  xx[324] = xx[656] * xx[232];
  xx[325] = xx[657] * xx[232];
  xx[326] = xx[101] * (xx[657] - (xx[227] * xx[324] + xx[325] * xx[232]) * xx[7])
    - (xx[682] + xx[691]);
  xx[383] = (xx[656] + xx[7] * (xx[227] * xx[325] - xx[324] * xx[232])) * xx[101]
    - (xx[681] + xx[690]);
  xx[324] = xx[232] * xx[383];
  xx[325] = xx[232] * xx[326];
  xx[462] = xx[326] + xx[7] * (xx[227] * xx[324] - xx[325] * xx[232]);
  xx[326] = xx[462] * xx[49];
  xx[603] = xx[141];
  xx[604] = xx[228];
  xx[605] = xx[45];
  xx[659] = - xx[371];
  xx[660] = xx[389];
  xx[661] = - xx[410];
  pm_math_Vector3_cross_ra(xx + 603, xx + 659, xx + 662);
  xx[371] = xx[663] * xx[247];
  xx[389] = xx[662] * xx[247];
  xx[410] = xx[662] + xx[7] * (xx[205] * xx[371] - xx[389] * xx[247]) - (xx[45]
    + xx[48]) * xx[557];
  xx[560] = xx[663] - (xx[205] * xx[389] + xx[371] * xx[247]) * xx[7];
  xx[371] = xx[264] * state[11];
  xx[264] = xx[253] * state[11];
  xx[389] = xx[238] * xx[410] + xx[231] * xx[560] + xx[240] * xx[371] + xx[264] *
    xx[394];
  xx[231] = xx[597] + xx[2] + xx[274] + xx[326] + xx[389];
  xx[238] = xx[462] + xx[410] * xx[252] + xx[234] * xx[560] + xx[369] * xx[371]
    + xx[264] * xx[393];
  xx[234] = xx[238] * xx[49];
  xx[240] = (xx[231] + xx[234]) / xx[244];
  xx[659] = xx[208] * xx[87];
  xx[660] = xx[407] * xx[158];
  xx[661] = xx[81] * xx[62];
  pm_math_Vector3_cross_ra(xx + 164, xx + 659, xx + 669);
  xx[164] = xx[215] * state[27];
  xx[165] = xx[544] + xx[281] * xx[164];
  xx[166] = xx[213] * state[27];
  xx[215] = xx[545] - xx[417] * xx[166];
  xx[252] = xx[43] * xx[215];
  xx[394] = xx[165] * xx[43];
  xx[374] = ((xx[213] + xx[213]) * xx[200] + xx[376]) * xx[36];
  xx[200] = xx[158] * state[25];
  xx[158] = xx[87] * state[25];
  xx[213] = xx[60] * state[25];
  xx[375] = xx[273] * state[7] * state[7];
  xx[376] = xx[10] * xx[375];
  xx[544] = xx[276] * state[7] * state[7];
  xx[545] = xx[376] - xx[5] * xx[544];
  xx[561] = xx[10] * xx[544];
  xx[659] = xx[545];
  xx[660] = xx[561];
  xx[661] = - xx[376];
  pm_math_Vector3_cross_ra(xx + 541, xx + 659, xx + 672);
  xx[577] = (xx[87] + xx[87]) * xx[213] + (xx[5] * xx[376] + xx[674]) * xx[7] -
    xx[544];
  xx[87] = xx[669] + xx[165] - (xx[38] * xx[252] + xx[394] * xx[43]) * xx[7] +
    xx[374] * xx[50] + xx[419] * xx[200] - xx[422] * xx[158] + xx[577] * xx[9];
  xx[165] = xx[670] + xx[215] + xx[7] * (xx[38] * xx[394] - xx[252] * xx[43]) -
    xx[52] * xx[374] + xx[423] * xx[200] - xx[418] * xx[158] - xx[577] * xx[262];
  xx[215] = xx[161] / xx[576];
  xx[252] = xx[210] - xx[84] * xx[215];
  xx[376] = xx[207] * xx[43];
  xx[394] = xx[38] * xx[376];
  xx[418] = xx[43] * xx[252];
  xx[419] = xx[252] + xx[7] * (xx[394] - xx[418] * xx[43]);
  xx[252] = xx[376] * xx[43];
  xx[376] = xx[207] - (xx[38] * xx[418] + xx[252]) * xx[7];
  xx[418] = xx[7] * (xx[672] - xx[5] * xx[545]) - (xx[86] + xx[81]) * xx[213];
  xx[81] = xx[7] * (xx[673] - xx[5] * xx[561]) - xx[375];
  xx[86] = xx[59] * xx[418] + xx[54] * xx[81];
  xx[54] = xx[671] + xx[546] - xx[160] * xx[215] + xx[52] * xx[419] - xx[50] *
    xx[376] + xx[86];
  xx[59] = 1.850049007113989;
  xx[213] = state[24] + xx[59];
  if (xx[307] < xx[213])
    xx[213] = xx[307];
  xx[375] = 1.74532925199433e-3;
  xx[422] = - (xx[213] / xx[375]);
  if (xx[8] < xx[422])
    xx[422] = xx[8];
  xx[423] = 3.0;
  xx[544] = 5729.577951308232;
  xx[545] = xx[544] * state[25];
  xx[561] = 5.729577951308232e6;
  xx[582] = xx[422] * xx[422] * (xx[423] - xx[7] * xx[422]) * ((- xx[213] == xx
    [307] ? xx[307] : - xx[545]) - xx[561] * xx[213]);
  if (xx[307] > xx[582])
    xx[582] = xx[307];
  xx[213] = 5.729577951308232e5;
  xx[422] = state[24];
  if (xx[307] > xx[422])
    xx[422] = xx[307];
  xx[586] = xx[422] / xx[375];
  if (xx[8] < xx[586])
    xx[586] = xx[8];
  xx[588] = (xx[213] * xx[422] + (xx[422] == xx[307] ? xx[307] : xx[545])) * xx
    [586] * xx[586] * (xx[423] - xx[7] * xx[586]);
  if (xx[307] > xx[588])
    xx[588] = xx[307];
  xx[422] = input[5] + xx[582] - xx[588];
  xx[545] = xx[418] * xx[53] + xx[57] * xx[81];
  xx[53] = xx[419] + xx[545];
  xx[57] = (xx[422] - (xx[54] + xx[53] * xx[60])) / xx[64];
  xx[659] = xx[87];
  xx[660] = xx[165];
  xx[661] = xx[54] + xx[41] * xx[57];
  pm_math_Quaternion_xform_ra(xx + 424, xx + 659, xx + 672);
  xx[54] = xx[47] * xx[418] + xx[81] * xx[55];
  xx[47] = xx[374] + xx[262] * xx[158] + xx[9] * xx[200] + xx[58] * xx[577];
  xx[659] = xx[376] + xx[54] + xx[61] * xx[57];
  xx[660] = xx[53] + xx[39] * xx[57];
  xx[661] = xx[47];
  pm_math_Quaternion_xform_ra(xx + 424, xx + 659, xx + 673);
  pm_math_Vector3_cross_ra(xx + 277, xx + 673, xx + 659);
  xx[9] = xx[68] * state[7];
  xx[53] = xx[70] * state[7];
  xx[55] = (xx[68] * xx[9] + xx[70] * xx[53]) * xx[7];
  xx[58] = state[7] - xx[55];
  xx[262] = xx[7] * (xx[70] * xx[9] - xx[68] * xx[53]);
  xx[9] = xx[55] + state[19];
  xx[684] = xx[58];
  xx[685] = xx[262];
  xx[686] = xx[9];
  xx[693] = xx[208] * xx[58];
  xx[694] = xx[407] * xx[262];
  xx[695] = xx[9] * xx[62];
  pm_math_Vector3_cross_ra(xx + 684, xx + 693, xx + 696);
  xx[53] = xx[262] * xx[124];
  xx[374] = xx[124] * xx[58];
  xx[376] = xx[58] + xx[7] * (xx[79] * xx[53] - xx[374] * xx[124]);
  xx[419] = xx[262] - (xx[79] * xx[374] + xx[53] * xx[124]) * xx[7];
  xx[53] = xx[9] + state[21];
  xx[693] = xx[376];
  xx[694] = xx[419];
  xx[695] = xx[53];
  xx[699] = xx[376] * xx[20];
  xx[700] = xx[102] * xx[419];
  xx[701] = xx[53] * xx[116];
  pm_math_Vector3_cross_ra(xx + 693, xx + 699, xx + 702);
  xx[20] = xx[108] * xx[419];
  xx[102] = xx[376] * xx[108];
  xx[116] = xx[376] + xx[7] * (xx[103] * xx[20] - xx[102] * xx[108]);
  xx[374] = xx[419] - (xx[103] * xx[102] + xx[20] * xx[108]) * xx[7];
  xx[20] = xx[53] + state[23];
  xx[699] = xx[116];
  xx[700] = xx[374];
  xx[701] = xx[20];
  xx[705] = xx[116] * xx[22];
  xx[706] = xx[22] * xx[374];
  xx[707] = xx[20] * xx[291];
  pm_math_Vector3_cross_ra(xx + 699, xx + 705, xx + 708);
  pm_math_Quaternion_compose_ra(xx + 645, xx + 625, xx + 711);
  xx[102] = xx[714] * xx[124] - xx[79] * xx[711];
  xx[577] = xx[711] * xx[124] + xx[79] * xx[714];
  xx[582] = xx[79] * xx[712] + xx[713] * xx[124];
  xx[586] = xx[712] * xx[124] - xx[79] * xx[713];
  xx[588] = xx[267] * xx[586];
  xx[699] = - xx[582];
  xx[700] = xx[586];
  xx[701] = - xx[577];
  xx[593] = xx[582] * xx[267] - xx[577] * xx[49];
  xx[598] = xx[49] * xx[586];
  xx[705] = xx[588];
  xx[706] = xx[593];
  xx[707] = - xx[598];
  pm_math_Vector3_cross_ra(xx + 699, xx + 705, xx + 715);
  xx[611] = xx[714] * xx[127];
  xx[660] = xx[138] * xx[714];
  xx[661] = xx[138] * xx[713] - xx[712] * xx[127];
  xx[699] = - xx[611];
  xx[700] = xx[660];
  xx[701] = - xx[661];
  pm_math_Vector3_cross_ra(xx + 712, xx + 699, xx + 705);
  pm_math_Quaternion_xform_ra(xx + 645, xx + 336, xx + 699);
  xx[718] = - (xx[103] * xx[102] + xx[577] * xx[108]);
  xx[719] = xx[582] * xx[103] - xx[108] * xx[586];
  xx[720] = - (xx[103] * xx[586] + xx[582] * xx[108]);
  xx[721] = xx[577] * xx[103] - xx[108] * xx[102];
  xx[722] = xx[49] + (xx[588] * xx[102] + xx[715]) * xx[7] + xx[138] + (xx[705]
    - xx[711] * xx[611]) * xx[7] + xx[699] + xx[1];
  xx[723] = (xx[593] * xx[102] + xx[716]) * xx[7] + (xx[711] * xx[660] + xx[706])
    * xx[7] + xx[127] + xx[700] + xx[4];
  xx[724] = xx[267] + xx[7] * (xx[717] - xx[598] * xx[102]) + xx[7] * (xx[707] -
    xx[661] * xx[711]) + xx[701] + xx[6];
  bb[0] = sm_core_compiler_computeProximityInfoBrickCylinder(
    blance_leg_1d80934b_1_geometry_2(NULL), blance_leg_1d80934b_1_geometry_1
    (NULL), (pm_math_Transform3 *)(xx + 618), (pm_math_Transform3 *)(xx + 718),
    xx + 1, (pm_math_Vector3 *)(xx + 645), (pm_math_Vector3 *)(xx + 699),
    (pm_math_Vector3 *)(xx + 705), (pm_math_Vector3 *)(xx + 711));
  xx[4] = xx[267] * xx[419];
  xx[6] = xx[329] * state[7];
  xx[102] = xx[72] * state[7];
  xx[714] = xx[666];
  xx[715] = xx[343] - xx[6];
  xx[716] = xx[102] + xx[668];
  pm_math_Quaternion_inverseXform_ra(xx + 625, xx + 714, xx + 665);
  xx[343] = xx[9] * xx[127];
  xx[577] = xx[665] - xx[343];
  xx[582] = xx[9] * xx[138];
  xx[586] = xx[60] * state[19];
  xx[588] = xx[582] + xx[666] + xx[586];
  xx[593] = xx[588] * xx[124];
  xx[598] = xx[577] * xx[124];
  xx[611] = xx[4] + xx[577] + xx[7] * (xx[79] * xx[593] - xx[598] * xx[124]);
  xx[577] = xx[53] * xx[49] - xx[376] * xx[267];
  xx[648] = xx[49] * state[21];
  xx[660] = xx[577] + xx[588] - (xx[79] * xx[598] + xx[593] * xx[124]) * xx[7] +
    xx[648];
  xx[588] = xx[660] * xx[108];
  xx[593] = xx[611] * xx[108];
  xx[598] = xx[138] * xx[262] - xx[127] * xx[58];
  xx[661] = xx[49] * xx[419];
  xx[725] = xx[116];
  xx[726] = xx[374];
  xx[727] = xx[20];
  xx[728] = xx[611] + xx[7] * (xx[103] * xx[588] - xx[593] * xx[108]);
  xx[729] = xx[660] - (xx[103] * xx[593] + xx[588] * xx[108]) * xx[7];
  xx[730] = xx[667] - xx[598] - xx[661];
  sm_core_compiler_computeContactWrenches(
    0, 1, bb[0], xx + 1, (const pm_math_Vector3 *)(xx + 645), (const
    pm_math_Vector3 *)(xx + 699), (const pm_math_Vector3 *)(xx + 705), (const
    pm_math_Vector3 *)(xx + 711),
    (const pm_math_Transform3 *)(xx + 618), (const pm_math_Transform3 *)(xx +
    618), (const pm_math_Transform3 *)(xx + 618), (const pm_math_Transform3 *)
    (xx + 718), NULL, (const pm_math_SpatialVector *)(xx + 725),
    0, 1, xx[272], xx[401], xx[404], xx[464], xx[573], xx[581], NULL, NULL,
    NULL, (pm_math_SpatialVector *)(xx + 665));
  bb[0] = sm_core_compiler_computeProximityInfoCxpolyCylinder(
    blance_leg_1d80934b_1_geometry_0(NULL), blance_leg_1d80934b_1_geometry_1
    (NULL), (pm_math_Transform3 *)(xx + 649), (pm_math_Transform3 *)(xx + 718),
    xx + 1, (pm_math_Vector3 *)(xx + 645), (pm_math_Vector3 *)(xx + 699),
    (pm_math_Vector3 *)(xx + 705), (pm_math_Vector3 *)(xx + 711));
  sm_core_compiler_computeContactWrenches(
    0, 1, bb[0], xx + 1, (const pm_math_Vector3 *)(xx + 645), (const
    pm_math_Vector3 *)(xx + 699), (const pm_math_Vector3 *)(xx + 705), (const
    pm_math_Vector3 *)(xx + 711),
    (const pm_math_Transform3 *)(xx + 649), (const pm_math_Transform3 *)(xx +
    618), (const pm_math_Transform3 *)(xx + 649), (const pm_math_Transform3 *)
    (xx + 718), NULL, (const pm_math_SpatialVector *)(xx + 725),
    0, 1, xx[272], xx[401], xx[404], xx[464], xx[573], xx[581], NULL, NULL,
    NULL, (pm_math_SpatialVector *)(xx + 731));
  xx[1] = xx[708] - xx[665] - xx[731] + xx[22] * xx[374] * state[23];
  xx[20] = xx[709] - xx[666] - xx[732] - xx[22] * xx[116] * state[23];
  xx[116] = xx[108] * xx[20];
  xx[272] = xx[1] * xx[108];
  xx[618] = xx[4];
  xx[619] = xx[577];
  xx[620] = - xx[661];
  pm_math_Vector3_cross_ra(xx + 693, xx + 618, xx + 621);
  xx[4] = xx[621] * xx[108];
  xx[374] = xx[622] * xx[108];
  xx[401] = xx[101] * (xx[622] - (xx[103] * xx[4] + xx[374] * xx[108]) * xx[7])
    - (xx[669] + xx[735]);
  xx[404] = (xx[621] + xx[7] * (xx[103] * xx[374] - xx[4] * xx[108])) * xx[101]
    - (xx[668] + xx[734]);
  xx[4] = xx[108] * xx[404];
  xx[374] = xx[108] * xx[401];
  xx[464] = xx[401] + xx[7] * (xx[103] * xx[4] - xx[374] * xx[108]);
  xx[401] = xx[419] * state[21];
  xx[419] = xx[376] * state[21];
  xx[618] = - xx[343];
  xx[619] = xx[582];
  xx[620] = - xx[598];
  pm_math_Vector3_cross_ra(xx + 684, xx + 618, xx + 645);
  xx[343] = xx[646] * xx[124];
  xx[573] = xx[645] * xx[124];
  xx[577] = xx[645] + xx[7] * (xx[79] * xx[343] - xx[573] * xx[124]) - (xx[9] +
    xx[53]) * xx[648];
  xx[581] = xx[646] - (xx[79] * xx[573] + xx[343] * xx[124]) * xx[7];
  xx[343] = xx[702] + xx[1] - (xx[103] * xx[116] + xx[272] * xx[108]) * xx[7] -
    xx[464] * xx[267] + xx[421] * xx[401] - xx[419] * xx[23] - (xx[310] * xx[577]
    + xx[308] * xx[581]);
  xx[1] = xx[710] - xx[667] - xx[733];
  xx[23] = input[1] - xx[1];
  xx[421] = xx[464] * xx[49];
  xx[573] = xx[114] * xx[577] + xx[107] * xx[581] - (xx[117] * xx[401] + xx[419]
    * xx[316]);
  xx[107] = xx[704] + xx[1] + xx[23] + xx[421] + xx[573];
  xx[114] = xx[464] + xx[577] * xx[129] + xx[110] * xx[581] - (xx[308] * xx[401]
    + xx[419] * xx[315]);
  xx[110] = xx[114] * xx[49];
  xx[117] = (xx[107] + xx[110]) / xx[121];
  xx[129] = xx[343] + xx[309] * xx[117];
  xx[308] = xx[404] - (xx[103] * xx[374] + xx[4] * xx[108]) * xx[7];
  xx[4] = xx[101] * xx[623] - (xx[670] + xx[736]);
  xx[316] = (xx[376] + xx[376]) * xx[648] + xx[647];
  xx[374] = xx[703] + xx[20] + xx[7] * (xx[103] * xx[272] - xx[116] * xx[108]) +
    xx[267] * xx[308] - xx[49] * xx[4] + xx[401] * xx[463] - xx[461] * xx[419] +
    xx[314] * xx[577] + xx[315] * xx[581] - xx[316] * xx[330];
  xx[20] = xx[374] - xx[317] * xx[117];
  xx[103] = xx[124] * xx[20];
  xx[108] = xx[129] * xx[124];
  xx[116] = xx[4] + xx[419] * xx[330] + xx[146] * xx[316];
  xx[4] = xx[116] * xx[127];
  xx[146] = xx[262] * state[19];
  xx[262] = xx[58] * state[19];
  xx[267] = xx[102] * state[7];
  xx[102] = xx[70] * xx[267];
  xx[272] = xx[6] * state[7];
  xx[6] = xx[102] - xx[68] * xx[272];
  xx[315] = xx[70] * xx[272];
  xx[618] = xx[6];
  xx[619] = xx[315];
  xx[620] = - xx[102];
  pm_math_Vector3_cross_ra(xx + 570, xx + 618, xx + 621);
  xx[316] = xx[7] * (xx[621] - xx[68] * xx[6]) - (xx[55] + xx[9]) * xx[586];
  xx[6] = xx[7] * (xx[622] - xx[68] * xx[315]) - xx[267];
  xx[9] = (xx[58] + xx[58]) * xx[586] + (xx[68] * xx[102] + xx[623]) * xx[7] -
    xx[272];
  xx[55] = xx[465] * xx[146] - xx[331] * xx[262] + xx[316] * xx[321] + xx[312] *
    xx[6] + xx[9] * xx[333];
  xx[58] = state[18];
  if (xx[307] < xx[58])
    xx[58] = xx[307];
  xx[102] = - (xx[58] / xx[375]);
  if (xx[8] < xx[102])
    xx[102] = xx[8];
  xx[267] = xx[544] * state[19];
  xx[272] = xx[102] * xx[102] * (xx[423] - xx[7] * xx[102]) * ((- xx[58] == xx
    [307] ? xx[307] : - xx[267]) - xx[561] * xx[58]);
  if (xx[307] > xx[272])
    xx[272] = xx[307];
  xx[58] = state[18] - xx[59];
  if (xx[307] > xx[58])
    xx[58] = xx[307];
  xx[102] = xx[58] / xx[375];
  if (xx[8] < xx[102])
    xx[102] = xx[8];
  xx[315] = (xx[213] * xx[58] + (xx[58] == xx[307] ? xx[307] : xx[267])) * xx
    [102] * xx[102] * (xx[423] - xx[7] * xx[102]);
  if (xx[307] > xx[315])
    xx[315] = xx[307];
  xx[58] = input[4] + xx[272] - xx[315];
  xx[102] = xx[114] - xx[120] * xx[117];
  xx[267] = xx[308] + xx[112] * xx[577] + xx[581] * xx[106] - (xx[310] * xx[401]
    + xx[314] * xx[419]);
  xx[106] = xx[267] - xx[115] * xx[117];
  xx[112] = xx[124] * xx[106];
  xx[272] = xx[124] * xx[102];
  xx[308] = xx[102] + xx[7] * (xx[79] * xx[112] - xx[272] * xx[124]);
  xx[102] = xx[106] - (xx[79] * xx[272] + xx[112] * xx[124]) * xx[7];
  xx[106] = xx[323] * xx[146] - xx[318] * xx[262] + xx[131] * xx[316] + xx[80] *
    xx[6];
  xx[80] = xx[698] + xx[107] - xx[119] * xx[117] + xx[138] * xx[308] - xx[127] *
    xx[102] + xx[106];
  xx[107] = xx[146] * xx[312] - xx[313] * xx[262] + xx[123] * xx[316] + xx[128] *
    xx[6];
  xx[112] = xx[308] + xx[107];
  xx[123] = (xx[58] - (xx[80] + xx[112] * xx[60])) / xx[135];
  xx[128] = xx[138] * xx[116];
  xx[131] = xx[468] * xx[146] - xx[105] * xx[262] + xx[334] * xx[316] + xx[313] *
    xx[6] - xx[9] * xx[147];
  xx[312] = xx[696] + xx[129] - (xx[79] * xx[103] + xx[108] * xx[124]) * xx[7] +
    xx[4] + xx[55] + xx[327] * xx[123];
  xx[313] = xx[697] + xx[20] + xx[7] * (xx[79] * xx[108] - xx[103] * xx[124]) -
    xx[128] + xx[131] + xx[320] * xx[123];
  xx[314] = xx[80] + xx[118] * xx[123];
  pm_math_Quaternion_xform_ra(xx + 625, xx + 312, xx + 463);
  xx[20] = xx[146] * xx[321] - xx[334] * xx[262] + xx[132] * xx[316] + xx[109] *
    xx[6];
  xx[80] = xx[116] + xx[146] * xx[333] + xx[147] * xx[262] + xx[148] * xx[9];
  xx[312] = xx[102] + xx[20] + xx[140] * xx[123];
  xx[313] = xx[112] + xx[134] * xx[123];
  xx[314] = xx[80];
  pm_math_Quaternion_xform_ra(xx + 625, xx + 312, xx + 618);
  pm_math_Vector3_cross_ra(xx + 336, xx + 618, xx + 312);
  xx[9] = xx[143] * state[7];
  xx[102] = xx[145] * state[7];
  xx[103] = (xx[143] * xx[9] + xx[145] * xx[102]) * xx[7];
  xx[105] = state[7] - xx[103];
  xx[108] = xx[7] * (xx[145] * xx[9] - xx[143] * xx[102]);
  xx[9] = xx[103] + state[15];
  xx[313] = xx[105];
  xx[314] = xx[108];
  xx[315] = xx[9];
  xx[621] = xx[208] * xx[105];
  xx[622] = xx[407] * xx[108];
  xx[623] = xx[9] * xx[62];
  pm_math_Vector3_cross_ra(xx + 313, xx + 621, xx + 645);
  xx[102] = xx[108] * xx[178];
  xx[109] = xx[178] * xx[105];
  xx[112] = xx[105] + xx[7] * (xx[156] * xx[102] - xx[109] * xx[178]);
  xx[116] = xx[108] - (xx[156] * xx[109] + xx[102] * xx[178]) * xx[7];
  xx[102] = xx[9] + state[17];
  xx[621] = xx[112];
  xx[622] = xx[116];
  xx[623] = xx[102];
  xx[648] = xx[112] * xx[281];
  xx[649] = xx[417] * xx[116];
  xx[650] = xx[102] * xx[160];
  pm_math_Vector3_cross_ra(xx + 621, xx + 648, xx + 651);
  xx[109] = xx[116] * state[17];
  xx[116] = xx[651] + xx[281] * xx[109];
  xx[129] = xx[112] * state[17];
  xx[132] = xx[652] - xx[417] * xx[129];
  xx[147] = xx[178] * xx[132];
  xx[148] = xx[116] * xx[178];
  xx[272] = xx[49] * state[17];
  xx[648] = - (xx[9] * xx[183]);
  xx[649] = xx[9] * xx[185];
  xx[650] = - (xx[185] * xx[108] - xx[183] * xx[105]);
  pm_math_Vector3_cross_ra(xx + 313, xx + 648, xx + 665);
  xx[281] = ((xx[112] + xx[112]) * xx[272] + xx[667]) * xx[36];
  xx[112] = xx[108] * state[15];
  xx[108] = xx[105] * state[15];
  xx[308] = xx[60] * state[15];
  xx[310] = xx[197] * state[7] * state[7];
  xx[313] = xx[145] * xx[310];
  xx[314] = xx[345] * state[7] * state[7];
  xx[315] = xx[143] * xx[314] - xx[313];
  xx[318] = xx[145] * xx[314];
  xx[648] = xx[315];
  xx[649] = - xx[318];
  xx[650] = xx[313];
  pm_math_Vector3_cross_ra(xx + 562, xx + 648, xx + 668);
  xx[321] = (xx[105] + xx[105]) * xx[308] + (xx[143] * xx[313] + xx[670]) * xx[7]
    - xx[314];
  xx[105] = xx[645] + xx[116] - (xx[156] * xx[147] + xx[148] * xx[178]) * xx[7]
    + xx[281] * xx[183] + xx[133] * xx[112] - xx[311] * xx[108] + xx[321] * xx
    [74];
  xx[116] = xx[646] + xx[132] + xx[7] * (xx[156] * xx[148] - xx[147] * xx[178])
    - xx[185] * xx[281] + xx[319] * xx[112] - xx[104] * xx[108] - xx[321] * xx
    [339];
  xx[104] = xx[665] * xx[178];
  xx[132] = xx[666] * xx[178];
  xx[133] = xx[36] * (xx[666] - (xx[156] * xx[104] + xx[132] * xx[178]) * xx[7]);
  xx[147] = xx[653] + xx[49] * xx[133];
  xx[148] = xx[147] / xx[576];
  xx[311] = xx[133] - xx[84] * xx[148];
  xx[313] = xx[36] * (xx[665] + xx[7] * (xx[156] * xx[132] - xx[104] * xx[178])
                      - (xx[9] + xx[102]) * xx[272]);
  xx[36] = xx[313] * xx[178];
  xx[102] = xx[156] * xx[36];
  xx[104] = xx[178] * xx[311];
  xx[132] = xx[311] + xx[7] * (xx[102] - xx[104] * xx[178]);
  xx[272] = xx[36] * xx[178];
  xx[36] = xx[313] - (xx[156] * xx[104] + xx[272]) * xx[7];
  xx[104] = xx[7] * (xx[668] + xx[143] * xx[315]) - (xx[103] + xx[9]) * xx[308];
  xx[9] = xx[7] * (xx[669] - xx[143] * xx[318]) - xx[310];
  xx[103] = xx[190] * xx[104] + xx[46] * xx[9];
  xx[46] = xx[647] + xx[653] - xx[160] * xx[148] + xx[185] * xx[132] - xx[183] *
    xx[36] + xx[103];
  xx[190] = state[14] + xx[59];
  if (xx[307] < xx[190])
    xx[190] = xx[307];
  xx[308] = - (xx[190] / xx[375]);
  if (xx[8] < xx[308])
    xx[308] = xx[8];
  xx[310] = xx[544] * state[15];
  xx[311] = xx[308] * xx[308] * (xx[423] - xx[7] * xx[308]) * ((- xx[190] == xx
    [307] ? xx[307] : - xx[310]) - xx[561] * xx[190]);
  if (xx[307] > xx[311])
    xx[311] = xx[307];
  xx[190] = state[14];
  if (xx[307] > xx[190])
    xx[190] = xx[307];
  xx[308] = xx[190] / xx[375];
  if (xx[8] < xx[308])
    xx[308] = xx[8];
  xx[314] = (xx[213] * xx[190] + (xx[190] == xx[307] ? xx[307] : xx[310])) * xx
    [308] * xx[308] * (xx[423] - xx[7] * xx[308]);
  if (xx[307] > xx[314])
    xx[314] = xx[307];
  xx[190] = input[3] + xx[311] - xx[314];
  xx[308] = xx[104] * xx[186] + xx[177] * xx[9];
  xx[177] = xx[132] + xx[308];
  xx[132] = (xx[190] - (xx[46] + xx[177] * xx[60])) / xx[187];
  xx[648] = xx[105];
  xx[649] = xx[116];
  xx[650] = xx[46] + xx[63] * xx[132];
  pm_math_Quaternion_xform_ra(xx + 599, xx + 648, xx + 665);
  xx[46] = xx[182] * xx[104] + xx[9] * xx[42];
  xx[42] = xx[281] + xx[339] * xx[108] + xx[74] * xx[112] + xx[181] * xx[321];
  xx[648] = xx[36] + xx[46] + xx[191] * xx[132];
  xx[649] = xx[177] + xx[157] * xx[132];
  xx[650] = xx[42];
  pm_math_Quaternion_xform_ra(xx + 599, xx + 648, xx + 666);
  pm_math_Vector3_cross_ra(xx + 365, xx + 666, xx + 648);
  xx[649] = xx[208] * xx[141];
  xx[650] = xx[407] * xx[228];
  xx[651] = xx[45] * xx[62];
  pm_math_Vector3_cross_ra(xx + 603, xx + 649, xx + 684);
  xx[36] = xx[608] - xx[678] - xx[687] + xx[22] * xx[304] * state[13];
  xx[62] = xx[609] - xx[679] - xx[688] - xx[22] * xx[301] * state[13];
  xx[22] = xx[232] * xx[62];
  xx[74] = xx[36] * xx[232];
  xx[177] = xx[595] + xx[36] - (xx[227] * xx[22] + xx[74] * xx[232]) * xx[7] +
    xx[462] * xx[340] + xx[289] * xx[371] - xx[264] * xx[149] + xx[346] * xx[410]
    + xx[369] * xx[560];
  xx[36] = xx[177] - xx[370] * xx[240];
  xx[149] = xx[383] - (xx[227] * xx[325] + xx[324] * xx[232]) * xx[7];
  xx[181] = xx[101] * xx[658] - (xx[683] + xx[692]);
  xx[101] = (xx[253] + xx[253]) * xx[557] + xx[664];
  xx[182] = xx[596] + xx[62] + xx[7] * (xx[227] * xx[74] - xx[22] * xx[232]) -
    (xx[340] * xx[149] + xx[49] * xx[181]) + xx[371] * xx[335] - xx[226] * xx
    [264] - (xx[396] * xx[410] + xx[393] * xx[560] + xx[101] * xx[408]);
  xx[22] = xx[182] + xx[395] * xx[240];
  xx[62] = xx[247] * xx[22];
  xx[74] = xx[36] * xx[247];
  xx[186] = xx[181] + xx[264] * xx[408] + xx[269] * xx[101];
  xx[101] = xx[186] * xx[250];
  xx[181] = xx[228] * state[9];
  xx[208] = xx[141] * state[9];
  xx[226] = xx[349] * state[7];
  xx[227] = xx[368] * state[7];
  xx[228] = xx[196] * xx[227];
  xx[232] = xx[194] * xx[226] - xx[228];
  xx[253] = xx[196] * xx[226];
  xx[323] = xx[232];
  xx[324] = - xx[253];
  xx[325] = xx[228];
  pm_math_Vector3_cross_ra(xx + 547, xx + 323, xx + 333);
  xx[269] = xx[7] * (xx[333] + xx[194] * xx[232]) - (xx[111] + xx[45]) * xx[400];
  xx[45] = xx[7] * (xx[334] - xx[194] * xx[253]) - xx[227];
  xx[111] = (xx[141] + xx[141]) * xx[400] + (xx[194] * xx[228] + xx[335]) * xx[7]
    - xx[226];
  xx[141] = xx[347] * xx[181] - xx[298] * xx[208] + xx[269] * xx[399] + xx[235] *
    xx[45] + xx[111] * xx[411];
  xx[226] = state[8];
  if (xx[307] < xx[226])
    xx[226] = xx[307];
  xx[227] = - (xx[226] / xx[375]);
  if (xx[8] < xx[227])
    xx[227] = xx[8];
  xx[228] = xx[544] * state[9];
  xx[232] = xx[227] * xx[227] * (xx[423] - xx[7] * xx[227]) * ((- xx[226] == xx
    [307] ? xx[307] : - xx[228]) - xx[561] * xx[226]);
  if (xx[307] > xx[232])
    xx[232] = xx[307];
  xx[226] = state[8] - xx[59];
  if (xx[307] > xx[226])
    xx[226] = xx[307];
  xx[59] = xx[226] / xx[375];
  if (xx[8] < xx[59])
    xx[59] = xx[8];
  xx[8] = (xx[213] * xx[226] + (xx[226] == xx[307] ? xx[307] : xx[228])) * xx[59]
    * xx[59] * (xx[423] - xx[7] * xx[59]);
  if (xx[307] > xx[8])
    xx[8] = xx[307];
  xx[59] = input[2] + xx[232] - xx[8];
  xx[8] = xx[238] - xx[243] * xx[240];
  xx[213] = xx[149] + xx[236] * xx[410] + xx[560] * xx[230] + xx[346] * xx[371]
    + xx[396] * xx[264];
  xx[149] = xx[213] - xx[239] * xx[240];
  xx[226] = xx[247] * xx[149];
  xx[227] = xx[247] * xx[8];
  xx[228] = xx[8] + xx[7] * (xx[205] * xx[226] - xx[227] * xx[247]);
  xx[8] = xx[149] - (xx[205] * xx[227] + xx[226] * xx[247]) * xx[7];
  xx[149] = xx[332] * xx[181] - xx[356] * xx[208] + xx[254] * xx[269] + xx[206] *
    xx[45];
  xx[206] = xx[686] + xx[231] - xx[242] * xx[240] + xx[261] * xx[228] - xx[250] *
    xx[8] + xx[149];
  xx[226] = xx[181] * xx[235] - xx[373] * xx[208] + xx[246] * xx[269] + xx[251] *
    xx[45];
  xx[227] = xx[228] + xx[226];
  xx[228] = (xx[59] - (xx[206] + xx[227] * xx[60])) / xx[258];
  xx[230] = xx[261] * xx[186];
  xx[231] = xx[409] * xx[181] - xx[152] * xx[208] + xx[412] * xx[269] + xx[373] *
    xx[45] - xx[111] * xx[100];
  xx[323] = xx[684] + xx[36] - (xx[205] * xx[62] + xx[74] * xx[247]) * xx[7] +
    xx[101] + xx[141] + xx[405] * xx[228];
  xx[324] = xx[685] + xx[22] + xx[7] * (xx[205] * xx[74] - xx[62] * xx[247]) -
    xx[230] + xx[231] + xx[398] * xx[228];
  xx[325] = xx[206] + xx[241] * xx[228];
  pm_math_Quaternion_xform_ra(xx + 589, xx + 323, xx + 330);
  xx[22] = xx[181] * xx[399] - xx[412] * xx[208] + xx[255] * xx[269] + xx[233] *
    xx[45];
  xx[36] = xx[186] + xx[181] * xx[411] + xx[100] * xx[208] + xx[270] * xx[111];
  xx[253] = xx[8] + xx[22] + xx[263] * xx[228];
  xx[254] = xx[227] + xx[257] * xx[228];
  xx[255] = xx[36];
  pm_math_Quaternion_xform_ra(xx + 589, xx + 253, xx + 323);
  pm_math_Vector3_cross_ra(xx + 414, xx + 323, xx + 253);
  xx[8] = xx[322] * state[7];
  xx[62] = xx[83] * xx[8];
  xx[74] = xx[214] * xx[8];
  xx[100] = xx[674] + xx[619] + xx[667] + xx[324] + xx[74];
  xx[111] = (xx[672] + xx[659] + xx[463] + xx[312] + xx[665] + xx[648] + xx[330]
             + xx[253] + xx[62] + xx[100] * xx[82]) / xx[162];
  xx[152] = xx[290] * xx[8];
  xx[186] = xx[163] * xx[8];
  xx[253] = xx[673] + xx[618] + xx[666] + xx[323] + xx[152] - xx[159] * xx[111];
  xx[254] = xx[100] - xx[85] * xx[111];
  xx[255] = xx[675] + xx[620] + xx[668] + xx[325] + xx[186] - xx[88] * xx[111];
  pm_math_Quaternion_xform_ra(xx + 282, xx + 253, xx + 310);
  xx[253] = - xx[310];
  xx[254] = - xx[311];
  xx[255] = - xx[312];
  solveSymmetricPosDef(xx + 532, xx + 253, 3, 1, xx + 310, xx + 321);
  xx[100] = 9.806650000000001;
  xx[163] = xx[293] - xx[302] + xx[351] - xx[360] + xx[378] - xx[387] + xx[429]
    - xx[438];
  xx[206] = xx[455] - xx[30] - xx[28] - xx[446] + xx[472] - xx[93] - xx[91] -
    xx[481] + xx[499] - xx[170] - xx[168] - xx[490] + xx[508] - xx[219] - xx[217]
    - xx[517] + xx[163] * xx[82];
  xx[27] = xx[296] - xx[303] + xx[354] - xx[361] + xx[381] - xx[388] + xx[432] -
    xx[439];
  xx[28] = xx[458] - xx[33] - xx[29] - xx[449] + xx[475] - xx[96] - xx[92] - xx
    [484] + xx[502] - xx[173] - xx[169] - xx[493] + xx[511] - xx[222] - xx[218]
    - xx[520] + xx[27] * xx[82];
  xx[90] = xx[71] - xx[229] * xx[211];
  xx[91] = xx[180] - xx[229] * xx[209];
  xx[92] = xx[83] - xx[229] * xx[89];
  xx[93] = xx[292] - xx[299] + xx[350] - xx[357] + xx[377] - xx[384] + xx[428] -
    xx[435] - xx[206] * xx[211];
  xx[94] = xx[163] - xx[206] * xx[209];
  xx[95] = xx[294] - xx[305] + xx[352] - xx[363] + xx[379] - xx[390] + xx[430] -
    xx[441] - xx[206] * xx[89];
  xx[96] = xx[295] - xx[300] + xx[353] - xx[358] + xx[380] - xx[385] + xx[431] -
    xx[436] - xx[28] * xx[211];
  xx[97] = xx[27] - xx[28] * xx[209];
  xx[98] = xx[297] - xx[306] + xx[355] - xx[364] + xx[382] - xx[391] + xx[433] -
    xx[442] - xx[28] * xx[89];
  pm_math_Matrix3x3_composeTranspose_ra(xx + 90, xx + 11, xx + 27);
  pm_math_Matrix3x3_compose_ra(xx + 11, xx + 27, xx + 89);
  xx[11] = - xx[556];
  xx[12] = xx[440];
  xx[13] = - xx[565];
  pm_math_Matrix3x3_postCross_ra(xx + 523, xx + 11, xx + 27);
  xx[438] = xx[89] - xx[27];
  xx[439] = xx[90] - xx[30];
  xx[440] = xx[91] - xx[33];
  xx[441] = xx[92] - xx[28];
  xx[442] = xx[93] - xx[31];
  xx[443] = xx[94] - xx[34];
  xx[444] = xx[95] - xx[29];
  xx[445] = xx[96] - xx[32];
  xx[446] = xx[97] - xx[35];
  xx[447] = xx[523];
  xx[448] = xx[524];
  xx[449] = xx[525];
  xx[450] = xx[526];
  xx[451] = xx[527];
  xx[452] = xx[528];
  xx[453] = xx[529];
  xx[454] = xx[530];
  xx[455] = xx[531];
  solveSymmetricPosDef(xx + 532, xx + 438, 3, 6, xx + 468, xx + 11);
  xx[11] = 1.77635683940025e-15;
  xx[12] = xx[100] * xx[477] + xx[11] * xx[483];
  xx[13] = xx[100] * xx[478] + xx[11] * xx[484];
  xx[14] = xx[100] * xx[479] + xx[11] * xx[485];
  xx[15] = xx[310] + xx[12] - xx[100];
  xx[16] = xx[311] + xx[13];
  xx[17] = xx[312] + xx[14] - xx[11];
  pm_math_Quaternion_inverseXform_ra(xx + 282, xx + 15, xx + 27);
  xx[15] = xx[111] + pm_math_Vector3_dot_ra(xx + 583, xx + 27);
  xx[16] = xx[15] * xx[194];
  xx[17] = xx[15] * xx[196];
  xx[18] = (xx[16] * xx[194] + xx[17] * xx[196]) * xx[7];
  xx[19] = xx[18] - xx[15];
  xx[30] = xx[19] + xx[181];
  xx[31] = xx[7] * (xx[17] * xx[194] - xx[16] * xx[196]);
  xx[16] = xx[31] - xx[208];
  xx[17] = xx[247] * xx[16];
  xx[32] = xx[30] * xx[247];
  xx[33] = xx[19];
  xx[34] = xx[31];
  xx[35] = - xx[18];
  xx[19] = xx[28] - xx[15] * xx[82];
  xx[28] = xx[29] + xx[8];
  xx[89] = xx[27];
  xx[90] = xx[19] + xx[15] * xx[406];
  xx[91] = xx[28] - xx[15] * xx[198];
  pm_math_Quaternion_inverseXform_ra(xx + 589, xx + 89, xx + 92);
  xx[29] = xx[228] - (pm_math_Vector3_dot_ra(xx + 553, xx + 33) + xx[259] * xx
                      [92] + xx[265] * xx[93]);
  xx[31] = xx[29] - xx[18];
  xx[33] = xx[30] + xx[7] * (xx[205] * xx[17] - xx[32] * xx[247]);
  xx[34] = xx[16] - (xx[205] * xx[32] + xx[17] * xx[247]) * xx[7];
  xx[35] = xx[31];
  xx[16] = xx[92] + xx[269] - xx[250] * xx[31];
  xx[17] = xx[93] + xx[60] * xx[29] + xx[45] + xx[261] * xx[31];
  xx[18] = xx[17] * xx[247];
  xx[30] = xx[16] * xx[247];
  xx[31] = xx[240] + pm_math_Vector3_dot_ra(xx + 578, xx + 33) + (xx[16] + xx[7]
    * (xx[205] * xx[18] - xx[30] * xx[247])) * xx[245] + xx[237] * (xx[17] -
    (xx[205] * xx[30] + xx[18] * xx[247]) * xx[7]);
  xx[16] = state[11] * state[11];
  xx[17] = xx[16] * (xx[260] - xx[49]);
  xx[18] = xx[196] * xx[17];
  xx[30] = xx[250] * xx[16];
  xx[16] = xx[196] * xx[30];
  xx[32] = xx[16] + xx[194] * xx[17];
  xx[33] = - xx[16];
  xx[34] = - xx[18];
  xx[35] = xx[32];
  pm_math_Vector3_cross_ra(xx + 547, xx + 33, xx + 89);
  xx[16] = xx[203] * state[9] * state[9];
  xx[17] = xx[7] * xx[202] * state[9] * state[9];
  xx[33] = state[9] * state[9];
  xx[34] = xx[7] * xx[249] * state[11] * state[9];
  xx[35] = xx[196] * xx[34];
  xx[71] = xx[402] * state[11] * state[9];
  xx[83] = xx[196] * xx[71];
  xx[92] = xx[35] - xx[194] * xx[71];
  xx[93] = - xx[35];
  xx[94] = xx[83];
  xx[95] = xx[92];
  pm_math_Vector3_cross_ra(xx + 547, xx + 93, xx + 96);
  xx[35] = xx[225] * state[11] * state[11];
  xx[71] = xx[7] * xx[195] * state[11] * state[11];
  xx[93] = state[17] * state[17];
  xx[94] = xx[93] * (xx[184] - xx[49]);
  xx[95] = xx[145] * xx[94];
  xx[111] = xx[183] * xx[93];
  xx[93] = xx[145] * xx[111];
  xx[163] = xx[93] + xx[143] * xx[94];
  xx[167] = - xx[93];
  xx[168] = - xx[95];
  xx[169] = xx[163];
  pm_math_Vector3_cross_ra(xx + 562, xx + 167, xx + 170);
  xx[93] = xx[154] * state[15] * state[15];
  xx[94] = xx[7] * xx[153] * state[15] * state[15];
  xx[153] = state[15] * state[15];
  xx[167] = xx[7] * xx[188] * state[17] * state[15];
  xx[168] = xx[145] * xx[167];
  xx[169] = xx[151] * state[17] * state[15];
  xx[151] = xx[145] * xx[169];
  xx[173] = xx[168] - xx[143] * xx[169];
  xx[216] = - xx[168];
  xx[217] = xx[151];
  xx[218] = xx[173];
  pm_math_Vector3_cross_ra(xx + 562, xx + 216, xx + 219);
  xx[168] = xx[176] * state[17] * state[17];
  xx[169] = xx[7] * xx[144] * state[17] * state[17];
  xx[216] = xx[27];
  xx[217] = xx[19] + xx[15] * xx[345];
  xx[218] = xx[28] - xx[15] * xx[197];
  pm_math_Quaternion_inverseXform_ra(xx + 599, xx + 216, xx + 222);
  xx[144] = (xx[15] * xx[143] * xx[143] + xx[15] * xx[145] * xx[145]) * xx[7];
  xx[174] = xx[132] - (xx[189] * xx[222] + xx[193] * xx[223] - xx[130] * xx[144]);
  xx[132] = xx[174] - xx[144];
  xx[144] = xx[223] + xx[60] * xx[174] + xx[9] + xx[185] * xx[132];
  xx[175] = xx[148] + xx[372] * xx[132] + xx[342] * (xx[144] - (xx[156] * (xx
    [222] + xx[104] - xx[183] * xx[132]) * xx[178] + xx[144] * xx[178] * xx[178])
    * xx[7]);
  xx[132] = xx[7] * xx[204] * state[9] * state[9];
  xx[89] = xx[7] * xx[155] * state[15] * state[15];
  xx[96] = xx[15] * xx[68];
  xx[144] = xx[15] * xx[70];
  xx[148] = (xx[96] * xx[68] + xx[144] * xx[70]) * xx[7];
  xx[155] = xx[148] - xx[15];
  xx[170] = xx[155] + xx[146];
  xx[180] = xx[7] * (xx[144] * xx[68] - xx[96] * xx[70]);
  xx[96] = xx[180] - xx[262];
  xx[144] = xx[124] * xx[96];
  xx[184] = xx[170] * xx[124];
  xx[216] = xx[155];
  xx[217] = xx[180];
  xx[218] = - xx[148];
  xx[222] = xx[27];
  xx[223] = xx[19] + xx[15] * xx[329];
  xx[224] = xx[28] - xx[15] * xx[72];
  pm_math_Quaternion_inverseXform_ra(xx + 625, xx + 222, xx + 227);
  xx[155] = xx[123] - (pm_math_Vector3_dot_ra(xx + 612, xx + 216) + xx[136] *
                       xx[227] + xx[142] * xx[228]);
  xx[123] = xx[155] - xx[148];
  xx[216] = xx[170] + xx[7] * (xx[79] * xx[144] - xx[184] * xx[124]);
  xx[217] = xx[96] - (xx[79] * xx[184] + xx[144] * xx[124]) * xx[7];
  xx[218] = xx[123];
  xx[96] = xx[227] + xx[316] - xx[127] * xx[123];
  xx[144] = xx[228] + xx[60] * xx[155] + xx[6] + xx[138] * xx[123];
  xx[123] = xx[144] * xx[124];
  xx[148] = xx[96] * xx[124];
  xx[170] = xx[117] + pm_math_Vector3_dot_ra(xx + 615, xx + 216) + (xx[96] + xx
    [7] * (xx[79] * xx[123] - xx[148] * xx[124])) * xx[122] + xx[113] * (xx[144]
    - (xx[79] * xx[148] + xx[123] * xx[124]) * xx[7]);
  xx[96] = xx[7] * xx[76] * state[19] * state[19];
  xx[76] = xx[77] * state[19] * state[19];
  xx[117] = xx[99] * state[21] * state[21];
  xx[123] = xx[7] * xx[69] * state[21] * state[21];
  xx[69] = state[21] * state[21];
  xx[144] = xx[69] * (xx[137] - xx[49]);
  xx[137] = xx[70] * xx[144];
  xx[148] = xx[127] * xx[69];
  xx[69] = xx[70] * xx[148];
  xx[180] = xx[69] + xx[68] * xx[144];
  xx[216] = xx[69];
  xx[217] = xx[137];
  xx[218] = - xx[180];
  pm_math_Vector3_cross_ra(xx + 570, xx + 216, xx + 222);
  xx[69] = state[19] * state[19];
  xx[144] = xx[7] * xx[126] * state[21] * state[19];
  xx[126] = xx[70] * xx[144];
  xx[184] = xx[271] * state[21] * state[19];
  xx[188] = xx[70] * xx[184];
  xx[195] = xx[68] * xx[184] - xx[126];
  xx[216] = xx[126];
  xx[217] = - xx[188];
  xx[218] = xx[195];
  pm_math_Vector3_cross_ra(xx + 570, xx + 216, xx + 227);
  xx[126] = xx[7] * xx[24] * state[25] * state[25];
  xx[24] = xx[25] * state[25] * state[25];
  xx[184] = xx[40] * state[27] * state[27];
  xx[202] = xx[7] * xx[37] * state[27] * state[27];
  xx[37] = state[27] * state[27];
  xx[204] = xx[37] * (xx[51] - xx[49]);
  xx[51] = xx[10] * xx[204];
  xx[206] = xx[50] * xx[37];
  xx[37] = xx[10] * xx[206];
  xx[209] = xx[37] + xx[5] * xx[204];
  xx[216] = xx[37];
  xx[217] = xx[51];
  xx[218] = - xx[209];
  pm_math_Vector3_cross_ra(xx + 541, xx + 216, xx + 253);
  xx[37] = state[25] * state[25];
  xx[204] = xx[7] * xx[56] * state[27] * state[25];
  xx[56] = xx[10] * xx[204];
  xx[211] = xx[212] * state[27] * state[25];
  xx[212] = xx[10] * xx[211];
  xx[214] = xx[5] * xx[211] - xx[56];
  xx[216] = xx[56];
  xx[217] = - xx[212];
  xx[218] = xx[214];
  pm_math_Vector3_cross_ra(xx + 541, xx + 216, xx + 292);
  xx[216] = xx[27];
  xx[217] = xx[19] + xx[15] * xx[276];
  xx[218] = xx[28] - xx[15] * xx[273];
  pm_math_Quaternion_inverseXform_ra(xx + 424, xx + 216, xx + 295);
  xx[19] = (xx[15] * xx[5] * xx[5] + xx[15] * xx[10] * xx[10]) * xx[7];
  xx[15] = xx[57] - (xx[65] * xx[295] + xx[67] * xx[296] - xx[420] * xx[19]);
  xx[27] = xx[15] - xx[19];
  xx[19] = xx[296] + xx[60] * xx[15] + xx[81] + xx[52] * xx[27];
  xx[28] = xx[215] + xx[372] * xx[27] + xx[342] * (xx[19] - (xx[38] * (xx[295] +
    xx[418] - xx[50] * xx[27]) * xx[43] + xx[19] * xx[43] * xx[43]) * xx[7]);
  xx[19] = xx[7] * xx[78] * state[19] * state[19];
  xx[27] = xx[7] * xx[26] * state[25] * state[25];
  xx[215] = xx[31] * xx[386] - ((xx[194] * xx[18] + xx[90]) * xx[7] - xx[30] -
    (xx[250] * xx[16] + xx[261] * xx[17] + xx[201] * xx[33]) + xx[7] * (xx[7] *
    (xx[97] - xx[194] * xx[83]) - xx[34]) - xx[49] * (xx[559] * (xx[413] * xx
    [437] + xx[403] * xx[437]) * state[9] * state[11] + xx[17] * xx[225] + xx
    [248] * xx[16] + xx[199] * xx[35] + xx[71] * xx[203]) - ((xx[143] * xx[95] +
    xx[171]) * xx[7] - xx[111] - (xx[183] * xx[93] + xx[185] * xx[94] + xx[341] *
    xx[153]) + xx[7] * (xx[7] * (xx[220] - xx[143] * xx[151]) - xx[167]) - xx[49]
    * (xx[559] * (xx[574] * xx[466] + xx[569] * xx[466]) * state[15] * state[17]
       + xx[94] * xx[176] + xx[179] * xx[93] + xx[150] * xx[168] + xx[169] * xx
       [154])) + xx[434] * xx[29]) + xx[467] * xx[174] - xx[175] * xx[575];
  xx[216] = xx[31] * xx[392] - (xx[266] * xx[33] - (xx[250] * xx[17] + xx[261] *
    xx[132]) + (xx[91] - xx[194] * xx[32]) * xx[7] + (xx[98] - xx[194] * xx[92])
    * xx[559] - (xx[132] * xx[225] + xx[248] * xx[17] + xx[192] * xx[35] + xx
                 [199] * xx[71] + xx[559] * (xx[413] * xx[403] - xx[437] * xx
    [437]) * state[9] * state[11]) * xx[49] - (xx[344] * xx[153] - (xx[183] *
    xx[94] + xx[185] * xx[89]) + (xx[172] - xx[143] * xx[163]) * xx[7] + (xx[221]
    - xx[143] * xx[173]) * xx[559] - (xx[89] * xx[176] + xx[179] * xx[94] + xx
    [139] * xx[168] + xx[150] * xx[169] + xx[559] * (xx[574] * xx[569] - xx[466]
    * xx[466]) * state[15] * state[17]) * xx[49]) + xx[397] * xx[29]) + xx[566] *
    xx[174] - xx[175] * xx[558];
  xx[217] = xx[170] * xx[607] - (xx[49] * (xx[559] * (xx[606] * xx[551] + xx[594]
    * xx[551]) * state[19] * state[21] - (xx[96] * xx[99] + xx[125] * xx[76] +
    xx[73] * xx[117] + xx[123] * xx[77])) + (xx[68] * xx[137] + xx[223]) * xx[7]
    - xx[148] - (xx[127] * xx[76] + xx[138] * xx[96] + xx[75] * xx[69]) + xx[7] *
    (xx[7] * (xx[228] - xx[68] * xx[188]) - xx[144]) - (xx[49] * (xx[559] * (xx
    [359] * xx[550] + xx[348] * xx[550]) * state[25] * state[27] - (xx[126] *
    xx[40] + xx[44] * xx[24] + xx[21] * xx[184] + xx[202] * xx[25])) + (xx[5] *
    xx[51] + xx[254]) * xx[7] - xx[206] - (xx[50] * xx[24] + xx[52] * xx[126] +
    xx[268] * xx[37]) + xx[7] * (xx[7] * (xx[293] - xx[5] * xx[212]) - xx[204]))
    + xx[568] * xx[155]) + xx[280] * xx[15] - xx[28] * xx[362];
  xx[218] = xx[170] * xx[567] - (xx[328] * xx[69] - (xx[127] * xx[96] + xx[138] *
    xx[19]) + (xx[224] - xx[68] * xx[180]) * xx[7] + (xx[68] * xx[195] + xx[229])
    * xx[559] - (xx[19] * xx[99] + xx[125] * xx[96] + xx[66] * xx[117] + xx[73] *
                 xx[123] + xx[559] * (xx[606] * xx[594] - xx[551] * xx[551]) *
                 state[19] * state[21]) * xx[49] - (xx[275] * xx[37] - (xx[50] *
    xx[126] + xx[52] * xx[27]) + (xx[255] - xx[5] * xx[209]) * xx[7] + (xx[5] *
    xx[214] + xx[294]) * xx[559] - (xx[27] * xx[40] + xx[44] * xx[126] + xx[3] *
    xx[184] + xx[21] * xx[202] + xx[559] * (xx[359] * xx[348] - xx[550] * xx[550])
    * state[25] * state[27]) * xx[49]) + xx[587] * xx[155]) + xx[552] * xx[15] -
    xx[28] * xx[256];
  memcpy(xx + 438, xx + 629, 16 * sizeof(double));
  factorAndSolveSymmetric(xx + 438, 4, xx + 24, ii + 0, xx + 215, xx + 15, xx +
    468);
  xx[3] = (xx[161] + xx[362] * xx[17] + xx[18] * xx[256]) / xx[576];
  xx[19] = xx[210] - xx[84] * xx[3];
  xx[21] = xx[43] * xx[19];
  xx[24] = xx[207] - (xx[38] * xx[21] + xx[252]) * xx[7];
  xx[25] = xx[19] + xx[7] * (xx[394] - xx[21] * xx[43]);
  xx[19] = xx[671] + xx[546] - xx[160] * xx[3] + xx[52] * xx[25] - xx[50] * xx
    [24] + xx[86];
  xx[21] = xx[25] + xx[545];
  xx[25] = (xx[422] - (xx[19] + xx[21] * xx[60]) - (xx[280] * xx[17] + xx[18] *
             xx[552])) / xx[64];
  xx[26] = xx[24] + xx[54] + xx[61] * xx[25];
  xx[27] = xx[21] + xx[39] * xx[25];
  xx[28] = xx[47];
  pm_math_Quaternion_xform_ra(xx + 424, xx + 26, xx + 29);
  xx[21] = xx[23] / xx[291];
  xx[23] = xx[704] + xx[1] + xx[291] * xx[21] + xx[421] + xx[573];
  xx[1] = (xx[607] * xx[17] + xx[18] * xx[567] - (xx[23] + xx[110])) / xx[121];
  xx[24] = xx[267] + xx[115] * xx[1];
  xx[26] = xx[114] + xx[120] * xx[1];
  xx[27] = xx[26] * xx[124];
  xx[28] = xx[24] * xx[124];
  xx[32] = xx[24] - (xx[79] * xx[27] + xx[28] * xx[124]) * xx[7];
  xx[24] = xx[26] + xx[7] * (xx[79] * xx[28] - xx[27] * xx[124]);
  xx[26] = xx[698] + xx[23] + xx[119] * xx[1] + xx[24] * xx[138] - xx[127] * xx
    [32] + xx[106];
  xx[23] = xx[24] + xx[107];
  xx[24] = (xx[58] - (xx[26] + xx[23] * xx[60]) + xx[568] * xx[17] + xx[18] *
            xx[587]) / xx[135];
  xx[33] = xx[32] + xx[20] + xx[140] * xx[24];
  xx[34] = xx[23] + xx[134] * xx[24];
  xx[35] = xx[80];
  pm_math_Quaternion_xform_ra(xx + 625, xx + 33, xx + 56);
  xx[17] = (xx[147] + xx[575] * xx[15] + xx[16] * xx[558]) / xx[576];
  xx[18] = xx[133] - xx[84] * xx[17];
  xx[20] = xx[178] * xx[18];
  xx[23] = xx[313] - (xx[156] * xx[20] + xx[272]) * xx[7];
  xx[27] = xx[18] + xx[7] * (xx[102] - xx[20] * xx[178]);
  xx[18] = xx[647] + xx[653] - xx[160] * xx[17] + xx[185] * xx[27] - xx[183] *
    xx[23] + xx[103];
  xx[20] = xx[27] + xx[308];
  xx[27] = (xx[190] - (xx[18] + xx[20] * xx[60]) - (xx[467] * xx[15] + xx[16] *
             xx[566])) / xx[187];
  xx[32] = xx[23] + xx[46] + xx[191] * xx[27];
  xx[33] = xx[20] + xx[157] * xx[27];
  xx[34] = xx[42];
  pm_math_Quaternion_xform_ra(xx + 599, xx + 32, xx + 75);
  xx[20] = xx[274] / xx[291];
  xx[23] = xx[597] + xx[2] + xx[291] * xx[20] + xx[326] + xx[389];
  xx[2] = (xx[386] * xx[15] + xx[16] * xx[392] - (xx[23] + xx[234])) / xx[244];
  xx[28] = xx[213] + xx[239] * xx[2];
  xx[32] = xx[238] + xx[243] * xx[2];
  xx[33] = xx[32] * xx[247];
  xx[34] = xx[28] * xx[247];
  xx[35] = xx[28] - (xx[205] * xx[33] + xx[34] * xx[247]) * xx[7];
  xx[28] = xx[32] + xx[7] * (xx[205] * xx[34] - xx[33] * xx[247]);
  xx[32] = xx[686] + xx[23] + xx[242] * xx[2] + xx[28] * xx[261] - xx[250] * xx
    [35] + xx[149];
  xx[23] = xx[28] + xx[226];
  xx[28] = (xx[59] - (xx[32] + xx[23] * xx[60]) + xx[434] * xx[15] + xx[16] *
            xx[397]) / xx[258];
  xx[89] = xx[35] + xx[22] + xx[263] * xx[28];
  xx[90] = xx[23] + xx[257] * xx[28];
  xx[91] = xx[36];
  pm_math_Quaternion_xform_ra(xx + 589, xx + 89, xx + 33);
  xx[89] = xx[87];
  xx[90] = xx[165];
  xx[91] = xx[19] + xx[41] * xx[25];
  pm_math_Quaternion_xform_ra(xx + 424, xx + 89, xx + 39);
  pm_math_Vector3_cross_ra(xx + 277, xx + 29, xx + 40);
  xx[15] = xx[343] - xx[309] * xx[1];
  xx[16] = xx[374] + xx[317] * xx[1];
  xx[19] = xx[16] * xx[124];
  xx[22] = xx[124] * xx[15];
  xx[89] = xx[696] + xx[15] - (xx[79] * xx[19] + xx[22] * xx[124]) * xx[7] + xx
    [4] + xx[55] + xx[327] * xx[24];
  xx[90] = xx[697] + xx[16] + xx[7] * (xx[79] * xx[22] - xx[19] * xx[124]) - xx
    [128] + xx[131] + xx[320] * xx[24];
  xx[91] = xx[26] + xx[118] * xx[24];
  pm_math_Quaternion_xform_ra(xx + 625, xx + 89, xx + 92);
  pm_math_Vector3_cross_ra(xx + 336, xx + 56, xx + 89);
  xx[93] = xx[105];
  xx[94] = xx[116];
  xx[95] = xx[18] + xx[63] * xx[27];
  pm_math_Quaternion_xform_ra(xx + 599, xx + 93, xx + 96);
  pm_math_Vector3_cross_ra(xx + 365, xx + 75, xx + 93);
  xx[4] = xx[177] + xx[370] * xx[2];
  xx[15] = xx[182] - xx[395] * xx[2];
  xx[16] = xx[15] * xx[247];
  xx[18] = xx[247] * xx[4];
  xx[97] = xx[684] + xx[4] - (xx[205] * xx[16] + xx[18] * xx[247]) * xx[7] + xx
    [101] + xx[141] + xx[405] * xx[28];
  xx[98] = xx[685] + xx[15] + xx[7] * (xx[205] * xx[18] - xx[16] * xx[247]) -
    xx[230] + xx[231] + xx[398] * xx[28];
  xx[99] = xx[32] + xx[241] * xx[28];
  pm_math_Quaternion_xform_ra(xx + 589, xx + 97, xx + 101);
  pm_math_Vector3_cross_ra(xx + 414, xx + 33, xx + 97);
  xx[4] = xx[30] + xx[57] + xx[76] + xx[34] + xx[74];
  xx[15] = (xx[39] + xx[40] + xx[92] + xx[89] + xx[96] + xx[93] + xx[101] + xx
            [97] + xx[62] + xx[4] * xx[82]) / xx[162];
  xx[39] = xx[29] + xx[56] + xx[75] + xx[33] + xx[152] - xx[159] * xx[15];
  xx[40] = xx[4] - xx[85] * xx[15];
  xx[41] = xx[31] + xx[58] + xx[77] + xx[35] + xx[186] - xx[88] * xx[15];
  pm_math_Quaternion_xform_ra(xx + 282, xx + 39, xx + 29);
  xx[32] = - xx[29];
  xx[33] = - xx[30];
  xx[34] = - xx[31];
  solveSymmetricPosDef(xx + 532, xx + 32, 3, 1, xx + 29, xx + 35);
  xx[4] = xx[29] + xx[12];
  xx[12] = xx[30] + xx[13];
  xx[13] = xx[31] + xx[14];
  xx[29] = xx[4] - xx[100];
  xx[30] = xx[12];
  xx[31] = xx[13] - xx[11];
  pm_math_Quaternion_inverseXform_ra(xx + 282, xx + 29, xx + 32);
  xx[11] = xx[15] + pm_math_Vector3_dot_ra(xx + 583, xx + 32);
  xx[14] = xx[11] * xx[194];
  xx[15] = xx[11] * xx[196];
  xx[16] = (xx[14] * xx[194] + xx[15] * xx[196]) * xx[7];
  xx[18] = xx[16] - xx[11];
  xx[19] = xx[7] * (xx[15] * xx[194] - xx[14] * xx[196]);
  xx[29] = xx[18];
  xx[30] = xx[19];
  xx[31] = - xx[16];
  xx[14] = xx[33] - xx[11] * xx[82];
  xx[15] = xx[34] + xx[8];
  xx[33] = xx[32];
  xx[34] = xx[14] + xx[11] * xx[406];
  xx[35] = xx[15] - xx[11] * xx[198];
  pm_math_Quaternion_inverseXform_ra(xx + 589, xx + 33, xx + 39);
  xx[8] = xx[28] - (pm_math_Vector3_dot_ra(xx + 553, xx + 29) + xx[259] * xx[39]
                    + xx[265] * xx[40]);
  xx[22] = xx[18] + xx[181];
  xx[18] = xx[19] - xx[208];
  xx[19] = xx[247] * xx[18];
  xx[23] = xx[22] * xx[247];
  xx[26] = xx[8] - xx[16];
  xx[28] = xx[22] + xx[7] * (xx[205] * xx[19] - xx[23] * xx[247]);
  xx[29] = xx[18] - (xx[205] * xx[23] + xx[19] * xx[247]) * xx[7];
  xx[30] = xx[26];
  xx[16] = xx[39] + xx[269] - xx[250] * xx[26];
  xx[18] = xx[40] + xx[60] * xx[8] + xx[45] + xx[261] * xx[26];
  xx[19] = xx[18] * xx[247];
  xx[22] = xx[16] * xx[247];
  xx[23] = xx[2] - (pm_math_Vector3_dot_ra(xx + 578, xx + 28) + (xx[16] + xx[7] *
    (xx[205] * xx[19] - xx[22] * xx[247])) * xx[245] + xx[237] * (xx[18] - (xx
    [205] * xx[22] + xx[19] * xx[247]) * xx[7]));
  xx[2] = xx[26] + xx[23];
  xx[28] = xx[32];
  xx[29] = xx[14] + xx[11] * xx[345];
  xx[30] = xx[15] - xx[11] * xx[197];
  pm_math_Quaternion_inverseXform_ra(xx + 599, xx + 28, xx + 33);
  xx[16] = xx[11] * xx[143];
  xx[18] = xx[11] * xx[145];
  xx[19] = (xx[16] * xx[143] + xx[18] * xx[145]) * xx[7];
  xx[22] = xx[27] - (xx[189] * xx[33] + xx[193] * xx[34] - xx[130] * xx[19]);
  xx[26] = xx[22] - xx[19];
  xx[27] = xx[34] + xx[60] * xx[22] + xx[9] + xx[185] * xx[26];
  xx[9] = xx[17] + xx[372] * xx[26] + xx[342] * (xx[27] - (xx[156] * (xx[33] +
    xx[104] - xx[183] * xx[26]) * xx[178] + xx[27] * xx[178] * xx[178]) * xx[7]);
  xx[17] = xx[11] * xx[68];
  xx[27] = xx[11] * xx[70];
  xx[28] = (xx[17] * xx[68] + xx[27] * xx[70]) * xx[7];
  xx[29] = xx[28] - xx[11];
  xx[30] = xx[7] * (xx[27] * xx[68] - xx[17] * xx[70]);
  xx[33] = xx[29];
  xx[34] = xx[30];
  xx[35] = - xx[28];
  xx[39] = xx[32];
  xx[40] = xx[14] + xx[11] * xx[329];
  xx[41] = xx[15] - xx[11] * xx[72];
  pm_math_Quaternion_inverseXform_ra(xx + 625, xx + 39, xx + 44);
  xx[17] = xx[24] - (pm_math_Vector3_dot_ra(xx + 612, xx + 33) + xx[136] * xx[44]
                     + xx[142] * xx[45]);
  xx[24] = xx[29] + xx[146];
  xx[27] = xx[30] - xx[262];
  xx[29] = xx[124] * xx[27];
  xx[30] = xx[24] * xx[124];
  xx[31] = xx[17] - xx[28];
  xx[33] = xx[24] + xx[7] * (xx[79] * xx[29] - xx[30] * xx[124]);
  xx[34] = xx[27] - (xx[79] * xx[30] + xx[29] * xx[124]) * xx[7];
  xx[35] = xx[31];
  xx[24] = xx[44] + xx[316] - xx[127] * xx[31];
  xx[27] = xx[45] + xx[60] * xx[17] + xx[6] + xx[138] * xx[31];
  xx[6] = xx[27] * xx[124];
  xx[28] = xx[24] * xx[124];
  xx[29] = xx[1] - (pm_math_Vector3_dot_ra(xx + 615, xx + 33) + (xx[24] + xx[7] *
    (xx[79] * xx[6] - xx[28] * xx[124])) * xx[122] + xx[113] * (xx[27] - (xx[79]
    * xx[28] + xx[6] * xx[124]) * xx[7]));
  xx[1] = xx[31] + xx[29];
  xx[33] = xx[32];
  xx[34] = xx[14] + xx[11] * xx[276];
  xx[35] = xx[15] - xx[11] * xx[273];
  pm_math_Quaternion_inverseXform_ra(xx + 424, xx + 33, xx + 30);
  xx[6] = xx[11] * xx[5];
  xx[14] = xx[11] * xx[10];
  xx[15] = (xx[6] * xx[5] + xx[14] * xx[10]) * xx[7];
  xx[24] = xx[25] - (xx[65] * xx[30] + xx[67] * xx[31] - xx[420] * xx[15]);
  xx[25] = xx[24] - xx[15];
  xx[27] = xx[31] + xx[60] * xx[24] + xx[81] + xx[52] * xx[25];
  xx[28] = xx[3] + xx[372] * xx[25] + xx[342] * (xx[27] - (xx[38] * (xx[30] +
    xx[418] - xx[50] * xx[25]) * xx[43] + xx[27] * xx[43] * xx[43]) * xx[7]);
  xx[30] = xx[466];
  xx[31] = xx[574];
  xx[32] = xx[466];
  xx[33] = xx[569];
  xx[34] = xx[437];
  xx[35] = xx[413];
  xx[36] = xx[437];
  xx[37] = xx[403];
  pm_math_Quaternion_inverseCompose_ra(xx + 30, xx + 34, xx + 39);
  pm_math_Quaternion_inverseXform_ra(xx + 39, xx + 621, xx + 30);
  xx[3] = xx[19] - xx[11] + xx[112];
  xx[19] = xx[7] * (xx[18] * xx[143] - xx[16] * xx[145]) - xx[108];
  xx[16] = xx[178] * xx[19];
  xx[18] = xx[3] * xx[178];
  xx[33] = xx[3] + xx[7] * (xx[156] * xx[16] - xx[18] * xx[178]) + xx[109];
  xx[34] = xx[19] - (xx[156] * xx[18] + xx[16] * xx[178]) * xx[7] - xx[129];
  xx[35] = xx[26] - xx[9];
  pm_math_Quaternion_inverseXform_ra(xx + 39, xx + 33, xx + 44);
  xx[33] = xx[550];
  xx[34] = - xx[359];
  xx[35] = xx[550];
  xx[36] = - xx[348];
  xx[49] = xx[551];
  xx[50] = - xx[606];
  xx[51] = xx[551];
  xx[52] = - xx[594];
  pm_math_Quaternion_inverseCompose_ra(xx + 33, xx + 49, xx + 54);
  pm_math_Quaternion_inverseXform_ra(xx + 54, xx + 286, xx + 33);
  xx[3] = xx[15] - xx[11] + xx[200];
  xx[15] = xx[7] * (xx[14] * xx[5] - xx[6] * xx[10]) - xx[158];
  xx[5] = xx[43] * xx[15];
  xx[6] = xx[3] * xx[43];
  xx[49] = xx[3] + xx[7] * (xx[38] * xx[5] - xx[6] * xx[43]) + xx[164];
  xx[50] = xx[15] - (xx[38] * xx[6] + xx[5] * xx[43]) * xx[7] - xx[166];
  xx[51] = xx[25] - xx[28];
  pm_math_Quaternion_inverseXform_ra(xx + 54, xx + 49, xx + 14);
  logVector[0] = state[0];
  logVector[1] = state[1];
  logVector[2] = state[2];
  logVector[3] = state[3];
  logVector[4] = state[4];
  logVector[5] = state[5];
  logVector[6] = xx[0] * state[6];
  logVector[7] = xx[0] * state[7];
  logVector[8] = xx[0] * state[8];
  logVector[9] = xx[0] * state[9];
  logVector[10] = xx[0] * state[10];
  logVector[11] = xx[0] * state[11];
  logVector[12] = xx[0] * state[12];
  logVector[13] = xx[0] * state[13];
  logVector[14] = xx[0] * state[14];
  logVector[15] = xx[0] * state[15];
  logVector[16] = xx[0] * state[16];
  logVector[17] = xx[0] * state[17];
  logVector[18] = xx[0] * state[18];
  logVector[19] = xx[0] * state[19];
  logVector[20] = xx[0] * state[20];
  logVector[21] = xx[0] * state[21];
  logVector[22] = xx[0] * state[22];
  logVector[23] = xx[0] * state[23];
  logVector[24] = xx[0] * state[24];
  logVector[25] = xx[0] * state[25];
  logVector[26] = xx[0] * state[26];
  logVector[27] = xx[0] * state[27];
  logVector[28] = xx[4];
  logVector[29] = xx[12];
  logVector[30] = xx[13];
  logVector[31] = - (xx[11] * xx[0]);
  logVector[32] = xx[0] * xx[8];
  logVector[33] = xx[0] * xx[23];
  logVector[34] = xx[0] * (xx[20] - xx[2]);
  logVector[35] = xx[0] * xx[22];
  logVector[36] = - (xx[9] * xx[0]);
  logVector[37] = xx[0] * xx[17];
  logVector[38] = xx[0] * xx[29];
  logVector[39] = xx[0] * (xx[21] - xx[1]);
  logVector[40] = xx[0] * xx[24];
  logVector[41] = - (xx[28] * xx[0]);
  logVector[42] = (state[28] + sm_core_canonicalAngle(xx[7] * atan2(sqrt(xx[40] *
    xx[40] + xx[41] * xx[41] + xx[42] * xx[42]), fabs(xx[39])) * ((xx[39] * xx
    [42]) < 0.0 ? -1.0 : +1.0) - state[28])) * xx[0];
  logVector[43] = xx[0] * (xx[48] - xx[32]);
  logVector[44] = xx[0] * (xx[2] - xx[46]);
  logVector[45] = (state[30] + sm_core_canonicalAngle(xx[7] * atan2(sqrt(xx[55] *
    xx[55] + xx[56] * xx[56] + xx[57] * xx[57]), fabs(xx[54])) * ((xx[54] * xx
    [57]) < 0.0 ? -1.0 : +1.0) - state[30])) * xx[0];
  logVector[46] = xx[0] * (xx[53] - xx[35]);
  logVector[47] = xx[0] * (xx[1] - xx[16]);
  errorResult[0] = xx[307];
  return NULL;
}
