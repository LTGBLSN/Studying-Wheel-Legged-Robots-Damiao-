/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'blance_leg/blance_leg_model/Solver Configuration1'.
 */

#ifndef __blance_leg_1d80934b_1_h__
#define __blance_leg_1d80934b_1_h__
#ifdef __cplusplus

extern "C"
{

#endif

  extern void blance_leg_1d80934b_1_dae( NeDae **dae, const NeModelParameters
    *modelParams,
    const NeSolverParameters *solverParams);

#ifdef __cplusplus

}

#endif
#endif
