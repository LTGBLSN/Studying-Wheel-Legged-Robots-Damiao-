/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'blance_leg/blance_leg_model/Solver Configuration1'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"

const sm_core_compiler_ConvexPolyhedron *blance_leg_1d80934b_1_geometry_0(const
  RuntimeDerivedValuesBundle *rtdv)
{
  static const double hull_points[18] = { 1.73, 0.0,
    0.5, 0.0, 0.5,
    0.5, 0.0, 0.0,
    0.5, 1.73, 0.0,
    -0.5, 0.0, 0.5,
    -0.5, 0.0, 0.0,
    -0.5 };

  static const int vx_index[6] = { 0, 3,
    7, 12, 17,
    21 };

  static const int vx_valency[6] = { 3, 4,
    5, 5, 4,
    3 };

  static const int vx_adjacency_graph[24] = { 1, 2,
    3, 2, 0,
    3, 4, 0,
    1, 4, 5,
    3, 0, 2,
    5, 4, 1,
    1, 3, 5,
    2, 2, 4,
    3 };

  static const int seed_vx_ids[8] = { 0, 1,
    2, 0, 3,
    4, 5, 3 };

  static sm_core_compiler_ConvexPolyhedron cxh;
  cxh.hullPoints = hull_points;
  cxh.vxIndex = vx_index;
  cxh.vxValency = vx_valency;
  cxh.numHullPoints = 6;
  cxh.vxAdjacencyGraph = vx_adjacency_graph;
  cxh.graphSize = 24;
  cxh.seedVxIds = seed_vx_ids;
  cxh.diagonalAABB = 2.059830090080248;
  (void) rtdv;
  return &cxh;
}

const sm_core_compiler_Cylinder *blance_leg_1d80934b_1_geometry_1(const
  RuntimeDerivedValuesBundle *rtdv)
{
  static const sm_core_compiler_Cylinder cylinder = { 0.08599999999999999, 0.04
  };

  (void) rtdv;
  return &cylinder;
}

const sm_core_compiler_Brick *blance_leg_1d80934b_1_geometry_2(const
  RuntimeDerivedValuesBundle *rtdv)
{
  static const sm_core_compiler_Brick brick = { 1.0, 30.0, 0.01 };

  (void) rtdv;
  return &brick;
}

void blance_leg_1d80934b_1_initializeGeometries(const struct
  RuntimeDerivedValuesBundleTag *rtdv)
{
  blance_leg_1d80934b_1_geometry_0(rtdv);
  blance_leg_1d80934b_1_geometry_1(rtdv);
  blance_leg_1d80934b_1_geometry_2(rtdv);
}
