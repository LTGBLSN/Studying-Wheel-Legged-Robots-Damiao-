/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'blance_leg/blance_leg_model/Solver Configuration1'.
 */

const sm_core_compiler_ConvexPolyhedron *blance_leg_1d80934b_1_geometry_0(const
  RuntimeDerivedValuesBundle *rtdv);
const sm_core_compiler_Cylinder *blance_leg_1d80934b_1_geometry_1(const
  RuntimeDerivedValuesBundle *rtdv);
const sm_core_compiler_Brick *blance_leg_1d80934b_1_geometry_2(const
  RuntimeDerivedValuesBundle *rtdv);
struct RuntimeDerivedValuesBundleTag;
void blance_leg_1d80934b_1_initializeGeometries(const struct
  RuntimeDerivedValuesBundleTag *rtdv);
