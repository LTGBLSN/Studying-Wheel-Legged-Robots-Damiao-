/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'blance_leg/blance_leg_model/Solver Configuration1'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"

void blance_leg_1d80934b_1_validateRuntimeParameters(const double *rtp, int32_T *
  satFlags)
{
  (void) rtp;
  (void) satFlags;
}

const NeAssertData *blance_leg_1d80934b_1_assertData = NULL;
