/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'blance_leg/blance_leg_model/Solver Configuration1'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"
#include "blance_leg_1d80934b_1_geometries.h"

PmfMessageId blance_leg_1d80934b_1_compDerivs(const RuntimeDerivedValuesBundle
  *rtdv, const int *eqnEnableFlags, const double *state, const int *modeVector,
  const double *input, const double *inputDot, const double *inputDdot, const
  double *discreteState, double *deriv, double *errorResult,
  NeuDiagnosticManager *neDiagMgr)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  boolean_T bb[1];
  int ii[4];
  double xx[733];
  (void) rtdvd;
  (void) rtdvi;
  (void) eqnEnableFlags;
  (void) modeVector;
  (void) inputDot;
  (void) inputDdot;
  (void) discreteState;
  (void) neDiagMgr;
  xx[0] = 0.7071067811865476;
  xx[1] = 0.5;
  xx[2] = xx[1] * state[6];
  xx[3] = xx[0] * cos(xx[2]);
  xx[4] = xx[3] * xx[3];
  xx[5] = xx[0] * sin(xx[2]);
  xx[2] = xx[5] * xx[5];
  xx[6] = 2.0;
  xx[7] = 1.0;
  xx[8] = (xx[4] + xx[2]) * xx[6] - xx[7];
  xx[9] = xx[3] * xx[5];
  xx[10] = xx[8];
  xx[11] = - ((xx[9] + xx[9]) * xx[6]);
  xx[12] = xx[6] * (xx[2] - xx[4]);
  xx[13] = xx[6] * (xx[9] - xx[9]);
  xx[14] = (xx[4] + xx[4]) * xx[6] - xx[7];
  xx[15] = - ((xx[9] + xx[9]) * xx[6]);
  xx[16] = (xx[2] + xx[4]) * xx[6];
  xx[17] = xx[6] * (xx[9] - xx[9]);
  xx[18] = xx[8];
  xx[2] = xx[1] * state[24];
  xx[4] = xx[0] * cos(xx[2]);
  xx[8] = xx[4] * xx[4];
  xx[9] = xx[0] * sin(xx[2]);
  xx[2] = xx[9] * xx[9];
  xx[19] = (xx[8] + xx[2]) * xx[6] - xx[7];
  xx[20] = xx[4] * xx[9];
  xx[21] = xx[6] * (xx[20] - xx[20]);
  xx[22] = (xx[2] + xx[8]) * xx[6];
  xx[23] = xx[20] + xx[20];
  xx[20] = xx[23] * xx[6];
  xx[24] = (xx[8] + xx[8]) * xx[6] - xx[7];
  xx[25] = xx[2] - xx[8];
  xx[2] = xx[6] * xx[25];
  xx[26] = xx[19];
  xx[27] = xx[21];
  xx[28] = xx[22];
  xx[29] = xx[20];
  xx[30] = xx[24];
  xx[31] = xx[21];
  xx[32] = xx[2];
  xx[33] = xx[20];
  xx[34] = xx[19];
  xx[8] = 0.135;
  xx[35] = 0.375;
  xx[36] = xx[1] * state[26];
  xx[37] = cos(xx[36]);
  xx[38] = xx[37] * xx[37];
  xx[39] = xx[6] * xx[38] - xx[7];
  xx[40] = xx[35] * xx[39];
  xx[41] = 0.09386245501799279;
  xx[42] = sin(xx[36]);
  xx[36] = xx[37] * xx[42];
  xx[43] = xx[6] * xx[36];
  xx[44] = xx[41] * xx[43];
  xx[45] = xx[40] * xx[39] + xx[44] * xx[43];
  xx[46] = xx[8] + xx[45];
  xx[47] = 0.2;
  xx[48] = 0.125;
  xx[49] = xx[48] * xx[42];
  xx[50] = xx[6] * xx[49] * xx[42];
  xx[51] = xx[47] - xx[50];
  xx[52] = xx[35] * xx[43];
  xx[53] = xx[41] * xx[39];
  xx[54] = xx[52] * xx[39] - xx[53] * xx[43];
  xx[55] = xx[37] * xx[49];
  xx[49] = xx[6] * xx[55];
  xx[56] = xx[51] * xx[54] - xx[45] * xx[49];
  xx[45] = 0.0117328068772491;
  xx[57] = (xx[38] + xx[42] * xx[42]) * xx[6] - xx[7];
  xx[38] = xx[45] * xx[43] * xx[57];
  xx[58] = xx[56] + xx[38];
  xx[59] = 0.075;
  xx[60] = xx[58] + xx[59] * xx[54];
  xx[61] = 2.5425e-4;
  xx[62] = 1.466600859656138e-3;
  xx[63] = xx[45] * xx[39] * xx[57];
  xx[64] = xx[49] * xx[38] + xx[51] * xx[63];
  xx[38] = xx[52] * xx[43] + xx[53] * xx[39];
  xx[52] = xx[40] * xx[43] - xx[44] * xx[39];
  xx[40] = xx[38] * xx[51] - xx[49] * xx[52];
  xx[44] = xx[61] + xx[62] * xx[57] * xx[57] - xx[64] - xx[64] + xx[51] * xx[40]
    - xx[56] * xx[49];
  xx[53] = xx[40] - xx[63];
  xx[40] = xx[44] + xx[53] * xx[59];
  xx[56] = xx[8] + xx[38];
  xx[38] = xx[53] + xx[56] * xx[59];
  xx[63] = xx[40] + xx[38] * xx[59];
  ii[0] = factorSymmetricPosDef(xx + 63, 1, xx + 64);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "sm:compiler:messages:simulationErrors:DegenerateMass",
      "'blance_leg/blance_leg_model/right joint 4' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[64] = xx[60] / xx[63];
  xx[65] = xx[46] - xx[60] * xx[64];
  xx[66] = xx[38] * xx[64];
  xx[67] = xx[54] - xx[66];
  xx[68] = xx[52] - xx[66];
  xx[66] = xx[38] / xx[63];
  xx[69] = xx[56] - xx[38] * xx[66];
  xx[70] = xx[35] * xx[57] * xx[57];
  xx[57] = xx[8] + xx[70];
  xx[71] = xx[65] * xx[19] + xx[21] * xx[67];
  xx[72] = xx[20] * xx[65] + xx[24] * xx[67];
  xx[73] = xx[2] * xx[65] + xx[20] * xx[67];
  xx[74] = xx[19] * xx[68] + xx[21] * xx[69];
  xx[75] = xx[20] * xx[68] + xx[69] * xx[24];
  xx[76] = xx[2] * xx[68] + xx[20] * xx[69];
  xx[77] = xx[57] * xx[22];
  xx[78] = xx[57] * xx[21];
  xx[79] = xx[57] * xx[19];
  pm_math_Matrix3x3_compose_ra(xx + 26, xx + 71, xx + 80);
  xx[65] = xx[1] * state[18];
  xx[67] = xx[0] * cos(xx[65]);
  xx[68] = xx[67] * xx[67];
  xx[69] = xx[0] * sin(xx[65]);
  xx[65] = xx[69] * xx[69];
  xx[71] = (xx[68] + xx[65]) * xx[6] - xx[7];
  xx[72] = xx[67] * xx[69];
  xx[73] = xx[6] * (xx[72] - xx[72]);
  xx[74] = (xx[65] + xx[68]) * xx[6];
  xx[75] = xx[72] + xx[72];
  xx[72] = xx[75] * xx[6];
  xx[76] = (xx[68] + xx[68]) * xx[6] - xx[7];
  xx[77] = xx[65] - xx[68];
  xx[65] = xx[6] * xx[77];
  xx[89] = xx[71];
  xx[90] = xx[73];
  xx[91] = xx[74];
  xx[92] = xx[72];
  xx[93] = xx[76];
  xx[94] = xx[73];
  xx[95] = xx[65];
  xx[96] = xx[72];
  xx[97] = xx[71];
  xx[68] = xx[1] * state[20];
  xx[78] = cos(xx[68]);
  xx[79] = xx[78] * xx[78];
  xx[98] = xx[6] * xx[79] - xx[7];
  xx[99] = 0.465;
  xx[100] = 1.18;
  xx[101] = xx[1] * state[22];
  xx[102] = cos(xx[101]);
  xx[103] = xx[102] * xx[102];
  xx[104] = xx[6] * xx[103] - xx[7];
  xx[105] = xx[100] * xx[104];
  xx[106] = xx[105] * xx[104];
  xx[107] = sin(xx[101]);
  xx[101] = xx[6] * xx[102] * xx[107];
  xx[108] = xx[100] * xx[101];
  xx[109] = xx[108] * xx[101];
  xx[110] = xx[106] + xx[109];
  xx[111] = xx[99] + xx[110];
  xx[112] = xx[108] * xx[104];
  xx[108] = xx[105] * xx[101];
  xx[105] = xx[112] - xx[108];
  xx[113] = xx[48] * xx[105];
  xx[114] = xx[113] + xx[113];
  xx[115] = 2.42575e-3;
  xx[116] = xx[109] + xx[106];
  xx[106] = xx[116] * xx[48];
  xx[109] = xx[48] * xx[106];
  xx[117] = xx[115] + xx[109];
  xx[118] = xx[117] + xx[109];
  xx[109] = xx[99] + xx[116];
  xx[119] = xx[106] + xx[109] * xx[48];
  xx[120] = xx[118] + xx[119] * xx[48];
  ii[0] = factorSymmetricPosDef(xx + 120, 1, xx + 121);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "sm:compiler:messages:simulationErrors:DegenerateMass",
      "'blance_leg/blance_leg_model/Revolute Joint6' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[121] = xx[114] / xx[120];
  xx[122] = xx[111] - xx[114] * xx[121];
  xx[123] = sin(xx[68]);
  xx[68] = xx[78] * xx[123];
  xx[124] = xx[6] * xx[68];
  xx[125] = xx[119] * xx[121];
  xx[126] = xx[105] - xx[125];
  xx[127] = xx[122] * xx[98] - xx[124] * xx[126];
  xx[128] = xx[108] - xx[112];
  xx[108] = xx[128] - xx[125];
  xx[112] = xx[119] / xx[120];
  xx[125] = xx[109] - xx[119] * xx[112];
  xx[129] = xx[98] * xx[108] - xx[124] * xx[125];
  xx[130] = xx[98] * xx[127] - xx[124] * xx[129];
  xx[131] = xx[8] + xx[130];
  xx[132] = (xx[79] + xx[123] * xx[123]) * xx[6] - xx[7];
  xx[79] = xx[113] - xx[118] * xx[121];
  xx[133] = xx[106] - xx[118] * xx[112];
  xx[134] = xx[132] * (xx[79] * xx[98] - xx[124] * xx[133]);
  xx[135] = xx[48] * xx[123];
  xx[136] = xx[6] * xx[135] * xx[123];
  xx[137] = xx[47] - xx[136];
  xx[138] = xx[124] * xx[122] + xx[98] * xx[126];
  xx[122] = xx[124] * xx[108] + xx[125] * xx[98];
  xx[108] = xx[138] * xx[98] - xx[122] * xx[124];
  xx[125] = xx[78] * xx[135];
  xx[126] = xx[6] * xx[125];
  xx[135] = xx[137] * xx[108] - xx[126] * xx[130];
  xx[130] = xx[134] + xx[135];
  xx[139] = xx[130] + xx[59] * xx[108];
  xx[140] = xx[118] / xx[120];
  xx[141] = (xx[124] * xx[79] + xx[133] * xx[98]) * xx[132];
  xx[79] = xx[137] * xx[141] - xx[126] * xx[134];
  xx[133] = xx[138] * xx[124] + xx[122] * xx[98];
  xx[122] = xx[124] * xx[127] + xx[98] * xx[129];
  xx[127] = xx[133] * xx[137] - xx[122] * xx[126];
  xx[129] = xx[61] + (xx[117] - xx[118] * xx[140]) * xx[132] * xx[132] + xx[79]
    + xx[79] + xx[127] * xx[137] - xx[135] * xx[126];
  xx[79] = xx[141] + xx[127];
  xx[117] = xx[129] + xx[79] * xx[59];
  xx[127] = xx[8] + xx[133];
  xx[133] = xx[79] + xx[127] * xx[59];
  xx[134] = xx[117] + xx[133] * xx[59];
  ii[0] = factorSymmetricPosDef(xx + 134, 1, xx + 135);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "sm:compiler:messages:simulationErrors:DegenerateMass",
      "'blance_leg/blance_leg_model/right joint1' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[135] = xx[139] / xx[134];
  xx[138] = xx[131] - xx[139] * xx[135];
  xx[141] = xx[133] * xx[135];
  xx[142] = xx[108] - xx[141];
  xx[143] = xx[122] - xx[141];
  xx[141] = xx[133] / xx[134];
  xx[144] = xx[127] - xx[133] * xx[141];
  xx[145] = (xx[103] + xx[107] * xx[107]) * xx[6] - xx[7];
  xx[103] = xx[100] * xx[145] * xx[145];
  xx[145] = xx[99] + xx[103];
  xx[146] = xx[145] * xx[132] * xx[132];
  xx[147] = xx[8] + xx[146];
  xx[148] = xx[138] * xx[71] + xx[73] * xx[142];
  xx[149] = xx[72] * xx[138] + xx[76] * xx[142];
  xx[150] = xx[65] * xx[138] + xx[72] * xx[142];
  xx[151] = xx[143] * xx[71] + xx[73] * xx[144];
  xx[152] = xx[72] * xx[143] + xx[144] * xx[76];
  xx[153] = xx[65] * xx[143] + xx[72] * xx[144];
  xx[154] = xx[147] * xx[74];
  xx[155] = xx[147] * xx[73];
  xx[156] = xx[147] * xx[71];
  pm_math_Matrix3x3_compose_ra(xx + 89, xx + 148, xx + 157);
  xx[138] = xx[1] * state[14];
  xx[142] = xx[0] * cos(xx[138]);
  xx[143] = xx[142] * xx[142];
  xx[144] = xx[0] * sin(xx[138]);
  xx[138] = xx[144] * xx[144];
  xx[148] = (xx[143] + xx[138]) * xx[6] - xx[7];
  xx[149] = xx[142] * xx[144];
  xx[150] = xx[6] * (xx[149] - xx[149]);
  xx[151] = (xx[138] + xx[143]) * xx[6];
  xx[152] = xx[149] + xx[149];
  xx[149] = xx[152] * xx[6];
  xx[153] = (xx[143] + xx[143]) * xx[6] - xx[7];
  xx[154] = xx[138] - xx[143];
  xx[138] = xx[6] * xx[154];
  xx[166] = xx[148];
  xx[167] = xx[150];
  xx[168] = xx[151];
  xx[169] = xx[149];
  xx[170] = xx[153];
  xx[171] = xx[150];
  xx[172] = xx[138];
  xx[173] = xx[149];
  xx[174] = xx[148];
  xx[143] = xx[1] * state[16];
  xx[155] = cos(xx[143]);
  xx[156] = xx[155] * xx[155];
  xx[175] = xx[6] * xx[156] - xx[7];
  xx[176] = xx[35] * xx[175];
  xx[177] = sin(xx[143]);
  xx[143] = xx[155] * xx[177];
  xx[178] = xx[6] * xx[143];
  xx[179] = xx[41] * xx[178];
  xx[180] = xx[176] * xx[175] + xx[179] * xx[178];
  xx[181] = xx[8] + xx[180];
  xx[182] = xx[48] * xx[177];
  xx[183] = xx[6] * xx[182] * xx[177];
  xx[184] = xx[47] - xx[183];
  xx[185] = xx[35] * xx[178];
  xx[186] = xx[41] * xx[175];
  xx[41] = xx[185] * xx[175] - xx[186] * xx[178];
  xx[187] = xx[155] * xx[182];
  xx[182] = xx[6] * xx[187];
  xx[188] = xx[184] * xx[41] - xx[180] * xx[182];
  xx[180] = (xx[156] + xx[177] * xx[177]) * xx[6] - xx[7];
  xx[156] = xx[45] * xx[178] * xx[180];
  xx[189] = xx[188] + xx[156];
  xx[190] = xx[189] + xx[59] * xx[41];
  xx[191] = xx[45] * xx[175] * xx[180];
  xx[45] = xx[182] * xx[156] + xx[184] * xx[191];
  xx[156] = xx[185] * xx[178] + xx[186] * xx[175];
  xx[185] = xx[176] * xx[178] - xx[179] * xx[175];
  xx[176] = xx[156] * xx[184] - xx[182] * xx[185];
  xx[179] = xx[61] + xx[62] * xx[180] * xx[180] - xx[45] - xx[45] + xx[184] *
    xx[176] - xx[188] * xx[182];
  xx[45] = xx[176] - xx[191];
  xx[62] = xx[179] + xx[45] * xx[59];
  xx[176] = xx[8] + xx[156];
  xx[156] = xx[45] + xx[176] * xx[59];
  xx[186] = xx[62] + xx[156] * xx[59];
  ii[0] = factorSymmetricPosDef(xx + 186, 1, xx + 188);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "sm:compiler:messages:simulationErrors:DegenerateMass",
      "'blance_leg/blance_leg_model/left joint 4 ' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[188] = xx[190] / xx[186];
  xx[191] = xx[181] - xx[190] * xx[188];
  xx[192] = xx[156] * xx[188];
  xx[193] = xx[41] - xx[192];
  xx[194] = xx[185] - xx[192];
  xx[192] = xx[156] / xx[186];
  xx[195] = xx[176] - xx[156] * xx[192];
  xx[196] = xx[35] * xx[180] * xx[180];
  xx[180] = xx[8] + xx[196];
  xx[197] = xx[191] * xx[148] + xx[150] * xx[193];
  xx[198] = xx[149] * xx[191] + xx[153] * xx[193];
  xx[199] = xx[138] * xx[191] + xx[149] * xx[193];
  xx[200] = xx[148] * xx[194] + xx[150] * xx[195];
  xx[201] = xx[149] * xx[194] + xx[195] * xx[153];
  xx[202] = xx[138] * xx[194] + xx[149] * xx[195];
  xx[203] = xx[180] * xx[151];
  xx[204] = xx[180] * xx[150];
  xx[205] = xx[180] * xx[148];
  pm_math_Matrix3x3_compose_ra(xx + 166, xx + 197, xx + 206);
  xx[191] = xx[1] * state[8];
  xx[193] = xx[0] * cos(xx[191]);
  xx[194] = xx[193] * xx[193];
  xx[195] = xx[0] * sin(xx[191]);
  xx[191] = xx[195] * xx[195];
  xx[197] = (xx[194] + xx[191]) * xx[6] - xx[7];
  xx[198] = xx[193] * xx[195];
  xx[199] = xx[6] * (xx[198] - xx[198]);
  xx[200] = (xx[191] + xx[194]) * xx[6];
  xx[201] = xx[198] + xx[198];
  xx[198] = xx[201] * xx[6];
  xx[202] = (xx[194] + xx[194]) * xx[6] - xx[7];
  xx[203] = xx[191] - xx[194];
  xx[191] = xx[6] * xx[203];
  xx[215] = xx[197];
  xx[216] = xx[199];
  xx[217] = xx[200];
  xx[218] = xx[198];
  xx[219] = xx[202];
  xx[220] = xx[199];
  xx[221] = xx[191];
  xx[222] = xx[198];
  xx[223] = xx[197];
  xx[194] = xx[1] * state[10];
  xx[204] = cos(xx[194]);
  xx[205] = xx[204] * xx[204];
  xx[224] = xx[6] * xx[205] - xx[7];
  xx[225] = xx[1] * state[12];
  xx[226] = cos(xx[225]);
  xx[227] = xx[226] * xx[226];
  xx[228] = xx[6] * xx[227] - xx[7];
  xx[229] = xx[100] * xx[228];
  xx[230] = xx[229] * xx[228];
  xx[231] = sin(xx[225]);
  xx[225] = xx[6] * xx[226] * xx[231];
  xx[232] = xx[100] * xx[225];
  xx[233] = xx[232] * xx[225];
  xx[234] = xx[230] + xx[233];
  xx[235] = xx[99] + xx[234];
  xx[236] = xx[232] * xx[228];
  xx[232] = xx[229] * xx[225];
  xx[229] = xx[236] - xx[232];
  xx[237] = xx[48] * xx[229];
  xx[238] = xx[237] + xx[237];
  xx[239] = xx[233] + xx[230];
  xx[230] = xx[239] * xx[48];
  xx[233] = xx[48] * xx[230];
  xx[240] = xx[115] + xx[233];
  xx[241] = xx[240] + xx[233];
  xx[233] = xx[99] + xx[239];
  xx[242] = xx[230] + xx[233] * xx[48];
  xx[243] = xx[241] + xx[242] * xx[48];
  ii[0] = factorSymmetricPosDef(xx + 243, 1, xx + 244);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "sm:compiler:messages:simulationErrors:DegenerateMass",
      "'blance_leg/blance_leg_model/Revolute Joint3' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[244] = xx[238] / xx[243];
  xx[245] = xx[235] - xx[238] * xx[244];
  xx[246] = sin(xx[194]);
  xx[194] = xx[204] * xx[246];
  xx[247] = xx[6] * xx[194];
  xx[248] = xx[242] * xx[244];
  xx[249] = xx[229] - xx[248];
  xx[250] = xx[245] * xx[224] - xx[247] * xx[249];
  xx[251] = xx[232] - xx[236];
  xx[232] = xx[251] - xx[248];
  xx[236] = xx[242] / xx[243];
  xx[248] = xx[233] - xx[242] * xx[236];
  xx[252] = xx[224] * xx[232] - xx[247] * xx[248];
  xx[253] = xx[224] * xx[250] - xx[247] * xx[252];
  xx[254] = xx[8] + xx[253];
  xx[255] = (xx[205] + xx[246] * xx[246]) * xx[6] - xx[7];
  xx[205] = xx[237] - xx[241] * xx[244];
  xx[256] = xx[230] - xx[241] * xx[236];
  xx[257] = xx[255] * (xx[205] * xx[224] - xx[247] * xx[256]);
  xx[258] = xx[48] * xx[246];
  xx[259] = xx[6] * xx[258] * xx[246];
  xx[260] = xx[47] - xx[259];
  xx[261] = xx[247] * xx[245] + xx[224] * xx[249];
  xx[245] = xx[247] * xx[232] + xx[248] * xx[224];
  xx[232] = xx[261] * xx[224] - xx[245] * xx[247];
  xx[248] = xx[204] * xx[258];
  xx[249] = xx[6] * xx[248];
  xx[258] = xx[260] * xx[232] - xx[249] * xx[253];
  xx[253] = xx[257] + xx[258];
  xx[262] = xx[253] + xx[59] * xx[232];
  xx[263] = xx[241] / xx[243];
  xx[264] = (xx[247] * xx[205] + xx[256] * xx[224]) * xx[255];
  xx[205] = xx[260] * xx[264] - xx[249] * xx[257];
  xx[256] = xx[261] * xx[247] + xx[245] * xx[224];
  xx[245] = xx[247] * xx[250] + xx[224] * xx[252];
  xx[250] = xx[256] * xx[260] - xx[245] * xx[249];
  xx[252] = xx[61] + (xx[240] - xx[241] * xx[263]) * xx[255] * xx[255] + xx[205]
    + xx[205] + xx[250] * xx[260] - xx[258] * xx[249];
  xx[205] = xx[264] + xx[250];
  xx[240] = xx[252] + xx[205] * xx[59];
  xx[250] = xx[8] + xx[256];
  xx[256] = xx[205] + xx[250] * xx[59];
  xx[257] = xx[240] + xx[256] * xx[59];
  ii[0] = factorSymmetricPosDef(xx + 257, 1, xx + 258);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "sm:compiler:messages:simulationErrors:DegenerateMass",
      "'blance_leg/blance_leg_model/left joint 1' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[258] = xx[262] / xx[257];
  xx[261] = xx[254] - xx[262] * xx[258];
  xx[264] = xx[256] * xx[258];
  xx[265] = xx[232] - xx[264];
  xx[266] = xx[245] - xx[264];
  xx[264] = xx[256] / xx[257];
  xx[267] = xx[250] - xx[256] * xx[264];
  xx[268] = (xx[227] + xx[231] * xx[231]) * xx[6] - xx[7];
  xx[227] = xx[100] * xx[268] * xx[268];
  xx[268] = xx[99] + xx[227];
  xx[99] = xx[268] * xx[255] * xx[255];
  xx[269] = xx[8] + xx[99];
  xx[270] = xx[261] * xx[197] + xx[199] * xx[265];
  xx[271] = xx[198] * xx[261] + xx[202] * xx[265];
  xx[272] = xx[191] * xx[261] + xx[198] * xx[265];
  xx[273] = xx[266] * xx[197] + xx[199] * xx[267];
  xx[274] = xx[198] * xx[266] + xx[267] * xx[202];
  xx[275] = xx[191] * xx[266] + xx[198] * xx[267];
  xx[276] = xx[269] * xx[200];
  xx[277] = xx[269] * xx[199];
  xx[278] = xx[269] * xx[197];
  pm_math_Matrix3x3_compose_ra(xx + 215, xx + 270, xx + 279);
  xx[8] = xx[49] * xx[70];
  xx[261] = xx[51] * xx[70];
  xx[70] = xx[58] - xx[40] * xx[64];
  xx[265] = xx[53] - xx[40] * xx[66];
  xx[270] = xx[22] * xx[8];
  xx[271] = xx[21] * xx[8];
  xx[272] = xx[8] * xx[19];
  xx[273] = - (xx[22] * xx[261]);
  xx[274] = - (xx[261] * xx[21]);
  xx[275] = - (xx[261] * xx[19]);
  xx[276] = xx[19] * xx[70] + xx[21] * xx[265];
  xx[277] = xx[20] * xx[70] + xx[265] * xx[24];
  xx[278] = xx[2] * xx[70] + xx[20] * xx[265];
  pm_math_Matrix3x3_compose_ra(xx + 26, xx + 270, xx + 288);
  xx[70] = 0.195;
  xx[265] = xx[59] * xx[4];
  xx[266] = xx[265] * xx[4];
  xx[267] = xx[59] * xx[9];
  xx[270] = xx[267] * xx[9];
  xx[271] = xx[267] * xx[4];
  xx[267] = (xx[271] + xx[265] * xx[9]) * xx[6];
  xx[265] = 0.05400000000000001;
  xx[272] = xx[267] - xx[265];
  xx[273] = 0.03;
  xx[274] = xx[6] * (xx[266] - xx[270]);
  xx[275] = xx[273] - xx[274];
  xx[276] = xx[70] - ((xx[266] + xx[270]) * xx[6] - xx[59]);
  xx[277] = xx[272];
  xx[278] = xx[275];
  pm_math_Matrix3x3_postCross_ra(xx + 80, xx + 276, xx + 297);
  xx[266] = 0.035;
  xx[306] = xx[266] * xx[106];
  xx[307] = xx[116] * xx[266];
  xx[116] = xx[48] * xx[307];
  xx[308] = xx[306] + xx[116];
  xx[309] = xx[266] * xx[105];
  xx[310] = xx[308] * xx[121] - xx[309];
  xx[311] = xx[308] * xx[112] - xx[307];
  xx[312] = xx[310] * xx[98] - xx[124] * xx[311];
  xx[313] = xx[110] * xx[266];
  xx[110] = xx[266] * xx[113];
  xx[314] = xx[266] * xx[128];
  xx[315] = xx[48] * xx[314];
  xx[316] = xx[110] + xx[315];
  xx[317] = xx[313] - xx[316] * xx[121];
  xx[318] = xx[314] - xx[316] * xx[112];
  xx[319] = xx[317] * xx[98] - xx[124] * xx[318];
  xx[320] = xx[98] * xx[312] - xx[124] * xx[319];
  xx[321] = xx[308] / xx[120];
  xx[322] = xx[118] * xx[321];
  xx[323] = (xx[322] - xx[306]) * xx[132];
  xx[306] = xx[316] / xx[120];
  xx[324] = xx[118] * xx[306];
  xx[325] = xx[132] * (xx[110] - xx[324]);
  xx[110] = xx[124] * xx[310] + xx[311] * xx[98];
  xx[310] = xx[124] * xx[317] + xx[318] * xx[98];
  xx[311] = xx[110] * xx[98] - xx[310] * xx[124];
  xx[317] = xx[137] * xx[311] - xx[126] * xx[320];
  xx[318] = xx[323] * xx[98] - xx[124] * xx[325] + xx[317];
  xx[326] = xx[318] + xx[59] * xx[311];
  xx[327] = xx[320] - xx[326] * xx[135];
  xx[328] = xx[311] - xx[326] * xx[141];
  xx[329] = xx[48] * xx[103];
  xx[103] = xx[329] * xx[132];
  xx[330] = xx[124] * xx[103];
  xx[331] = xx[126] * xx[146];
  xx[332] = xx[330] + xx[331];
  xx[333] = xx[124] * xx[312] + xx[98] * xx[319];
  xx[312] = xx[110] * xx[124] + xx[310] * xx[98];
  xx[110] = xx[312] * xx[137] - xx[333] * xx[126];
  xx[310] = xx[124] * xx[323] + xx[325] * xx[98] + xx[110];
  xx[319] = xx[310] + xx[312] * xx[59];
  xx[323] = xx[333] - xx[319] * xx[135];
  xx[325] = xx[312] - xx[319] * xx[141];
  xx[334] = xx[103] * xx[98];
  xx[103] = xx[137] * xx[146];
  xx[146] = xx[334] + xx[103];
  xx[335] = xx[130] - xx[117] * xx[135];
  xx[336] = xx[79] - xx[117] * xx[141];
  xx[337] = xx[71] * xx[327] + xx[73] * xx[328] + xx[74] * xx[332];
  xx[338] = xx[72] * xx[327] + xx[76] * xx[328] + xx[73] * xx[332];
  xx[339] = xx[65] * xx[327] + xx[72] * xx[328] + xx[71] * xx[332];
  xx[340] = xx[323] * xx[71] + xx[73] * xx[325] - xx[146] * xx[74];
  xx[341] = xx[72] * xx[323] + xx[325] * xx[76] - xx[146] * xx[73];
  xx[342] = xx[65] * xx[323] + xx[72] * xx[325] - xx[146] * xx[71];
  xx[343] = xx[335] * xx[71] + xx[73] * xx[336];
  xx[344] = xx[72] * xx[335] + xx[336] * xx[76];
  xx[345] = xx[65] * xx[335] + xx[72] * xx[336];
  pm_math_Matrix3x3_compose_ra(xx + 89, xx + 337, xx + 346);
  xx[71] = xx[59] * xx[67];
  xx[73] = xx[71] * xx[67];
  xx[74] = xx[59] * xx[69];
  xx[323] = xx[74] * xx[69];
  xx[325] = xx[74] * xx[67];
  xx[74] = (xx[325] + xx[71] * xx[69]) * xx[6];
  xx[71] = xx[265] + xx[74];
  xx[327] = xx[6] * (xx[73] - xx[323]);
  xx[328] = xx[273] - xx[327];
  xx[335] = xx[70] - ((xx[73] + xx[323]) * xx[6] - xx[59]);
  xx[336] = xx[71];
  xx[337] = xx[328];
  pm_math_Matrix3x3_postCross_ra(xx + 157, xx + 335, xx + 355);
  xx[73] = xx[182] * xx[196];
  xx[338] = xx[184] * xx[196];
  xx[196] = xx[189] - xx[62] * xx[188];
  xx[339] = xx[45] - xx[62] * xx[192];
  xx[364] = xx[151] * xx[73];
  xx[365] = xx[150] * xx[73];
  xx[366] = xx[73] * xx[148];
  xx[367] = - (xx[151] * xx[338]);
  xx[368] = - (xx[338] * xx[150]);
  xx[369] = - (xx[338] * xx[148]);
  xx[370] = xx[148] * xx[196] + xx[150] * xx[339];
  xx[371] = xx[149] * xx[196] + xx[339] * xx[153];
  xx[372] = xx[138] * xx[196] + xx[149] * xx[339];
  pm_math_Matrix3x3_compose_ra(xx + 166, xx + 364, xx + 373);
  xx[196] = xx[59] * xx[142];
  xx[339] = xx[196] * xx[142];
  xx[340] = xx[59] * xx[144];
  xx[341] = xx[340] * xx[144];
  xx[342] = xx[340] * xx[142];
  xx[340] = (xx[342] + xx[196] * xx[144]) * xx[6];
  xx[196] = xx[340] - xx[265];
  xx[343] = xx[6] * (xx[339] - xx[341]);
  xx[344] = xx[273] - xx[343];
  xx[364] = - (xx[70] + (xx[339] + xx[341]) * xx[6] - xx[59]);
  xx[365] = xx[196];
  xx[366] = xx[344];
  pm_math_Matrix3x3_postCross_ra(xx + 206, xx + 364, xx + 382);
  xx[339] = 0.04;
  xx[345] = xx[339] * xx[229];
  xx[367] = xx[339] * xx[230];
  xx[368] = xx[239] * xx[339];
  xx[239] = xx[48] * xx[368];
  xx[369] = xx[367] + xx[239];
  xx[370] = xx[345] - xx[369] * xx[244];
  xx[371] = xx[368] - xx[369] * xx[236];
  xx[372] = xx[370] * xx[224] - xx[247] * xx[371];
  xx[391] = xx[339] * xx[237];
  xx[392] = xx[339] * xx[251];
  xx[393] = xx[48] * xx[392];
  xx[394] = xx[391] + xx[393];
  xx[395] = xx[234] * xx[339];
  xx[234] = xx[394] * xx[244] - xx[395];
  xx[396] = xx[394] * xx[236] - xx[392];
  xx[397] = xx[224] * xx[234] - xx[247] * xx[396];
  xx[398] = xx[224] * xx[372] - xx[247] * xx[397];
  xx[399] = xx[369] / xx[243];
  xx[400] = xx[241] * xx[399];
  xx[401] = (xx[367] - xx[400]) * xx[255];
  xx[367] = xx[394] / xx[243];
  xx[402] = xx[241] * xx[367];
  xx[403] = xx[255] * (xx[402] - xx[391]);
  xx[391] = xx[247] * xx[370] + xx[371] * xx[224];
  xx[370] = xx[247] * xx[234] + xx[224] * xx[396];
  xx[234] = xx[391] * xx[224] - xx[370] * xx[247];
  xx[371] = xx[260] * xx[234] - xx[249] * xx[398];
  xx[396] = xx[401] * xx[224] - xx[247] * xx[403] + xx[371];
  xx[404] = xx[396] + xx[59] * xx[234];
  xx[405] = xx[398] - xx[404] * xx[258];
  xx[406] = xx[234] - xx[404] * xx[264];
  xx[407] = xx[48] * xx[227];
  xx[227] = xx[407] * xx[255];
  xx[408] = xx[247] * xx[227];
  xx[409] = xx[249] * xx[99];
  xx[410] = xx[408] + xx[409];
  xx[411] = xx[247] * xx[372] + xx[224] * xx[397];
  xx[372] = xx[391] * xx[247] + xx[370] * xx[224];
  xx[370] = xx[372] * xx[260] - xx[411] * xx[249];
  xx[391] = xx[247] * xx[401] + xx[403] * xx[224] + xx[370];
  xx[397] = xx[391] + xx[372] * xx[59];
  xx[401] = xx[411] - xx[397] * xx[258];
  xx[403] = xx[372] - xx[397] * xx[264];
  xx[412] = xx[227] * xx[224];
  xx[227] = xx[260] * xx[99];
  xx[99] = xx[412] + xx[227];
  xx[413] = xx[253] - xx[240] * xx[258];
  xx[414] = xx[205] - xx[240] * xx[264];
  xx[415] = xx[197] * xx[405] + xx[199] * xx[406] + xx[200] * xx[410];
  xx[416] = xx[198] * xx[405] + xx[202] * xx[406] + xx[199] * xx[410];
  xx[417] = xx[191] * xx[405] + xx[198] * xx[406] + xx[197] * xx[410];
  xx[418] = xx[401] * xx[197] + xx[199] * xx[403] - xx[99] * xx[200];
  xx[419] = xx[198] * xx[401] + xx[403] * xx[202] - xx[99] * xx[199];
  xx[420] = xx[191] * xx[401] + xx[198] * xx[403] - xx[99] * xx[197];
  xx[421] = xx[413] * xx[197] + xx[199] * xx[414];
  xx[422] = xx[198] * xx[413] + xx[414] * xx[202];
  xx[423] = xx[191] * xx[413] + xx[198] * xx[414];
  pm_math_Matrix3x3_compose_ra(xx + 215, xx + 415, xx + 424);
  xx[197] = xx[59] * xx[193];
  xx[199] = xx[197] * xx[193];
  xx[200] = xx[59] * xx[195];
  xx[401] = xx[200] * xx[195];
  xx[403] = xx[200] * xx[193];
  xx[200] = (xx[403] + xx[197] * xx[195]) * xx[6];
  xx[197] = xx[265] + xx[200];
  xx[265] = xx[6] * (xx[199] - xx[401]);
  xx[405] = xx[273] - xx[265];
  xx[413] = - (xx[70] + (xx[199] + xx[401]) * xx[6] - xx[59]);
  xx[414] = xx[197];
  xx[415] = xx[405];
  pm_math_Matrix3x3_postCross_ra(xx + 279, xx + 413, xx + 433);
  xx[70] = xx[288] - xx[297] + xx[346] - xx[355] + xx[373] - xx[382] + xx[424] -
    xx[433];
  xx[199] = xx[81] + xx[158] + xx[207] + xx[280];
  xx[81] = 0.03000000000000001;
  xx[158] = xx[70] + xx[199] * xx[81];
  xx[207] = 8.156250000000017e-6;
  xx[280] = 2.265625000000013e-5;
  xx[406] = xx[280] * xx[39];
  xx[416] = 1.97265625e-3;
  xx[417] = xx[416] * xx[43];
  xx[418] = xx[207] + xx[406] * xx[39] + xx[417] * xx[43] + xx[49] * xx[8];
  xx[419] = xx[280] * xx[43];
  xx[420] = xx[416] * xx[39];
  xx[421] = xx[419] * xx[39] - xx[420] * xx[43] - xx[261] * xx[49];
  xx[422] = xx[406] * xx[43] - xx[417] * xx[39] - xx[51] * xx[8];
  xx[406] = 2.6015625e-4;
  xx[417] = xx[406] + xx[419] * xx[43] + xx[420] * xx[39] + xx[51] * xx[261];
  xx[419] = xx[40] / xx[63];
  xx[420] = xx[44] - xx[40] * xx[419];
  xx[442] = xx[418] * xx[19] + xx[421] * xx[21];
  xx[443] = xx[418] * xx[20] + xx[421] * xx[24];
  xx[444] = xx[418] * xx[2] + xx[421] * xx[20];
  xx[445] = xx[422] * xx[19] + xx[417] * xx[21];
  xx[446] = xx[422] * xx[20] + xx[417] * xx[24];
  xx[447] = xx[422] * xx[2] + xx[417] * xx[20];
  xx[448] = xx[22] * xx[420];
  xx[449] = xx[21] * xx[420];
  xx[450] = xx[420] * xx[19];
  pm_math_Matrix3x3_compose_ra(xx + 26, xx + 442, xx + 451);
  pm_math_Matrix3x3_postCross_ra(xx + 288, xx + 276, xx + 26);
  pm_math_Matrix3x3_preCross_ra(xx + 297, xx + 276, xx + 442);
  xx[19] = 2.809375000000016e-5;
  xx[21] = 2.339153333333333e-3;
  xx[22] = xx[21] * xx[104];
  xx[44] = xx[22] * xx[104];
  xx[288] = xx[21] * xx[101];
  xx[297] = xx[288] * xx[101];
  xx[420] = xx[19] + xx[44] + xx[297] + xx[266] * xx[307];
  xx[423] = xx[420] - xx[308] * xx[321];
  xx[460] = xx[288] * xx[104];
  xx[104] = xx[22] * xx[101];
  xx[22] = xx[460] - xx[104] - xx[266] * xx[314];
  xx[101] = xx[316] * xx[321];
  xx[288] = xx[22] + xx[101];
  xx[461] = xx[423] * xx[98] - xx[288] * xx[124];
  xx[462] = xx[104] - xx[460] - xx[266] * xx[309];
  xx[104] = xx[462] + xx[101];
  xx[101] = 2.44609375e-3;
  xx[460] = xx[101] + xx[297] + xx[44] + xx[266] * xx[313] + xx[48] * xx[329];
  xx[44] = xx[460] - xx[316] * xx[306];
  xx[297] = xx[104] * xx[98] - xx[124] * xx[44];
  xx[463] = xx[126] * xx[330];
  xx[464] = xx[207] + xx[98] * xx[461] - xx[124] * xx[297] + xx[463] + xx[463] +
    xx[126] * xx[331];
  xx[463] = xx[326] / xx[134];
  xx[465] = xx[124] * xx[423] + xx[288] * xx[98];
  xx[288] = xx[104] * xx[124] + xx[44] * xx[98];
  xx[44] = xx[137] * xx[330];
  xx[104] = xx[126] * xx[334];
  xx[330] = xx[465] * xx[98] - xx[288] * xx[124] - xx[44] - xx[104] - xx[103] *
    xx[126];
  xx[423] = xx[319] * xx[463];
  xx[466] = xx[117] * xx[463];
  xx[467] = xx[124] * xx[461] + xx[297] * xx[98] - xx[104] - xx[44] - xx[137] *
    xx[331];
  xx[44] = xx[137] * xx[334];
  xx[104] = xx[406] + xx[465] * xx[124] + xx[288] * xx[98] + xx[44] + xx[44] +
    xx[137] * xx[103];
  xx[44] = xx[319] / xx[134];
  xx[103] = xx[117] * xx[44];
  xx[288] = xx[322] - xx[116];
  xx[297] = xx[315] - xx[324];
  xx[322] = xx[132] * (xx[288] * xx[98] - xx[124] * xx[297]) + xx[317];
  xx[317] = (xx[124] * xx[288] + xx[297] * xx[98]) * xx[132] + xx[110];
  xx[110] = xx[117] / xx[134];
  xx[468] = xx[464] - xx[326] * xx[463];
  xx[469] = xx[330] - xx[423];
  xx[470] = xx[318] - xx[466];
  xx[471] = xx[467] - xx[423];
  xx[472] = xx[104] - xx[319] * xx[44];
  xx[473] = xx[310] - xx[103];
  xx[474] = xx[322] - xx[466];
  xx[475] = xx[317] - xx[103];
  xx[476] = xx[129] - xx[117] * xx[110];
  pm_math_Matrix3x3_composeTranspose_ra(xx + 468, xx + 89, xx + 477);
  pm_math_Matrix3x3_compose_ra(xx + 89, xx + 477, xx + 468);
  pm_math_Matrix3x3_postCross_ra(xx + 346, xx + 335, xx + 89);
  pm_math_Matrix3x3_preCross_ra(xx + 355, xx + 335, xx + 477);
  xx[103] = xx[280] * xx[175];
  xx[129] = xx[416] * xx[178];
  xx[132] = xx[207] + xx[103] * xx[175] + xx[129] * xx[178] + xx[182] * xx[73];
  xx[288] = xx[280] * xx[178];
  xx[297] = xx[416] * xx[175];
  xx[310] = xx[288] * xx[175] - xx[297] * xx[178] - xx[338] * xx[182];
  xx[318] = xx[103] * xx[178] - xx[129] * xx[175] - xx[184] * xx[73];
  xx[103] = xx[406] + xx[288] * xx[178] + xx[297] * xx[175] + xx[184] * xx[338];
  xx[129] = xx[62] / xx[186];
  xx[288] = xx[179] - xx[62] * xx[129];
  xx[486] = xx[132] * xx[148] + xx[310] * xx[150];
  xx[487] = xx[132] * xx[149] + xx[310] * xx[153];
  xx[488] = xx[132] * xx[138] + xx[310] * xx[149];
  xx[489] = xx[318] * xx[148] + xx[103] * xx[150];
  xx[490] = xx[318] * xx[149] + xx[103] * xx[153];
  xx[491] = xx[318] * xx[138] + xx[103] * xx[149];
  xx[492] = xx[151] * xx[288];
  xx[493] = xx[150] * xx[288];
  xx[494] = xx[288] * xx[148];
  pm_math_Matrix3x3_compose_ra(xx + 166, xx + 486, xx + 495);
  pm_math_Matrix3x3_postCross_ra(xx + 373, xx + 364, xx + 166);
  pm_math_Matrix3x3_preCross_ra(xx + 382, xx + 364, xx + 486);
  xx[148] = xx[21] * xx[228];
  xx[150] = xx[148] * xx[228];
  xx[151] = xx[21] * xx[225];
  xx[179] = xx[151] * xx[225];
  xx[288] = xx[19] + xx[150] + xx[179] + xx[339] * xx[368];
  xx[297] = xx[288] - xx[369] * xx[399];
  xx[324] = xx[151] * xx[228];
  xx[151] = xx[148] * xx[225];
  xx[148] = xx[324] - xx[151] - xx[339] * xx[392];
  xx[225] = xx[394] * xx[399];
  xx[228] = xx[148] + xx[225];
  xx[331] = xx[297] * xx[224] - xx[228] * xx[247];
  xx[334] = xx[151] - xx[324] - xx[339] * xx[345];
  xx[151] = xx[334] + xx[225];
  xx[225] = xx[101] + xx[179] + xx[150] + xx[339] * xx[395] + xx[48] * xx[407];
  xx[150] = xx[225] - xx[394] * xx[367];
  xx[179] = xx[151] * xx[224] - xx[247] * xx[150];
  xx[324] = xx[249] * xx[408];
  xx[346] = xx[207] + xx[224] * xx[331] - xx[247] * xx[179] + xx[324] + xx[324]
    + xx[249] * xx[409];
  xx[324] = xx[404] / xx[257];
  xx[355] = xx[247] * xx[297] + xx[228] * xx[224];
  xx[228] = xx[151] * xx[247] + xx[150] * xx[224];
  xx[150] = xx[260] * xx[408];
  xx[151] = xx[249] * xx[412];
  xx[297] = xx[355] * xx[224] - xx[228] * xx[247] - xx[150] - xx[151] - xx[227] *
    xx[249];
  xx[373] = xx[397] * xx[324];
  xx[382] = xx[240] * xx[324];
  xx[408] = xx[247] * xx[331] + xx[179] * xx[224] - xx[151] - xx[150] - xx[260] *
    xx[409];
  xx[150] = xx[260] * xx[412];
  xx[151] = xx[406] + xx[355] * xx[247] + xx[228] * xx[224] + xx[150] + xx[150]
    + xx[260] * xx[227];
  xx[150] = xx[397] / xx[257];
  xx[179] = xx[240] * xx[150];
  xx[227] = xx[239] - xx[400];
  xx[228] = xx[402] - xx[393];
  xx[331] = xx[255] * (xx[227] * xx[224] - xx[247] * xx[228]) + xx[371];
  xx[355] = (xx[247] * xx[227] + xx[224] * xx[228]) * xx[255] + xx[370];
  xx[227] = xx[240] / xx[257];
  xx[504] = xx[346] - xx[404] * xx[324];
  xx[505] = xx[297] - xx[373];
  xx[506] = xx[396] - xx[382];
  xx[507] = xx[408] - xx[373];
  xx[508] = xx[151] - xx[397] * xx[150];
  xx[509] = xx[391] - xx[179];
  xx[510] = xx[331] - xx[382];
  xx[511] = xx[355] - xx[179];
  xx[512] = xx[252] - xx[240] * xx[227];
  pm_math_Matrix3x3_composeTranspose_ra(xx + 504, xx + 215, xx + 513);
  pm_math_Matrix3x3_compose_ra(xx + 215, xx + 513, xx + 504);
  pm_math_Matrix3x3_postCross_ra(xx + 424, xx + 413, xx + 215);
  pm_math_Matrix3x3_preCross_ra(xx + 433, xx + 413, xx + 513);
  xx[179] = xx[289] - xx[300] + xx[347] - xx[358] + xx[374] - xx[385] + xx[425]
    - xx[436];
  xx[228] = xx[451] - xx[26] - xx[26] - xx[442] + xx[468] - xx[89] - xx[89] -
    xx[477] + xx[495] - xx[166] - xx[166] - xx[486] + xx[504] - xx[215] - xx[215]
    - xx[513] + xx[179] * xx[81] + 0.08961000000000001;
  xx[252] = 10.3;
  xx[255] = xx[84] + xx[161] + xx[210] + xx[283] + xx[252];
  xx[84] = xx[179] + xx[255] * xx[81];
  xx[161] = xx[228] + xx[84] * xx[81];
  ii[0] = factorSymmetricPosDef(xx + 161, 1, xx + 210);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "sm:compiler:messages:simulationErrors:DegenerateMass",
      "'blance_leg/blance_leg_model/pitch' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[210] = xx[158] / xx[161];
  xx[283] = xx[84] * xx[210];
  xx[289] = xx[82] + xx[159] + xx[208] + xx[281];
  xx[82] = xx[290] - xx[303] + xx[348] - xx[361] + xx[375] - xx[388] + xx[426] -
    xx[439];
  xx[159] = xx[87] + xx[164] + xx[213] + xx[286];
  xx[87] = xx[82] + xx[159] * xx[81];
  xx[164] = xx[87] * xx[210];
  xx[208] = xx[84] / xx[161];
  xx[213] = xx[85] + xx[162] + xx[211] + xx[284];
  xx[85] = xx[87] * xx[208];
  xx[162] = xx[88] + xx[165] + xx[214] + xx[287] + xx[252];
  xx[88] = xx[87] / xx[161];
  xx[522] = xx[80] + xx[157] + xx[206] + xx[279] - xx[158] * xx[210] + xx[252];
  xx[523] = xx[199] - xx[283];
  xx[524] = xx[289] - xx[164];
  xx[525] = xx[83] + xx[160] + xx[209] + xx[282] - xx[283];
  xx[526] = xx[255] - xx[84] * xx[208];
  xx[527] = xx[213] - xx[85];
  xx[528] = xx[86] + xx[163] + xx[212] + xx[285] - xx[164];
  xx[529] = xx[159] - xx[85];
  xx[530] = xx[162] - xx[87] * xx[88];
  pm_math_Matrix3x3_composeTranspose_ra(xx + 522, xx + 10, xx + 531);
  pm_math_Matrix3x3_compose_ra(xx + 10, xx + 531, xx + 522);
  xx[531] = xx[522];
  xx[532] = xx[523];
  xx[533] = xx[524];
  xx[534] = xx[523];
  xx[535] = xx[526];
  xx[536] = xx[527];
  xx[537] = xx[524];
  xx[538] = xx[527];
  xx[539] = xx[530];
  ii[0] = factorSymmetricPosDef(xx + 531, 3, xx + 163);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "sm:compiler:messages:simulationErrors:DegenerateMass",
      "'blance_leg/blance_leg_model/Cartesian Joint1' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[80] = - xx[5];
  xx[281] = - xx[3];
  xx[282] = xx[80];
  xx[283] = xx[3];
  xx[284] = xx[80];
  xx[423] = xx[4];
  xx[424] = xx[9];
  xx[425] = xx[4];
  xx[426] = xx[9];
  xx[80] = xx[4] * state[7];
  xx[83] = xx[9] * state[7];
  xx[85] = (xx[4] * xx[80] + xx[9] * xx[83]) * xx[6];
  xx[86] = state[7] - xx[85];
  xx[157] = xx[6] * (xx[9] * xx[80] - xx[4] * xx[83]);
  xx[80] = xx[85] + state[25];
  xx[163] = xx[86];
  xx[164] = xx[157];
  xx[165] = xx[80];
  xx[285] = - (xx[80] * xx[49]);
  xx[286] = xx[80] * xx[51];
  xx[287] = - (xx[51] * xx[157] - xx[49] * xx[86]);
  pm_math_Vector3_cross_ra(xx + 163, xx + 285, xx + 373);
  xx[83] = xx[374] * xx[42];
  xx[159] = xx[373] * xx[42];
  xx[160] = xx[80] + state[27];
  xx[199] = xx[48] * state[27];
  xx[206] = xx[35] * (xx[373] + xx[6] * (xx[37] * xx[83] - xx[159] * xx[42]) -
                      (xx[80] + xx[160]) * xx[199]);
  xx[209] = xx[35] * (xx[374] - (xx[37] * xx[159] + xx[83] * xx[42]) * xx[6]);
  xx[83] = 0.046875;
  xx[159] = xx[157] * xx[42];
  xx[211] = xx[42] * xx[86];
  xx[212] = xx[86] + xx[6] * (xx[37] * xx[159] - xx[211] * xx[42]);
  xx[214] = xx[157] - (xx[37] * xx[211] + xx[159] * xx[42]) * xx[6];
  xx[285] = xx[212];
  xx[286] = xx[214];
  xx[287] = xx[160];
  xx[159] = 1.95625e-3;
  xx[540] = xx[212] * xx[280];
  xx[541] = xx[416] * xx[214];
  xx[542] = xx[160] * xx[159];
  pm_math_Vector3_cross_ra(xx + 285, xx + 540, xx + 543);
  xx[160] = xx[545] + xx[48] * xx[209];
  xx[211] = xx[48] - xx[50];
  xx[285] = xx[9];
  xx[286] = xx[4];
  xx[287] = xx[9];
  xx[252] = xx[9] * xx[211];
  xx[255] = xx[9] * xx[49];
  xx[279] = - xx[255];
  xx[290] = xx[4] * xx[49];
  xx[300] = xx[252] + xx[290];
  xx[540] = - xx[252];
  xx[541] = xx[279];
  xx[542] = xx[300];
  pm_math_Vector3_cross_ra(xx + 285, xx + 540, xx + 546);
  xx[252] = xx[4] * xx[255];
  xx[255] = xx[4] * xx[42];
  xx[303] = xx[37] * xx[9];
  xx[347] = xx[255] + xx[303];
  xx[348] = xx[347] * xx[48];
  xx[358] = xx[303] + xx[255];
  xx[255] = xx[358] * xx[48];
  xx[303] = (xx[347] * xx[348] + xx[358] * xx[255]) * xx[6];
  xx[361] = xx[211] + xx[6] * (xx[547] - xx[252]) - xx[303] + xx[48];
  xx[370] = - xx[195];
  xx[371] = - xx[193];
  xx[540] = xx[370];
  xx[541] = xx[371];
  xx[542] = xx[370];
  xx[382] = xx[260] * xx[195];
  xx[385] = xx[195] * xx[249];
  xx[388] = xx[193] * xx[249];
  xx[391] = xx[382] + xx[388];
  xx[549] = xx[382];
  xx[550] = xx[385];
  xx[551] = - xx[391];
  pm_math_Vector3_cross_ra(xx + 540, xx + 549, xx + 552);
  xx[382] = xx[193] * xx[385];
  xx[396] = xx[193] * xx[246];
  xx[400] = xx[204] * xx[195];
  xx[402] = xx[396] + xx[400];
  xx[409] = xx[402] * xx[48];
  xx[412] = xx[400] + xx[396];
  xx[396] = xx[412] * xx[48];
  xx[400] = (xx[402] * xx[409] + xx[412] * xx[396]) * xx[6];
  xx[433] = xx[260] + (xx[553] - xx[382]) * xx[6] - (xx[401] + xx[401]) * xx[6]
    - xx[400] + xx[47];
  xx[401] = xx[48] - xx[259];
  xx[436] = xx[195] * xx[401];
  xx[439] = xx[436] + xx[388];
  xx[549] = xx[436];
  xx[550] = xx[385];
  xx[551] = - xx[439];
  pm_math_Vector3_cross_ra(xx + 540, xx + 549, xx + 555);
  xx[385] = xx[401] + xx[6] * (xx[556] - xx[382]) - xx[400] + xx[48];
  xx[382] = xx[385] / xx[243];
  xx[388] = xx[242] * xx[382];
  xx[400] = xx[238] * xx[382];
  xx[436] = xx[400] * xx[246];
  xx[461] = xx[388] * xx[246];
  xx[465] = xx[388] + xx[6] * (xx[204] * xx[436] - xx[461] * xx[246]);
  xx[388] = xx[400] - (xx[204] * xx[461] + xx[436] * xx[246]) * xx[6];
  xx[400] = xx[241] * xx[382] + xx[465] * xx[260] - xx[249] * xx[388];
  xx[436] = (xx[433] - (xx[400] + xx[465] * xx[59])) / xx[257];
  xx[549] = xx[324];
  xx[550] = xx[150];
  xx[551] = xx[227];
  xx[150] = xx[48] - xx[183];
  xx[227] = - xx[144];
  xx[324] = - xx[142];
  xx[558] = xx[227];
  xx[559] = xx[324];
  xx[560] = xx[227];
  xx[461] = xx[144] * xx[150];
  xx[466] = xx[144] * xx[182];
  xx[561] = xx[142] * xx[182];
  xx[562] = xx[461] + xx[561];
  xx[563] = xx[461];
  xx[564] = xx[466];
  xx[565] = - xx[562];
  pm_math_Vector3_cross_ra(xx + 558, xx + 563, xx + 566);
  xx[461] = xx[142] * xx[466];
  xx[563] = xx[142] * xx[177];
  xx[564] = xx[155] * xx[144];
  xx[565] = xx[563] + xx[564];
  xx[569] = xx[565] * xx[48];
  xx[570] = xx[564] + xx[563];
  xx[563] = xx[570] * xx[48];
  xx[564] = (xx[565] * xx[569] + xx[570] * xx[563]) * xx[6];
  xx[571] = xx[150] + xx[6] * (xx[567] - xx[461]) - xx[564] + xx[48];
  xx[572] = 7.815625e-3;
  xx[573] = xx[571] / xx[572];
  xx[574] = xx[83] * xx[573];
  xx[575] = xx[574] * xx[177];
  xx[576] = xx[6] * xx[575] * xx[177] - xx[574];
  xx[574] = xx[6] * xx[155] * xx[575];
  xx[575] = xx[184] * xx[576] - xx[182] * xx[574] - xx[159] * xx[573];
  xx[577] = xx[184] * xx[144];
  xx[578] = xx[577] + xx[561];
  xx[579] = xx[577];
  xx[580] = xx[466];
  xx[581] = - xx[578];
  pm_math_Vector3_cross_ra(xx + 558, xx + 579, xx + 582);
  xx[466] = xx[184] + (xx[583] - xx[461]) * xx[6] - (xx[341] + xx[341]) * xx[6]
    - xx[564] + xx[47];
  xx[341] = (xx[575] + xx[59] * xx[576] + xx[466]) / xx[186];
  xx[461] = xx[575] - xx[62] * xx[341];
  xx[561] = xx[574] - xx[190] * xx[341];
  xx[564] = xx[576] - xx[156] * xx[341];
  xx[574] = xx[144] * xx[564];
  xx[575] = xx[144] * xx[561];
  xx[576] = xx[142] * xx[561] - xx[574];
  xx[579] = xx[574];
  xx[580] = - xx[575];
  xx[581] = xx[576];
  pm_math_Vector3_cross_ra(xx + 558, xx + 579, xx + 585);
  xx[577] = xx[561] + xx[6] * (xx[585] - xx[142] * xx[574]);
  xx[561] = xx[564] + (xx[142] * xx[575] + xx[586]) * xx[6];
  xx[564] = (xx[587] - xx[142] * xx[576]) * xx[6];
  xx[574] = xx[577];
  xx[575] = xx[561];
  xx[576] = xx[564];
  pm_math_Vector3_cross_ra(xx + 364, xx + 574, xx + 579);
  xx[585] = xx[371];
  xx[586] = xx[370];
  xx[587] = xx[371];
  xx[588] = xx[370];
  xx[370] = xx[394] * xx[382];
  xx[371] = xx[370] * xx[246];
  xx[574] = xx[369] * xx[382];
  xx[575] = xx[574] * xx[246];
  xx[589] = xx[6] * (xx[204] * xx[371] - xx[575] * xx[246]) + xx[574] + xx[404] *
    xx[436];
  xx[590] = (xx[204] * xx[575] + xx[371] * xx[246]) * xx[6] - xx[370] + xx[397] *
    xx[436];
  xx[591] = xx[400] + xx[240] * xx[436];
  pm_math_Quaternion_xform_ra(xx + 585, xx + 589, xx + 574);
  xx[370] = xx[388] + xx[262] * xx[436];
  xx[371] = xx[465] + xx[256] * xx[436];
  xx[388] = xx[371] * xx[195];
  xx[400] = xx[370] * xx[195];
  xx[465] = xx[370] * xx[193] - xx[388];
  xx[589] = xx[388];
  xx[590] = - xx[400];
  xx[591] = xx[465];
  pm_math_Vector3_cross_ra(xx + 540, xx + 589, xx + 592);
  xx[575] = xx[370] + xx[6] * (xx[592] - xx[388] * xx[193]);
  xx[370] = xx[371] + (xx[400] * xx[193] + xx[593]) * xx[6];
  xx[371] = (xx[594] - xx[193] * xx[465]) * xx[6];
  xx[589] = xx[575];
  xx[590] = xx[370];
  xx[591] = xx[371];
  pm_math_Vector3_cross_ra(xx + 413, xx + 589, xx + 592);
  xx[388] = xx[561] + xx[370];
  xx[370] = ((xx[142] * xx[142] * xx[461] + xx[144] * xx[144] * xx[461]) * xx[6]
             + xx[579] + xx[574] + xx[592] + xx[388] * xx[81]) / xx[161];
  xx[579] = xx[210];
  xx[580] = xx[208];
  xx[581] = xx[88];
  xx[589] = xx[577] + xx[575] - xx[158] * xx[370];
  xx[590] = xx[388] - xx[84] * xx[370];
  xx[591] = xx[564] + xx[371] - xx[87] * xx[370];
  pm_math_Quaternion_xform_ra(xx + 281, xx + 589, xx + 574);
  xx[589] = - xx[574];
  xx[590] = - xx[575];
  xx[591] = - xx[576];
  solveSymmetricPosDef(xx + 531, xx + 589, 3, 1, xx + 574, xx + 592);
  pm_math_Quaternion_inverseXform_ra(xx + 281, xx + 574, xx + 589);
  xx[371] = xx[370] + pm_math_Vector3_dot_ra(xx + 579, xx + 589);
  xx[370] = xx[371] * xx[193];
  xx[388] = xx[371] * xx[195];
  xx[400] = (xx[370] * xx[193] + xx[388] * xx[195]) * xx[6];
  xx[461] = xx[400] - xx[371];
  xx[465] = xx[6] * (xx[388] * xx[193] - xx[370] * xx[195]);
  xx[574] = xx[461];
  xx[575] = xx[465];
  xx[576] = - xx[400];
  xx[370] = xx[590] - xx[371] * xx[81];
  xx[592] = xx[589];
  xx[593] = xx[370] + xx[371] * xx[405];
  xx[594] = xx[591] - xx[371] * xx[197];
  pm_math_Quaternion_inverseXform_ra(xx + 585, xx + 592, xx + 595);
  xx[388] = xx[436] - (pm_math_Vector3_dot_ra(xx + 549, xx + 574) + xx[258] *
                       xx[595] + xx[264] * xx[596]);
  xx[574] = xx[399];
  xx[575] = - xx[367];
  xx[576] = xx[263];
  xx[263] = xx[465] * xx[246];
  xx[367] = xx[246] * xx[461];
  xx[399] = xx[388] - xx[400];
  xx[592] = xx[461] + xx[6] * (xx[204] * xx[263] - xx[367] * xx[246]);
  xx[593] = xx[465] - (xx[204] * xx[367] + xx[263] * xx[246]) * xx[6];
  xx[594] = xx[399];
  xx[263] = xx[595] - xx[249] * xx[399];
  xx[367] = xx[596] + xx[59] * xx[388] + xx[260] * xx[399];
  xx[399] = xx[367] * xx[246];
  xx[400] = xx[263] * xx[246];
  xx[595] = xx[324];
  xx[596] = xx[227];
  xx[597] = xx[324];
  xx[598] = xx[227];
  xx[599] = xx[589];
  xx[600] = xx[370] + xx[371] * xx[344];
  xx[601] = xx[591] - xx[371] * xx[196];
  pm_math_Quaternion_inverseXform_ra(xx + 595, xx + 599, xx + 589);
  xx[227] = (xx[371] * xx[142] * xx[142] + xx[371] * xx[144] * xx[144]) * xx[6];
  xx[324] = xx[341] + xx[188] * xx[589] + xx[192] * xx[590] - xx[129] * xx[227];
  xx[341] = 5.997600959616154;
  xx[370] = xx[227] + xx[324];
  xx[227] = xx[590] - xx[324] * xx[59] - xx[370] * xx[184];
  xx[371] = 0.2502998800479808;
  xx[436] = xx[204] * xx[193] - xx[195] * xx[246];
  xx[461] = (xx[396] * xx[436] + xx[409] * xx[436]) * xx[6];
  xx[396] = (xx[193] * xx[391] + xx[554]) * xx[6] + (xx[403] + xx[403]) * xx[6]
    + xx[461];
  xx[391] = (xx[439] * xx[193] + xx[557]) * xx[6] + xx[461];
  xx[403] = xx[391] / xx[243];
  xx[409] = xx[242] * xx[403];
  xx[439] = xx[238] * xx[403];
  xx[461] = xx[439] * xx[246];
  xx[465] = xx[409] * xx[246];
  xx[552] = xx[409] + xx[6] * (xx[204] * xx[461] - xx[465] * xx[246]);
  xx[409] = xx[439] - (xx[204] * xx[465] + xx[461] * xx[246]) * xx[6];
  xx[439] = xx[241] * xx[403] + xx[552] * xx[260] - xx[249] * xx[409];
  xx[461] = (xx[396] - (xx[439] + xx[552] * xx[59])) / xx[257];
  xx[465] = xx[155] * xx[142] - xx[144] * xx[177];
  xx[553] = (xx[563] * xx[465] + xx[569] * xx[465]) * xx[6];
  xx[554] = (xx[562] * xx[142] + xx[568]) * xx[6] + xx[553];
  xx[555] = xx[554] / xx[572];
  xx[556] = xx[83] * xx[555];
  xx[557] = xx[556] * xx[177];
  xx[561] = xx[6] * xx[557] * xx[177] - xx[556];
  xx[556] = xx[6] * xx[155] * xx[557];
  xx[557] = xx[184] * xx[561] - xx[182] * xx[556] - xx[159] * xx[555];
  xx[562] = (xx[142] * xx[578] + xx[584]) * xx[6] + (xx[342] + xx[342]) * xx[6]
    + xx[553];
  xx[342] = (xx[557] + xx[59] * xx[561] + xx[562]) / xx[186];
  xx[553] = xx[557] - xx[62] * xx[342];
  xx[557] = xx[556] - xx[190] * xx[342];
  xx[556] = xx[561] - xx[156] * xx[342];
  xx[561] = xx[144] * xx[556];
  xx[563] = xx[144] * xx[557];
  xx[564] = xx[142] * xx[557] - xx[561];
  xx[566] = xx[561];
  xx[567] = - xx[563];
  xx[568] = xx[564];
  pm_math_Vector3_cross_ra(xx + 558, xx + 566, xx + 582);
  xx[566] = xx[557] + xx[6] * (xx[582] - xx[142] * xx[561]);
  xx[557] = xx[556] + (xx[142] * xx[563] + xx[583]) * xx[6];
  xx[556] = (xx[584] - xx[142] * xx[564]) * xx[6];
  xx[567] = xx[566];
  xx[568] = xx[557];
  xx[569] = xx[556];
  pm_math_Vector3_cross_ra(xx + 364, xx + 567, xx + 582);
  xx[561] = xx[394] * xx[403];
  xx[563] = xx[561] * xx[246];
  xx[564] = xx[369] * xx[403];
  xx[567] = xx[564] * xx[246];
  xx[599] = xx[6] * (xx[204] * xx[563] - xx[567] * xx[246]) + xx[564] + xx[404] *
    xx[461];
  xx[600] = (xx[204] * xx[567] + xx[563] * xx[246]) * xx[6] - xx[561] + xx[397] *
    xx[461];
  xx[601] = xx[439] + xx[240] * xx[461];
  pm_math_Quaternion_xform_ra(xx + 585, xx + 599, xx + 567);
  xx[439] = xx[409] + xx[262] * xx[461];
  xx[409] = xx[552] + xx[256] * xx[461];
  xx[552] = xx[409] * xx[195];
  xx[561] = xx[439] * xx[195];
  xx[563] = xx[439] * xx[193] - xx[552];
  xx[599] = xx[552];
  xx[600] = - xx[561];
  xx[601] = xx[563];
  pm_math_Vector3_cross_ra(xx + 540, xx + 599, xx + 602);
  xx[564] = xx[439] + xx[6] * (xx[602] - xx[552] * xx[193]);
  xx[439] = xx[409] + (xx[561] * xx[193] + xx[603]) * xx[6];
  xx[409] = (xx[604] - xx[193] * xx[563]) * xx[6];
  xx[599] = xx[564];
  xx[600] = xx[439];
  xx[601] = xx[409];
  pm_math_Vector3_cross_ra(xx + 413, xx + 599, xx + 602);
  xx[552] = xx[557] + xx[439];
  xx[439] = ((xx[142] * xx[142] * xx[553] + xx[144] * xx[144] * xx[553]) * xx[6]
             + xx[582] + xx[567] + xx[602] + xx[552] * xx[81]) / xx[161];
  xx[567] = xx[566] + xx[564] - xx[158] * xx[439];
  xx[568] = xx[552] - xx[84] * xx[439];
  xx[569] = xx[556] + xx[409] - xx[87] * xx[439];
  pm_math_Quaternion_xform_ra(xx + 281, xx + 567, xx + 582);
  xx[566] = - xx[582];
  xx[567] = - xx[583];
  xx[568] = - xx[584];
  solveSymmetricPosDef(xx + 531, xx + 566, 3, 1, xx + 582, xx + 599);
  pm_math_Quaternion_inverseXform_ra(xx + 281, xx + 582, xx + 566);
  xx[409] = xx[439] + pm_math_Vector3_dot_ra(xx + 579, xx + 566);
  xx[439] = xx[409] * xx[193];
  xx[552] = xx[409] * xx[195];
  xx[553] = (xx[439] * xx[193] + xx[552] * xx[195]) * xx[6];
  xx[556] = xx[553] - xx[409];
  xx[557] = xx[6] * (xx[552] * xx[193] - xx[439] * xx[195]);
  xx[582] = xx[556];
  xx[583] = xx[557];
  xx[584] = - xx[553];
  xx[439] = xx[567] - xx[409] * xx[81];
  xx[599] = xx[566];
  xx[600] = xx[439] + xx[409] * xx[405];
  xx[601] = xx[568] - xx[409] * xx[197];
  pm_math_Quaternion_inverseXform_ra(xx + 585, xx + 599, xx + 602);
  xx[552] = xx[461] - (pm_math_Vector3_dot_ra(xx + 549, xx + 582) + xx[258] *
                       xx[602] + xx[264] * xx[603]);
  xx[461] = xx[557] * xx[246];
  xx[561] = xx[246] * xx[556];
  xx[563] = xx[552] - xx[553];
  xx[582] = xx[556] + xx[6] * (xx[204] * xx[461] - xx[561] * xx[246]);
  xx[583] = xx[557] - (xx[204] * xx[561] + xx[461] * xx[246]) * xx[6];
  xx[584] = xx[563];
  xx[461] = xx[602] - xx[249] * xx[563];
  xx[553] = xx[603] + xx[59] * xx[552] + xx[260] * xx[563];
  xx[556] = xx[553] * xx[246];
  xx[557] = xx[461] * xx[246];
  xx[561] = xx[403] - (pm_math_Vector3_dot_ra(xx + 574, xx + 582) + (xx[461] +
    xx[6] * (xx[204] * xx[556] - xx[557] * xx[246])) * xx[244] + xx[236] * (xx
    [553] - (xx[204] * xx[557] + xx[556] * xx[246]) * xx[6]));
  xx[582] = xx[566];
  xx[583] = xx[439] + xx[409] * xx[344];
  xx[584] = xx[568] - xx[409] * xx[196];
  pm_math_Quaternion_inverseXform_ra(xx + 595, xx + 582, xx + 566);
  xx[403] = (xx[409] * xx[142] * xx[142] + xx[409] * xx[144] * xx[144]) * xx[6];
  xx[409] = xx[342] + xx[188] * xx[566] + xx[192] * xx[567] - xx[129] * xx[403];
  xx[342] = xx[403] + xx[409];
  xx[403] = xx[567] - xx[409] * xx[59] - xx[342] * xx[184];
  xx[439] = xx[555] + xx[341] * (xx[403] - (xx[155] * xx[177] * (xx[566] + xx
    [342] * xx[182]) + xx[177] * xx[403] * xx[177]) * xx[6]) - xx[342] * xx[371];
  xx[342] = xx[433] * xx[552] + xx[385] * xx[561] + xx[409] * xx[466] + xx[439] *
    xx[571];
  xx[403] = xx[361] / xx[572];
  xx[461] = xx[83] * xx[403];
  xx[553] = xx[461] * xx[42];
  xx[555] = xx[6] * xx[37] * xx[553];
  xx[556] = xx[6] * xx[553] * xx[42] - xx[461];
  xx[461] = xx[51] * xx[556] - xx[49] * xx[555] - xx[159] * xx[403];
  xx[553] = xx[51] * xx[9];
  xx[557] = xx[553] + xx[290];
  xx[566] = - xx[553];
  xx[567] = xx[279];
  xx[568] = xx[557];
  pm_math_Vector3_cross_ra(xx + 285, xx + 566, xx + 582);
  xx[279] = xx[51] + (xx[583] - xx[252]) * xx[6] - (xx[270] + xx[270]) * xx[6] -
    xx[303] + xx[47];
  xx[252] = (xx[461] + xx[59] * xx[556] + xx[279]) / xx[63];
  xx[270] = xx[555] - xx[60] * xx[252];
  xx[290] = xx[556] - xx[38] * xx[252];
  xx[303] = xx[9] * xx[290];
  xx[553] = xx[9] * xx[270];
  xx[555] = xx[303] - xx[4] * xx[270];
  xx[566] = - xx[303];
  xx[567] = xx[553];
  xx[568] = xx[555];
  pm_math_Vector3_cross_ra(xx + 285, xx + 566, xx + 599);
  xx[556] = xx[270] + xx[6] * (xx[599] - xx[4] * xx[303]);
  xx[270] = xx[48] - xx[136];
  xx[566] = xx[69];
  xx[567] = xx[67];
  xx[568] = xx[69];
  xx[303] = xx[69] * xx[270];
  xx[563] = xx[69] * xx[126];
  xx[564] = - xx[563];
  xx[569] = xx[67] * xx[126];
  xx[577] = xx[303] + xx[569];
  xx[602] = - xx[303];
  xx[603] = xx[564];
  xx[604] = xx[577];
  pm_math_Vector3_cross_ra(xx + 566, xx + 602, xx + 605);
  xx[303] = xx[67] * xx[563];
  xx[563] = xx[67] * xx[123];
  xx[578] = xx[78] * xx[69];
  xx[590] = xx[563] + xx[578];
  xx[591] = xx[590] * xx[48];
  xx[602] = xx[578] + xx[563];
  xx[563] = xx[602] * xx[48];
  xx[578] = (xx[590] * xx[591] + xx[602] * xx[563]) * xx[6];
  xx[603] = xx[270] + xx[6] * (xx[606] - xx[303]) - xx[578] + xx[48];
  xx[604] = xx[603] / xx[120];
  xx[608] = xx[114] * xx[604];
  xx[609] = xx[119] * xx[604];
  xx[610] = xx[609] * xx[123];
  xx[611] = xx[608] * xx[123];
  xx[612] = xx[608] - (xx[78] * xx[610] + xx[611] * xx[123]) * xx[6];
  xx[608] = xx[137] * xx[69];
  xx[613] = xx[608] + xx[569];
  xx[614] = - xx[608];
  xx[615] = xx[564];
  xx[616] = xx[613];
  pm_math_Vector3_cross_ra(xx + 566, xx + 614, xx + 617);
  xx[564] = xx[137] + (xx[618] - xx[303]) * xx[6] - (xx[323] + xx[323]) * xx[6]
    - xx[578] + xx[47];
  xx[47] = xx[609] + xx[6] * (xx[78] * xx[611] - xx[610] * xx[123]);
  xx[303] = xx[118] * xx[604] + xx[47] * xx[137] - xx[126] * xx[612];
  xx[323] = (xx[564] - (xx[303] + xx[47] * xx[59])) / xx[134];
  xx[569] = xx[612] + xx[139] * xx[323];
  xx[578] = xx[47] + xx[133] * xx[323];
  xx[47] = xx[578] * xx[69];
  xx[608] = xx[569] * xx[69];
  xx[609] = xx[47] - xx[569] * xx[67];
  xx[610] = - xx[47];
  xx[611] = xx[608];
  xx[612] = xx[609];
  pm_math_Vector3_cross_ra(xx + 566, xx + 610, xx + 614);
  xx[610] = xx[569] + xx[6] * (xx[614] - xx[47] * xx[67]);
  xx[47] = xx[461] - xx[40] * xx[252];
  xx[461] = xx[290] + (xx[4] * xx[553] + xx[600]) * xx[6];
  xx[290] = (xx[4] * xx[555] + xx[601]) * xx[6];
  xx[599] = xx[556];
  xx[600] = xx[461];
  xx[601] = xx[290];
  pm_math_Vector3_cross_ra(xx + 276, xx + 599, xx + 620);
  xx[621] = xx[67];
  xx[622] = xx[69];
  xx[623] = xx[67];
  xx[624] = xx[69];
  xx[553] = xx[308] * xx[604];
  xx[555] = xx[553] * xx[123];
  xx[569] = xx[316] * xx[604];
  xx[599] = xx[569] * xx[123];
  xx[625] = xx[6] * (xx[555] * xx[123] - xx[78] * xx[599]) - xx[553] + xx[326] *
    xx[323];
  xx[626] = xx[569] - (xx[78] * xx[555] + xx[599] * xx[123]) * xx[6] + xx[319] *
    xx[323];
  xx[627] = xx[303] + xx[117] * xx[323];
  pm_math_Quaternion_xform_ra(xx + 621, xx + 625, xx + 599);
  xx[303] = xx[578] + (xx[608] * xx[67] + xx[615]) * xx[6];
  xx[553] = (xx[67] * xx[609] + xx[616]) * xx[6];
  xx[614] = xx[610];
  xx[615] = xx[303];
  xx[616] = xx[553];
  pm_math_Vector3_cross_ra(xx + 335, xx + 614, xx + 625);
  xx[555] = xx[461] + xx[303];
  xx[303] = ((xx[4] * xx[4] * xx[47] + xx[9] * xx[9] * xx[47]) * xx[6] + xx[620]
             + xx[599] + xx[625] + xx[555] * xx[81]) / xx[161];
  xx[599] = xx[556] + xx[610] - xx[158] * xx[303];
  xx[600] = xx[555] - xx[84] * xx[303];
  xx[601] = xx[290] + xx[553] - xx[87] * xx[303];
  pm_math_Quaternion_xform_ra(xx + 281, xx + 599, xx + 608);
  xx[599] = - xx[608];
  xx[600] = - xx[609];
  xx[601] = - xx[610];
  solveSymmetricPosDef(xx + 531, xx + 599, 3, 1, xx + 608, xx + 614);
  pm_math_Quaternion_inverseXform_ra(xx + 281, xx + 608, xx + 599);
  xx[47] = xx[303] + pm_math_Vector3_dot_ra(xx + 579, xx + 599);
  xx[290] = xx[600] - xx[47] * xx[81];
  xx[608] = xx[599];
  xx[609] = xx[290] + xx[47] * xx[344];
  xx[610] = xx[601] - xx[47] * xx[196];
  pm_math_Quaternion_inverseXform_ra(xx + 595, xx + 608, xx + 614);
  xx[303] = (xx[47] * xx[142] * xx[142] + xx[47] * xx[144] * xx[144]) * xx[6];
  xx[461] = xx[188] * xx[614] + xx[192] * xx[615] - xx[129] * xx[303];
  xx[553] = xx[47] * xx[193];
  xx[555] = xx[47] * xx[195];
  xx[556] = (xx[553] * xx[193] + xx[555] * xx[195]) * xx[6];
  xx[569] = xx[556] - xx[47];
  xx[578] = xx[6] * (xx[555] * xx[193] - xx[553] * xx[195]);
  xx[608] = xx[569];
  xx[609] = xx[578];
  xx[610] = - xx[556];
  xx[625] = xx[599];
  xx[626] = xx[290] + xx[47] * xx[405];
  xx[627] = xx[601] - xx[47] * xx[197];
  pm_math_Quaternion_inverseXform_ra(xx + 585, xx + 625, xx + 628);
  xx[553] = pm_math_Vector3_dot_ra(xx + 549, xx + 608) + xx[258] * xx[628] + xx
    [264] * xx[629];
  xx[555] = xx[578] * xx[246];
  xx[600] = xx[246] * xx[569];
  xx[608] = xx[556] + xx[553];
  xx[609] = xx[569] + xx[6] * (xx[204] * xx[555] - xx[600] * xx[246]);
  xx[610] = xx[578] - (xx[204] * xx[600] + xx[555] * xx[246]) * xx[6];
  xx[611] = - xx[608];
  xx[555] = xx[628] + xx[608] * xx[249];
  xx[556] = xx[629] - xx[553] * xx[59] - xx[608] * xx[260];
  xx[569] = xx[246] * xx[556];
  xx[578] = xx[246] * xx[555];
  xx[600] = pm_math_Vector3_dot_ra(xx + 574, xx + 609) + (xx[555] + xx[6] * (xx
    [204] * xx[569] - xx[578] * xx[246])) * xx[244] + xx[236] * (xx[556] - (xx
    [204] * xx[578] + xx[569] * xx[246]) * xx[6]);
  xx[555] = xx[303] + xx[461];
  xx[303] = xx[615] - xx[59] * xx[461] - xx[555] * xx[184];
  xx[556] = xx[341] * (xx[303] - (xx[155] * xx[177] * (xx[614] + xx[555] * xx
    [182]) + xx[177] * xx[303] * xx[177]) * xx[6]) - xx[555] * xx[371];
  xx[303] = xx[466] * xx[461] - (xx[553] * xx[433] + xx[600] * xx[385]) + xx[571]
    * xx[556];
  xx[546] = xx[9] * xx[42] - xx[37] * xx[4];
  xx[547] = (xx[255] * xx[546] + xx[348] * xx[546]) * xx[6];
  xx[255] = (xx[300] * xx[4] + xx[548]) * xx[6] - xx[547];
  xx[300] = xx[255] / xx[572];
  xx[348] = xx[83] * xx[300];
  xx[548] = xx[348] * xx[42];
  xx[555] = xx[6] * xx[37] * xx[548];
  xx[569] = xx[6] * xx[548] * xx[42] - xx[348];
  xx[348] = xx[51] * xx[569] - xx[49] * xx[555] - xx[159] * xx[300];
  xx[548] = (xx[4] * xx[557] + xx[584]) * xx[6] + (xx[271] + xx[271]) * xx[6] -
    xx[547];
  xx[271] = (xx[348] + xx[59] * xx[569] + xx[548]) / xx[63];
  xx[547] = xx[555] - xx[60] * xx[271];
  xx[555] = xx[569] - xx[38] * xx[271];
  xx[557] = xx[9] * xx[555];
  xx[569] = xx[9] * xx[547];
  xx[578] = xx[557] - xx[4] * xx[547];
  xx[582] = - xx[557];
  xx[583] = xx[569];
  xx[584] = xx[578];
  pm_math_Vector3_cross_ra(xx + 285, xx + 582, xx + 608);
  xx[582] = xx[547] + xx[6] * (xx[608] - xx[4] * xx[557]);
  xx[547] = xx[69] * xx[123] - xx[78] * xx[67];
  xx[557] = (xx[563] * xx[547] + xx[591] * xx[547]) * xx[6];
  xx[563] = (xx[577] * xx[67] + xx[607]) * xx[6] - xx[557];
  xx[577] = xx[563] / xx[120];
  xx[583] = xx[114] * xx[577];
  xx[584] = xx[119] * xx[577];
  xx[591] = xx[584] * xx[123];
  xx[605] = xx[583] * xx[123];
  xx[606] = xx[583] - (xx[78] * xx[591] + xx[605] * xx[123]) * xx[6];
  xx[583] = (xx[67] * xx[613] + xx[619]) * xx[6] + (xx[325] + xx[325]) * xx[6] -
    xx[557];
  xx[325] = xx[584] + xx[6] * (xx[78] * xx[605] - xx[591] * xx[123]);
  xx[557] = xx[118] * xx[577] + xx[325] * xx[137] - xx[126] * xx[606];
  xx[584] = (xx[583] - (xx[557] + xx[325] * xx[59])) / xx[134];
  xx[591] = xx[606] + xx[139] * xx[584];
  xx[605] = xx[325] + xx[133] * xx[584];
  xx[325] = xx[605] * xx[69];
  xx[606] = xx[591] * xx[69];
  xx[607] = xx[325] - xx[591] * xx[67];
  xx[611] = - xx[325];
  xx[612] = xx[606];
  xx[613] = xx[607];
  pm_math_Vector3_cross_ra(xx + 566, xx + 611, xx + 614);
  xx[611] = xx[591] + xx[6] * (xx[614] - xx[325] * xx[67]);
  xx[325] = xx[348] - xx[40] * xx[271];
  xx[348] = xx[555] + (xx[4] * xx[569] + xx[609]) * xx[6];
  xx[555] = (xx[4] * xx[578] + xx[610]) * xx[6];
  xx[608] = xx[582];
  xx[609] = xx[348];
  xx[610] = xx[555];
  pm_math_Vector3_cross_ra(xx + 276, xx + 608, xx + 617);
  xx[569] = xx[308] * xx[577];
  xx[578] = xx[569] * xx[123];
  xx[591] = xx[316] * xx[577];
  xx[608] = xx[591] * xx[123];
  xx[618] = xx[6] * (xx[578] * xx[123] - xx[78] * xx[608]) - xx[569] + xx[326] *
    xx[584];
  xx[619] = xx[591] - (xx[78] * xx[578] + xx[608] * xx[123]) * xx[6] + xx[319] *
    xx[584];
  xx[620] = xx[557] + xx[117] * xx[584];
  pm_math_Quaternion_xform_ra(xx + 621, xx + 618, xx + 608);
  xx[557] = xx[605] + (xx[606] * xx[67] + xx[615]) * xx[6];
  xx[569] = (xx[67] * xx[607] + xx[616]) * xx[6];
  xx[605] = xx[611];
  xx[606] = xx[557];
  xx[607] = xx[569];
  pm_math_Vector3_cross_ra(xx + 335, xx + 605, xx + 612);
  xx[578] = xx[348] + xx[557];
  xx[348] = ((xx[4] * xx[4] * xx[325] + xx[9] * xx[9] * xx[325]) * xx[6] + xx
             [617] + xx[608] + xx[612] + xx[578] * xx[81]) / xx[161];
  xx[605] = xx[582] + xx[611] - xx[158] * xx[348];
  xx[606] = xx[578] - xx[84] * xx[348];
  xx[607] = xx[555] + xx[569] - xx[87] * xx[348];
  pm_math_Quaternion_xform_ra(xx + 281, xx + 605, xx + 608);
  xx[605] = - xx[608];
  xx[606] = - xx[609];
  xx[607] = - xx[610];
  solveSymmetricPosDef(xx + 531, xx + 605, 3, 1, xx + 608, xx + 611);
  pm_math_Quaternion_inverseXform_ra(xx + 281, xx + 608, xx + 605);
  xx[325] = xx[348] + pm_math_Vector3_dot_ra(xx + 579, xx + 605);
  xx[348] = xx[606] - xx[325] * xx[81];
  xx[608] = xx[605];
  xx[609] = xx[348] + xx[325] * xx[344];
  xx[610] = xx[607] - xx[325] * xx[196];
  pm_math_Quaternion_inverseXform_ra(xx + 595, xx + 608, xx + 611);
  xx[555] = (xx[325] * xx[142] * xx[142] + xx[325] * xx[144] * xx[144]) * xx[6];
  xx[557] = xx[188] * xx[611] + xx[192] * xx[612] - xx[129] * xx[555];
  xx[569] = xx[325] * xx[193];
  xx[578] = xx[325] * xx[195];
  xx[582] = (xx[569] * xx[193] + xx[578] * xx[195]) * xx[6];
  xx[591] = xx[582] - xx[325];
  xx[606] = xx[6] * (xx[578] * xx[193] - xx[569] * xx[195]);
  xx[608] = xx[591];
  xx[609] = xx[606];
  xx[610] = - xx[582];
  xx[613] = xx[605];
  xx[614] = xx[348] + xx[325] * xx[405];
  xx[615] = xx[607] - xx[325] * xx[197];
  pm_math_Quaternion_inverseXform_ra(xx + 585, xx + 613, xx + 616);
  xx[569] = pm_math_Vector3_dot_ra(xx + 549, xx + 608) + xx[258] * xx[616] + xx
    [264] * xx[617];
  xx[578] = xx[606] * xx[246];
  xx[608] = xx[246] * xx[591];
  xx[609] = xx[582] + xx[569];
  xx[613] = xx[591] + xx[6] * (xx[204] * xx[578] - xx[608] * xx[246]);
  xx[614] = xx[606] - (xx[204] * xx[608] + xx[578] * xx[246]) * xx[6];
  xx[615] = - xx[609];
  xx[578] = xx[616] + xx[609] * xx[249];
  xx[582] = xx[617] - xx[569] * xx[59] - xx[609] * xx[260];
  xx[591] = xx[246] * xx[582];
  xx[606] = xx[246] * xx[578];
  xx[608] = pm_math_Vector3_dot_ra(xx + 574, xx + 613) + (xx[578] + xx[6] * (xx
    [204] * xx[591] - xx[606] * xx[246])) * xx[244] + xx[236] * (xx[582] - (xx
    [204] * xx[606] + xx[591] * xx[246]) * xx[6]);
  xx[578] = xx[555] + xx[557];
  xx[555] = xx[612] - xx[59] * xx[557] - xx[578] * xx[184];
  xx[582] = xx[341] * (xx[555] - (xx[155] * xx[177] * (xx[611] + xx[578] * xx
    [182]) + xx[177] * xx[555] * xx[177]) * xx[6]) - xx[578] * xx[371];
  xx[555] = xx[466] * xx[557] - (xx[569] * xx[433] + xx[608] * xx[385]) + xx[571]
    * xx[582];
  xx[578] = xx[562] * xx[461] - (xx[553] * xx[396] + xx[600] * xx[391]) + xx[554]
    * xx[556];
  xx[461] = xx[562] * xx[557] - (xx[569] * xx[396] + xx[608] * xx[391]) + xx[554]
    * xx[582];
  xx[608] = xx[463];
  xx[609] = xx[44];
  xx[610] = xx[110];
  xx[44] = xx[47] * xx[67];
  xx[110] = xx[47] * xx[69];
  xx[463] = (xx[44] * xx[67] + xx[110] * xx[69]) * xx[6];
  xx[553] = xx[463] - xx[47];
  xx[556] = xx[6] * (xx[110] * xx[67] - xx[44] * xx[69]);
  xx[611] = xx[553];
  xx[612] = xx[556];
  xx[613] = - xx[463];
  xx[614] = xx[599];
  xx[615] = xx[290] + xx[47] * xx[328];
  xx[616] = xx[601] - xx[47] * xx[71];
  pm_math_Quaternion_inverseXform_ra(xx + 621, xx + 614, xx + 617);
  xx[44] = xx[323] - (pm_math_Vector3_dot_ra(xx + 608, xx + 611) + xx[135] * xx
                      [617] + xx[141] * xx[618]);
  xx[611] = - xx[321];
  xx[612] = xx[306];
  xx[613] = xx[140];
  xx[110] = xx[556] * xx[123];
  xx[140] = xx[123] * xx[553];
  xx[306] = xx[44] - xx[463];
  xx[614] = xx[553] + xx[6] * (xx[78] * xx[110] - xx[140] * xx[123]);
  xx[615] = xx[556] - (xx[78] * xx[140] + xx[110] * xx[123]) * xx[6];
  xx[616] = xx[306];
  xx[110] = xx[617] - xx[126] * xx[306];
  xx[140] = xx[618] + xx[59] * xx[44] + xx[137] * xx[306];
  xx[306] = xx[140] * xx[123];
  xx[321] = xx[110] * xx[123];
  xx[617] = xx[599];
  xx[618] = xx[290] + xx[47] * xx[275];
  xx[619] = xx[601] - xx[47] * xx[272];
  pm_math_Quaternion_inverseXform_ra(xx + 423, xx + 617, xx + 599);
  xx[290] = (xx[47] * xx[4] * xx[4] + xx[47] * xx[9] * xx[9]) * xx[6];
  xx[47] = xx[252] + xx[64] * xx[599] + xx[66] * xx[600] - xx[419] * xx[290];
  xx[252] = xx[290] + xx[47];
  xx[290] = xx[600] - xx[47] * xx[59] - xx[252] * xx[51];
  xx[323] = xx[325] * xx[67];
  xx[463] = xx[325] * xx[69];
  xx[553] = (xx[323] * xx[67] + xx[463] * xx[69]) * xx[6];
  xx[556] = xx[553] - xx[325];
  xx[557] = xx[6] * (xx[463] * xx[67] - xx[323] * xx[69]);
  xx[617] = xx[556];
  xx[618] = xx[557];
  xx[619] = - xx[553];
  xx[625] = xx[605];
  xx[626] = xx[348] + xx[325] * xx[328];
  xx[627] = xx[607] - xx[325] * xx[71];
  pm_math_Quaternion_inverseXform_ra(xx + 621, xx + 625, xx + 628);
  xx[323] = xx[584] - (pm_math_Vector3_dot_ra(xx + 608, xx + 617) + xx[135] *
                       xx[628] + xx[141] * xx[629]);
  xx[463] = xx[557] * xx[123];
  xx[569] = xx[123] * xx[556];
  xx[582] = xx[323] - xx[553];
  xx[617] = xx[556] + xx[6] * (xx[78] * xx[463] - xx[569] * xx[123]);
  xx[618] = xx[557] - (xx[78] * xx[569] + xx[463] * xx[123]) * xx[6];
  xx[619] = xx[582];
  xx[463] = xx[628] - xx[126] * xx[582];
  xx[553] = xx[629] + xx[59] * xx[323] + xx[137] * xx[582];
  xx[556] = xx[553] * xx[123];
  xx[557] = xx[463] * xx[123];
  xx[569] = xx[577] - (pm_math_Vector3_dot_ra(xx + 611, xx + 617) + (xx[463] +
    xx[6] * (xx[78] * xx[556] - xx[557] * xx[123])) * xx[121] + xx[112] * (xx
    [553] - (xx[78] * xx[557] + xx[556] * xx[123]) * xx[6]));
  xx[617] = xx[605];
  xx[618] = xx[348] + xx[325] * xx[275];
  xx[619] = xx[607] - xx[325] * xx[272];
  pm_math_Quaternion_inverseXform_ra(xx + 423, xx + 617, xx + 605);
  xx[348] = (xx[325] * xx[4] * xx[4] + xx[325] * xx[9] * xx[9]) * xx[6];
  xx[325] = xx[271] + xx[64] * xx[605] + xx[66] * xx[606] - xx[419] * xx[348];
  xx[271] = xx[348] + xx[325];
  xx[348] = xx[606] - xx[325] * xx[59] - xx[271] * xx[51];
  xx[463] = xx[300] + xx[341] * (xx[348] - (xx[37] * xx[42] * (xx[605] + xx[271]
    * xx[49]) + xx[42] * xx[348] * xx[42]) * xx[6]) - xx[271] * xx[371];
  xx[271] = xx[564] * xx[323] + xx[603] * xx[569] + xx[325] * xx[279] + xx[463] *
    xx[361];
  xx[625] = xx[433] * xx[388] + xx[385] * (xx[382] - (pm_math_Vector3_dot_ra(xx
    + 574, xx + 592) + (xx[263] + xx[6] * (xx[204] * xx[399] - xx[400] * xx[246]))
    * xx[244] + xx[236] * (xx[367] - (xx[204] * xx[400] + xx[399] * xx[246]) *
    xx[6]))) + xx[324] * xx[466] + (xx[573] + xx[341] * (xx[227] - (xx[155] *
    xx[177] * (xx[589] + xx[370] * xx[182]) + xx[177] * xx[227] * xx[177]) * xx
    [6]) - xx[370] * xx[371]) * xx[571];
  xx[626] = xx[342];
  xx[627] = xx[303];
  xx[628] = xx[555];
  xx[629] = xx[342];
  xx[630] = xx[396] * xx[552] + xx[561] * xx[391] + xx[409] * xx[562] + xx[439] *
    xx[554];
  xx[631] = xx[578];
  xx[632] = xx[461];
  xx[633] = xx[303];
  xx[634] = xx[578];
  xx[635] = xx[564] * xx[44] + xx[603] * (xx[604] - (pm_math_Vector3_dot_ra(xx +
    611, xx + 614) + (xx[110] + xx[6] * (xx[78] * xx[306] - xx[321] * xx[123])) *
    xx[121] + xx[112] * (xx[140] - (xx[78] * xx[321] + xx[306] * xx[123]) * xx[6])))
    + xx[47] * xx[279] + (xx[403] + xx[341] * (xx[290] - (xx[37] * xx[42] * (xx
    [599] + xx[252] * xx[49]) + xx[42] * xx[290] * xx[42]) * xx[6]) - xx[252] *
    xx[371]) * xx[361];
  xx[636] = xx[271];
  xx[637] = xx[555];
  xx[638] = xx[461];
  xx[639] = xx[271];
  xx[640] = xx[583] * xx[323] + xx[569] * xx[563] + xx[325] * xx[548] + xx[463] *
    xx[255];
  xx[44] = xx[193] * state[7];
  xx[47] = xx[195] * state[7];
  xx[110] = (xx[193] * xx[44] + xx[195] * xx[47]) * xx[6];
  xx[140] = state[7] - xx[110];
  xx[227] = xx[6] * (xx[195] * xx[44] - xx[193] * xx[47]);
  xx[44] = xx[227] * xx[246];
  xx[47] = xx[246] * xx[140];
  xx[252] = xx[140] + xx[6] * (xx[204] * xx[44] - xx[47] * xx[246]);
  xx[263] = xx[227] - (xx[204] * xx[47] + xx[44] * xx[246]) * xx[6];
  xx[44] = xx[110] + state[9];
  xx[47] = xx[44] + state[11];
  xx[323] = xx[252];
  xx[324] = xx[263];
  xx[325] = xx[47];
  xx[555] = xx[252] * xx[19];
  xx[556] = xx[101] * xx[263];
  xx[557] = xx[47] * xx[115];
  pm_math_Vector3_cross_ra(xx + 323, xx + 555, xx + 591);
  xx[271] = xx[231] * xx[263];
  xx[290] = xx[252] * xx[231];
  xx[300] = xx[252] + xx[6] * (xx[226] * xx[271] - xx[290] * xx[231]);
  xx[303] = xx[263] - (xx[226] * xx[290] + xx[271] * xx[231]) * xx[6];
  xx[271] = xx[47] + state[13];
  xx[555] = xx[300];
  xx[556] = xx[303];
  xx[557] = xx[271];
  xx[290] = 4.363639999999999e-3;
  xx[599] = xx[300] * xx[21];
  xx[600] = xx[21] * xx[303];
  xx[601] = xx[271] * xx[290];
  pm_math_Vector3_cross_ra(xx + 555, xx + 599, xx + 604);
  xx[306] = 0.0;
  xx[614] = xx[7];
  xx[615] = xx[306];
  xx[616] = xx[306];
  xx[617] = xx[306];
  xx[618] = xx[306];
  xx[619] = xx[306];
  xx[620] = xx[306];
  xx[321] = xx[0] * xx[3];
  xx[342] = xx[0] * xx[5];
  xx[641] = xx[321] + xx[321];
  xx[642] = xx[342] + xx[342];
  xx[643] = xx[321] - xx[321];
  xx[644] = - (xx[342] - xx[342]);
  pm_math_Quaternion_compose_ra(xx + 641, xx + 585, xx + 645);
  xx[321] = xx[648] * xx[246] - xx[204] * xx[645];
  xx[342] = xx[645] * xx[246] + xx[204] * xx[648];
  xx[348] = xx[204] * xx[646] + xx[647] * xx[246];
  xx[367] = xx[646] * xx[246] - xx[204] * xx[647];
  xx[555] = - xx[348];
  xx[556] = xx[367];
  xx[557] = - xx[342];
  xx[370] = xx[339] * xx[367];
  xx[382] = xx[348] * xx[339] + xx[342] * xx[48];
  xx[388] = xx[48] * xx[367];
  xx[599] = - xx[370];
  xx[600] = - xx[382];
  xx[601] = - xx[388];
  pm_math_Vector3_cross_ra(xx + 555, xx + 599, xx + 649);
  xx[399] = xx[648] * xx[249];
  xx[400] = xx[260] * xx[648];
  xx[403] = xx[260] * xx[647] - xx[646] * xx[249];
  xx[555] = - xx[399];
  xx[556] = xx[400];
  xx[557] = - xx[403];
  pm_math_Vector3_cross_ra(xx + 646, xx + 555, xx + 599);
  pm_math_Quaternion_xform_ra(xx + 641, xx + 413, xx + 555);
  xx[409] = xx[273] * xx[5];
  xx[439] = xx[409] * xx[5];
  xx[461] = xx[273] * xx[3];
  xx[463] = xx[461] * xx[3];
  xx[552] = xx[6] * (xx[439] - xx[463]);
  xx[553] = xx[0] * xx[0] * xx[552];
  xx[561] = xx[273] - (xx[439] + xx[463]) * xx[6];
  xx[273] = xx[0] * xx[0] * xx[561];
  xx[0] = xx[6] * (xx[553] - xx[273]) - xx[552] + state[2];
  xx[439] = (xx[409] * xx[3] + xx[461] * xx[5]) * xx[6];
  xx[3] = xx[439] + state[1];
  xx[5] = (xx[553] + xx[273]) * xx[6] - (xx[561] + state[0]) + 0.4;
  xx[652] = - (xx[226] * xx[321] + xx[342] * xx[231]);
  xx[653] = xx[348] * xx[226] - xx[231] * xx[367];
  xx[654] = - (xx[226] * xx[367] + xx[348] * xx[231]);
  xx[655] = xx[342] * xx[226] - xx[231] * xx[321];
  xx[656] = xx[48] + (xx[649] - xx[370] * xx[321]) * xx[6] + xx[260] + (xx[599]
    - xx[645] * xx[399]) * xx[6] + xx[555] + xx[0];
  xx[657] = (xx[650] - xx[321] * xx[382]) * xx[6] + (xx[645] * xx[400] + xx[600])
    * xx[6] + xx[249] + xx[556] + xx[3];
  xx[658] = xx[6] * (xx[651] - xx[388] * xx[321]) - xx[339] + xx[6] * (xx[601] -
    xx[403] * xx[645]) + xx[557] + xx[5];
  bb[0] = sm_core_compiler_computeProximityInfoBrickCylinder(
    blance_leg_1d80934b_1_geometry_2(NULL), blance_leg_1d80934b_1_geometry_1
    (NULL), (pm_math_Transform3 *)(xx + 614), (pm_math_Transform3 *)(xx + 652),
    xx + 273, (pm_math_Vector3 *)(xx + 555), (pm_math_Vector3 *)(xx + 599),
    (pm_math_Vector3 *)(xx + 645), (pm_math_Vector3 *)(xx + 648));
  xx[659] = state[3];
  xx[660] = state[4];
  xx[661] = state[5];
  pm_math_Quaternion_inverseXform_ra(xx + 281, xx + 659, xx + 662);
  xx[321] = xx[81] * state[7];
  xx[342] = xx[663] + xx[321];
  xx[348] = xx[405] * state[7];
  xx[367] = xx[197] * state[7];
  xx[659] = xx[662];
  xx[660] = xx[342] - xx[348];
  xx[661] = xx[367] + xx[664];
  pm_math_Quaternion_inverseXform_ra(xx + 585, xx + 659, xx + 665);
  xx[370] = xx[44] * xx[249];
  xx[382] = xx[665] - xx[370];
  xx[388] = xx[44] * xx[260];
  xx[399] = xx[59] * state[9];
  xx[400] = xx[388] + xx[666] + xx[399];
  xx[403] = xx[400] * xx[246];
  xx[409] = xx[382] * xx[246];
  xx[461] = xx[339] * xx[263];
  xx[463] = xx[382] + xx[6] * (xx[204] * xx[403] - xx[409] * xx[246]) - xx[461];
  xx[382] = xx[47] * xx[48] + xx[252] * xx[339];
  xx[553] = xx[48] * state[11];
  xx[569] = xx[382] + xx[400] - (xx[204] * xx[409] + xx[403] * xx[246]) * xx[6]
    + xx[553];
  xx[400] = xx[569] * xx[231];
  xx[403] = xx[463] * xx[231];
  xx[409] = xx[260] * xx[227] - xx[249] * xx[140];
  xx[573] = xx[48] * xx[263];
  xx[668] = xx[300];
  xx[669] = xx[303];
  xx[670] = xx[271];
  xx[671] = xx[463] + xx[6] * (xx[226] * xx[400] - xx[403] * xx[231]);
  xx[672] = xx[569] - (xx[226] * xx[403] + xx[400] * xx[231]) * xx[6];
  xx[673] = xx[667] - xx[409] - xx[573];
  xx[271] = 1.0e6;
  xx[400] = 1000.0;
  xx[403] = 1.0e-4;
  xx[463] = 0.3;
  xx[569] = 0.2119573811760597;
  xx[577] = 9.126024771145405e-4;
  sm_core_compiler_computeContactWrenches(
    0, 1, bb[0], xx + 273, (const pm_math_Vector3 *)(xx + 555), (const
    pm_math_Vector3 *)(xx + 599), (const pm_math_Vector3 *)(xx + 645), (const
    pm_math_Vector3 *)(xx + 648),
    (const pm_math_Transform3 *)(xx + 614), (const pm_math_Transform3 *)(xx +
    614), (const pm_math_Transform3 *)(xx + 614), (const pm_math_Transform3 *)
    (xx + 652), NULL, (const pm_math_SpatialVector *)(xx + 668),
    0, 1, xx[271], xx[400], xx[403], xx[463], xx[569], xx[577], NULL, NULL,
    NULL, (pm_math_SpatialVector *)(xx + 674));
  xx[273] = - xx[1];
  xx[555] = 4.0;
  xx[645] = xx[1];
  xx[646] = xx[1];
  xx[647] = xx[273];
  xx[648] = xx[273];
  xx[649] = xx[306];
  xx[650] = xx[555];
  xx[651] = xx[306];
  bb[0] = sm_core_compiler_computeProximityInfoCxpolyCylinder(
    blance_leg_1d80934b_1_geometry_0(NULL), blance_leg_1d80934b_1_geometry_1
    (NULL), (pm_math_Transform3 *)(xx + 645), (pm_math_Transform3 *)(xx + 652),
    xx + 1, (pm_math_Vector3 *)(xx + 599), (pm_math_Vector3 *)(xx + 659),
    (pm_math_Vector3 *)(xx + 665), (pm_math_Vector3 *)(xx + 680));
  sm_core_compiler_computeContactWrenches(
    0, 1, bb[0], xx + 1, (const pm_math_Vector3 *)(xx + 599), (const
    pm_math_Vector3 *)(xx + 659), (const pm_math_Vector3 *)(xx + 665), (const
    pm_math_Vector3 *)(xx + 680),
    (const pm_math_Transform3 *)(xx + 645), (const pm_math_Transform3 *)(xx +
    614), (const pm_math_Transform3 *)(xx + 645), (const pm_math_Transform3 *)
    (xx + 652), NULL, (const pm_math_SpatialVector *)(xx + 668),
    0, 1, xx[271], xx[400], xx[403], xx[463], xx[569], xx[577], NULL, NULL,
    NULL, (pm_math_SpatialVector *)(xx + 683));
  xx[1] = xx[606] - xx[676] - xx[685];
  xx[273] = input[0] - xx[1];
  xx[599] = - xx[461];
  xx[600] = xx[382];
  xx[601] = - xx[573];
  pm_math_Vector3_cross_ra(xx + 323, xx + 599, xx + 652);
  xx[323] = xx[652] * xx[231];
  xx[324] = xx[653] * xx[231];
  xx[325] = xx[100] * (xx[653] - (xx[226] * xx[323] + xx[324] * xx[231]) * xx[6])
    - (xx[678] + xx[687]);
  xx[382] = (xx[652] + xx[6] * (xx[226] * xx[324] - xx[323] * xx[231])) * xx[100]
    - (xx[677] + xx[686]);
  xx[323] = xx[231] * xx[382];
  xx[324] = xx[231] * xx[325];
  xx[461] = xx[325] + xx[6] * (xx[226] * xx[323] - xx[324] * xx[231]);
  xx[325] = xx[461] * xx[48];
  xx[599] = xx[140];
  xx[600] = xx[227];
  xx[601] = xx[44];
  xx[655] = - xx[370];
  xx[656] = xx[388];
  xx[657] = - xx[409];
  pm_math_Vector3_cross_ra(xx + 599, xx + 655, xx + 658);
  xx[370] = xx[659] * xx[246];
  xx[388] = xx[658] * xx[246];
  xx[409] = xx[658] + xx[6] * (xx[204] * xx[370] - xx[388] * xx[246]) - (xx[44]
    + xx[47]) * xx[553];
  xx[47] = xx[659] - (xx[204] * xx[388] + xx[370] * xx[246]) * xx[6];
  xx[370] = xx[263] * state[11];
  xx[263] = xx[252] * state[11];
  xx[388] = xx[237] * xx[409] + xx[230] * xx[47] + xx[239] * xx[370] + xx[263] *
    xx[393];
  xx[230] = xx[593] + xx[1] + xx[273] + xx[325] + xx[388];
  xx[237] = xx[461] + xx[409] * xx[251] + xx[233] * xx[47] + xx[368] * xx[370] +
    xx[263] * xx[392];
  xx[233] = xx[237] * xx[48];
  xx[239] = (xx[230] + xx[233]) / xx[243];
  xx[655] = xx[207] * xx[86];
  xx[656] = xx[406] * xx[157];
  xx[657] = xx[80] * xx[61];
  pm_math_Vector3_cross_ra(xx + 163, xx + 655, xx + 665);
  xx[163] = xx[214] * state[27];
  xx[164] = xx[543] + xx[280] * xx[163];
  xx[165] = xx[212] * state[27];
  xx[214] = xx[544] - xx[416] * xx[165];
  xx[251] = xx[42] * xx[214];
  xx[393] = xx[164] * xx[42];
  xx[373] = ((xx[212] + xx[212]) * xx[199] + xx[375]) * xx[35];
  xx[199] = xx[157] * state[25];
  xx[157] = xx[86] * state[25];
  xx[212] = xx[59] * state[25];
  xx[374] = xx[272] * state[7] * state[7];
  xx[375] = xx[9] * xx[374];
  xx[543] = xx[275] * state[7] * state[7];
  xx[544] = xx[375] - xx[4] * xx[543];
  xx[556] = xx[9] * xx[543];
  xx[655] = xx[544];
  xx[656] = xx[556];
  xx[657] = - xx[375];
  pm_math_Vector3_cross_ra(xx + 285, xx + 655, xx + 668);
  xx[557] = (xx[86] + xx[86]) * xx[212] + (xx[4] * xx[375] + xx[670]) * xx[6] -
    xx[543];
  xx[86] = xx[665] + xx[164] - (xx[37] * xx[251] + xx[393] * xx[42]) * xx[6] +
    xx[373] * xx[49] + xx[418] * xx[199] - xx[421] * xx[157] + xx[557] * xx[8];
  xx[164] = xx[666] + xx[214] + xx[6] * (xx[37] * xx[393] - xx[251] * xx[42]) -
    xx[51] * xx[373] + xx[422] * xx[199] - xx[417] * xx[157] - xx[557] * xx[261];
  xx[214] = xx[160] / xx[572];
  xx[251] = xx[209] - xx[83] * xx[214];
  xx[375] = xx[206] * xx[42];
  xx[393] = xx[37] * xx[375];
  xx[417] = xx[42] * xx[251];
  xx[418] = xx[251] + xx[6] * (xx[393] - xx[417] * xx[42]);
  xx[251] = xx[375] * xx[42];
  xx[375] = xx[206] - (xx[37] * xx[417] + xx[251]) * xx[6];
  xx[417] = xx[6] * (xx[668] - xx[4] * xx[544]) - (xx[85] + xx[80]) * xx[212];
  xx[80] = xx[6] * (xx[669] - xx[4] * xx[556]) - xx[374];
  xx[85] = xx[58] * xx[417] + xx[53] * xx[80];
  xx[53] = xx[667] + xx[545] - xx[159] * xx[214] + xx[51] * xx[418] - xx[49] *
    xx[375] + xx[85];
  xx[58] = 1.850049007113989;
  xx[212] = state[24] + xx[58];
  if (xx[306] < xx[212])
    xx[212] = xx[306];
  xx[374] = 1.74532925199433e-3;
  xx[421] = - (xx[212] / xx[374]);
  if (xx[7] < xx[421])
    xx[421] = xx[7];
  xx[422] = 3.0;
  xx[543] = 5729.577951308232;
  xx[544] = xx[543] * state[25];
  xx[556] = 5.729577951308232e6;
  xx[573] = xx[421] * xx[421] * (xx[422] - xx[6] * xx[421]) * ((- xx[212] == xx
    [306] ? xx[306] : - xx[544]) - xx[556] * xx[212]);
  if (xx[306] > xx[573])
    xx[573] = xx[306];
  xx[212] = 5.729577951308232e5;
  xx[421] = state[24];
  if (xx[306] > xx[421])
    xx[421] = xx[306];
  xx[578] = xx[421] / xx[374];
  if (xx[7] < xx[578])
    xx[578] = xx[7];
  xx[582] = (xx[212] * xx[421] + (xx[421] == xx[306] ? xx[306] : xx[544])) * xx
    [578] * xx[578] * (xx[422] - xx[6] * xx[578]);
  if (xx[306] > xx[582])
    xx[582] = xx[306];
  xx[421] = input[5] + xx[573] - xx[582];
  xx[544] = xx[417] * xx[52] + xx[56] * xx[80];
  xx[52] = xx[418] + xx[544];
  xx[56] = (xx[421] - (xx[53] + xx[52] * xx[59])) / xx[63];
  xx[655] = xx[86];
  xx[656] = xx[164];
  xx[657] = xx[53] + xx[40] * xx[56];
  pm_math_Quaternion_xform_ra(xx + 423, xx + 655, xx + 668);
  xx[53] = xx[46] * xx[417] + xx[80] * xx[54];
  xx[46] = xx[373] + xx[261] * xx[157] + xx[8] * xx[199] + xx[57] * xx[557];
  xx[655] = xx[375] + xx[53] + xx[60] * xx[56];
  xx[656] = xx[52] + xx[38] * xx[56];
  xx[657] = xx[46];
  pm_math_Quaternion_xform_ra(xx + 423, xx + 655, xx + 669);
  pm_math_Vector3_cross_ra(xx + 276, xx + 669, xx + 655);
  xx[8] = xx[67] * state[7];
  xx[52] = xx[69] * state[7];
  xx[54] = (xx[67] * xx[8] + xx[69] * xx[52]) * xx[6];
  xx[57] = state[7] - xx[54];
  xx[261] = xx[6] * (xx[69] * xx[8] - xx[67] * xx[52]);
  xx[8] = xx[54] + state[19];
  xx[680] = xx[57];
  xx[681] = xx[261];
  xx[682] = xx[8];
  xx[689] = xx[207] * xx[57];
  xx[690] = xx[406] * xx[261];
  xx[691] = xx[8] * xx[61];
  pm_math_Vector3_cross_ra(xx + 680, xx + 689, xx + 692);
  xx[52] = xx[261] * xx[123];
  xx[373] = xx[123] * xx[57];
  xx[375] = xx[57] + xx[6] * (xx[78] * xx[52] - xx[373] * xx[123]);
  xx[418] = xx[261] - (xx[78] * xx[373] + xx[52] * xx[123]) * xx[6];
  xx[52] = xx[8] + state[21];
  xx[689] = xx[375];
  xx[690] = xx[418];
  xx[691] = xx[52];
  xx[695] = xx[375] * xx[19];
  xx[696] = xx[101] * xx[418];
  xx[697] = xx[52] * xx[115];
  pm_math_Vector3_cross_ra(xx + 689, xx + 695, xx + 698);
  xx[19] = xx[107] * xx[418];
  xx[101] = xx[375] * xx[107];
  xx[115] = xx[375] + xx[6] * (xx[102] * xx[19] - xx[101] * xx[107]);
  xx[373] = xx[418] - (xx[102] * xx[101] + xx[19] * xx[107]) * xx[6];
  xx[19] = xx[52] + state[23];
  xx[695] = xx[115];
  xx[696] = xx[373];
  xx[697] = xx[19];
  xx[701] = xx[115] * xx[21];
  xx[702] = xx[21] * xx[373];
  xx[703] = xx[19] * xx[290];
  pm_math_Vector3_cross_ra(xx + 695, xx + 701, xx + 704);
  pm_math_Quaternion_compose_ra(xx + 641, xx + 621, xx + 707);
  xx[101] = xx[710] * xx[123] - xx[78] * xx[707];
  xx[557] = xx[707] * xx[123] + xx[78] * xx[710];
  xx[573] = xx[78] * xx[708] + xx[709] * xx[123];
  xx[578] = xx[708] * xx[123] - xx[78] * xx[709];
  xx[582] = xx[266] * xx[578];
  xx[695] = - xx[573];
  xx[696] = xx[578];
  xx[697] = - xx[557];
  xx[584] = xx[573] * xx[266] - xx[557] * xx[48];
  xx[589] = xx[48] * xx[578];
  xx[701] = xx[582];
  xx[702] = xx[584];
  xx[703] = - xx[589];
  pm_math_Vector3_cross_ra(xx + 695, xx + 701, xx + 711);
  xx[594] = xx[710] * xx[126];
  xx[607] = xx[137] * xx[710];
  xx[656] = xx[137] * xx[709] - xx[708] * xx[126];
  xx[695] = - xx[594];
  xx[696] = xx[607];
  xx[697] = - xx[656];
  pm_math_Vector3_cross_ra(xx + 708, xx + 695, xx + 701);
  pm_math_Quaternion_xform_ra(xx + 641, xx + 335, xx + 695);
  xx[714] = - (xx[102] * xx[101] + xx[557] * xx[107]);
  xx[715] = xx[573] * xx[102] - xx[107] * xx[578];
  xx[716] = - (xx[102] * xx[578] + xx[573] * xx[107]);
  xx[717] = xx[557] * xx[102] - xx[107] * xx[101];
  xx[718] = xx[48] + (xx[582] * xx[101] + xx[711]) * xx[6] + xx[137] + (xx[701]
    - xx[707] * xx[594]) * xx[6] + xx[695] + xx[0];
  xx[719] = (xx[584] * xx[101] + xx[712]) * xx[6] + (xx[707] * xx[607] + xx[702])
    * xx[6] + xx[126] + xx[696] + xx[3];
  xx[720] = xx[266] + xx[6] * (xx[713] - xx[589] * xx[101]) + xx[6] * (xx[703] -
    xx[656] * xx[707]) + xx[697] + xx[5];
  bb[0] = sm_core_compiler_computeProximityInfoBrickCylinder(
    blance_leg_1d80934b_1_geometry_2(NULL), blance_leg_1d80934b_1_geometry_1
    (NULL), (pm_math_Transform3 *)(xx + 614), (pm_math_Transform3 *)(xx + 714),
    xx + 0, (pm_math_Vector3 *)(xx + 641), (pm_math_Vector3 *)(xx + 695),
    (pm_math_Vector3 *)(xx + 701), (pm_math_Vector3 *)(xx + 707));
  xx[3] = xx[266] * xx[418];
  xx[5] = xx[328] * state[7];
  xx[101] = xx[71] * state[7];
  xx[710] = xx[662];
  xx[711] = xx[342] - xx[5];
  xx[712] = xx[101] + xx[664];
  pm_math_Quaternion_inverseXform_ra(xx + 621, xx + 710, xx + 661);
  xx[342] = xx[8] * xx[126];
  xx[557] = xx[661] - xx[342];
  xx[573] = xx[8] * xx[137];
  xx[578] = xx[59] * state[19];
  xx[582] = xx[573] + xx[662] + xx[578];
  xx[584] = xx[582] * xx[123];
  xx[589] = xx[557] * xx[123];
  xx[594] = xx[3] + xx[557] + xx[6] * (xx[78] * xx[584] - xx[589] * xx[123]);
  xx[557] = xx[52] * xx[48] - xx[375] * xx[266];
  xx[607] = xx[48] * state[21];
  xx[644] = xx[557] + xx[582] - (xx[78] * xx[589] + xx[584] * xx[123]) * xx[6] +
    xx[607];
  xx[582] = xx[644] * xx[107];
  xx[584] = xx[594] * xx[107];
  xx[589] = xx[137] * xx[261] - xx[126] * xx[57];
  xx[656] = xx[48] * xx[418];
  xx[721] = xx[115];
  xx[722] = xx[373];
  xx[723] = xx[19];
  xx[724] = xx[594] + xx[6] * (xx[102] * xx[582] - xx[584] * xx[107]);
  xx[725] = xx[644] - (xx[102] * xx[584] + xx[582] * xx[107]) * xx[6];
  xx[726] = xx[663] - xx[589] - xx[656];
  sm_core_compiler_computeContactWrenches(
    0, 1, bb[0], xx + 0, (const pm_math_Vector3 *)(xx + 641), (const
    pm_math_Vector3 *)(xx + 695), (const pm_math_Vector3 *)(xx + 701), (const
    pm_math_Vector3 *)(xx + 707),
    (const pm_math_Transform3 *)(xx + 614), (const pm_math_Transform3 *)(xx +
    614), (const pm_math_Transform3 *)(xx + 614), (const pm_math_Transform3 *)
    (xx + 714), NULL, (const pm_math_SpatialVector *)(xx + 721),
    0, 1, xx[271], xx[400], xx[403], xx[463], xx[569], xx[577], NULL, NULL,
    NULL, (pm_math_SpatialVector *)(xx + 661));
  bb[0] = sm_core_compiler_computeProximityInfoCxpolyCylinder(
    blance_leg_1d80934b_1_geometry_0(NULL), blance_leg_1d80934b_1_geometry_1
    (NULL), (pm_math_Transform3 *)(xx + 645), (pm_math_Transform3 *)(xx + 714),
    xx + 0, (pm_math_Vector3 *)(xx + 641), (pm_math_Vector3 *)(xx + 695),
    (pm_math_Vector3 *)(xx + 701), (pm_math_Vector3 *)(xx + 707));
  sm_core_compiler_computeContactWrenches(
    0, 1, bb[0], xx + 0, (const pm_math_Vector3 *)(xx + 641), (const
    pm_math_Vector3 *)(xx + 695), (const pm_math_Vector3 *)(xx + 701), (const
    pm_math_Vector3 *)(xx + 707),
    (const pm_math_Transform3 *)(xx + 645), (const pm_math_Transform3 *)(xx +
    614), (const pm_math_Transform3 *)(xx + 645), (const pm_math_Transform3 *)
    (xx + 714), NULL, (const pm_math_SpatialVector *)(xx + 721),
    0, 1, xx[271], xx[400], xx[403], xx[463], xx[569], xx[577], NULL, NULL,
    NULL, (pm_math_SpatialVector *)(xx + 727));
  xx[0] = xx[704] - xx[661] - xx[727] + xx[21] * xx[373] * state[23];
  xx[19] = xx[705] - xx[662] - xx[728] - xx[21] * xx[115] * state[23];
  xx[115] = xx[107] * xx[19];
  xx[271] = xx[0] * xx[107];
  xx[614] = xx[3];
  xx[615] = xx[557];
  xx[616] = - xx[656];
  pm_math_Vector3_cross_ra(xx + 689, xx + 614, xx + 617);
  xx[3] = xx[617] * xx[107];
  xx[373] = xx[618] * xx[107];
  xx[400] = xx[100] * (xx[618] - (xx[102] * xx[3] + xx[373] * xx[107]) * xx[6])
    - (xx[665] + xx[731]);
  xx[403] = (xx[617] + xx[6] * (xx[102] * xx[373] - xx[3] * xx[107])) * xx[100]
    - (xx[664] + xx[730]);
  xx[3] = xx[107] * xx[403];
  xx[373] = xx[107] * xx[400];
  xx[463] = xx[400] + xx[6] * (xx[102] * xx[3] - xx[373] * xx[107]);
  xx[400] = xx[418] * state[21];
  xx[418] = xx[375] * state[21];
  xx[614] = - xx[342];
  xx[615] = xx[573];
  xx[616] = - xx[589];
  pm_math_Vector3_cross_ra(xx + 680, xx + 614, xx + 641);
  xx[342] = xx[642] * xx[123];
  xx[557] = xx[641] * xx[123];
  xx[569] = xx[641] + xx[6] * (xx[78] * xx[342] - xx[557] * xx[123]) - (xx[8] +
    xx[52]) * xx[607];
  xx[52] = xx[642] - (xx[78] * xx[557] + xx[342] * xx[123]) * xx[6];
  xx[342] = xx[698] + xx[0] - (xx[102] * xx[115] + xx[271] * xx[107]) * xx[6] -
    xx[463] * xx[266] + xx[420] * xx[400] - xx[418] * xx[22] - (xx[309] * xx[569]
    + xx[307] * xx[52]);
  xx[0] = xx[706] - xx[663] - xx[729];
  xx[22] = input[1] - xx[0];
  xx[420] = xx[463] * xx[48];
  xx[557] = xx[113] * xx[569] + xx[106] * xx[52] - (xx[116] * xx[400] + xx[418] *
    xx[315]);
  xx[106] = xx[700] + xx[0] + xx[22] + xx[420] + xx[557];
  xx[113] = xx[463] + xx[569] * xx[128] + xx[109] * xx[52] - (xx[307] * xx[400]
    + xx[418] * xx[314]);
  xx[109] = xx[113] * xx[48];
  xx[116] = (xx[106] + xx[109]) / xx[120];
  xx[128] = xx[342] + xx[308] * xx[116];
  xx[307] = xx[403] - (xx[102] * xx[373] + xx[3] * xx[107]) * xx[6];
  xx[3] = xx[100] * xx[619] - (xx[666] + xx[732]);
  xx[315] = (xx[375] + xx[375]) * xx[607] + xx[643];
  xx[373] = xx[699] + xx[19] + xx[6] * (xx[102] * xx[271] - xx[115] * xx[107]) +
    xx[266] * xx[307] - xx[48] * xx[3] + xx[400] * xx[462] - xx[460] * xx[418] +
    xx[313] * xx[569] + xx[314] * xx[52] - xx[315] * xx[329];
  xx[19] = xx[373] - xx[316] * xx[116];
  xx[102] = xx[123] * xx[19];
  xx[107] = xx[128] * xx[123];
  xx[115] = xx[3] + xx[418] * xx[329] + xx[145] * xx[315];
  xx[3] = xx[115] * xx[126];
  xx[145] = xx[261] * state[19];
  xx[261] = xx[57] * state[19];
  xx[266] = xx[101] * state[7];
  xx[101] = xx[69] * xx[266];
  xx[271] = xx[5] * state[7];
  xx[5] = xx[101] - xx[67] * xx[271];
  xx[314] = xx[69] * xx[271];
  xx[614] = xx[5];
  xx[615] = xx[314];
  xx[616] = - xx[101];
  pm_math_Vector3_cross_ra(xx + 566, xx + 614, xx + 617);
  xx[315] = xx[6] * (xx[617] - xx[67] * xx[5]) - (xx[54] + xx[8]) * xx[578];
  xx[5] = xx[6] * (xx[618] - xx[67] * xx[314]) - xx[266];
  xx[8] = (xx[57] + xx[57]) * xx[578] + (xx[67] * xx[101] + xx[619]) * xx[6] -
    xx[271];
  xx[54] = xx[464] * xx[145] - xx[330] * xx[261] + xx[315] * xx[320] + xx[311] *
    xx[5] + xx[8] * xx[332];
  xx[57] = state[18];
  if (xx[306] < xx[57])
    xx[57] = xx[306];
  xx[101] = - (xx[57] / xx[374]);
  if (xx[7] < xx[101])
    xx[101] = xx[7];
  xx[266] = xx[543] * state[19];
  xx[271] = xx[101] * xx[101] * (xx[422] - xx[6] * xx[101]) * ((- xx[57] == xx
    [306] ? xx[306] : - xx[266]) - xx[556] * xx[57]);
  if (xx[306] > xx[271])
    xx[271] = xx[306];
  xx[57] = state[18] - xx[58];
  if (xx[306] > xx[57])
    xx[57] = xx[306];
  xx[101] = xx[57] / xx[374];
  if (xx[7] < xx[101])
    xx[101] = xx[7];
  xx[314] = (xx[212] * xx[57] + (xx[57] == xx[306] ? xx[306] : xx[266])) * xx
    [101] * xx[101] * (xx[422] - xx[6] * xx[101]);
  if (xx[306] > xx[314])
    xx[314] = xx[306];
  xx[57] = input[4] + xx[271] - xx[314];
  xx[101] = xx[113] - xx[119] * xx[116];
  xx[266] = xx[307] + xx[111] * xx[569] + xx[52] * xx[105] - (xx[309] * xx[400]
    + xx[313] * xx[418]);
  xx[52] = xx[266] - xx[114] * xx[116];
  xx[105] = xx[123] * xx[52];
  xx[111] = xx[123] * xx[101];
  xx[271] = xx[101] + xx[6] * (xx[78] * xx[105] - xx[111] * xx[123]);
  xx[101] = xx[52] - (xx[78] * xx[111] + xx[105] * xx[123]) * xx[6];
  xx[52] = xx[322] * xx[145] - xx[317] * xx[261] + xx[130] * xx[315] + xx[79] *
    xx[5];
  xx[79] = xx[694] + xx[106] - xx[118] * xx[116] + xx[137] * xx[271] - xx[126] *
    xx[101] + xx[52];
  xx[105] = xx[145] * xx[311] - xx[312] * xx[261] + xx[122] * xx[315] + xx[127] *
    xx[5];
  xx[106] = xx[271] + xx[105];
  xx[111] = (xx[57] - (xx[79] + xx[106] * xx[59])) / xx[134];
  xx[122] = xx[137] * xx[115];
  xx[127] = xx[467] * xx[145] - xx[104] * xx[261] + xx[333] * xx[315] + xx[312] *
    xx[5] - xx[8] * xx[146];
  xx[311] = xx[692] + xx[128] - (xx[78] * xx[102] + xx[107] * xx[123]) * xx[6] +
    xx[3] + xx[54] + xx[326] * xx[111];
  xx[312] = xx[693] + xx[19] + xx[6] * (xx[78] * xx[107] - xx[102] * xx[123]) -
    xx[122] + xx[127] + xx[319] * xx[111];
  xx[313] = xx[79] + xx[117] * xx[111];
  pm_math_Quaternion_xform_ra(xx + 621, xx + 311, xx + 462);
  xx[19] = xx[145] * xx[320] - xx[333] * xx[261] + xx[131] * xx[315] + xx[108] *
    xx[5];
  xx[79] = xx[115] + xx[145] * xx[332] + xx[146] * xx[261] + xx[147] * xx[8];
  xx[311] = xx[101] + xx[19] + xx[139] * xx[111];
  xx[312] = xx[106] + xx[133] * xx[111];
  xx[313] = xx[79];
  pm_math_Quaternion_xform_ra(xx + 621, xx + 311, xx + 106);
  pm_math_Vector3_cross_ra(xx + 335, xx + 106, xx + 311);
  xx[8] = xx[142] * state[7];
  xx[101] = xx[144] * state[7];
  xx[102] = (xx[142] * xx[8] + xx[144] * xx[101]) * xx[6];
  xx[104] = state[7] - xx[102];
  xx[115] = xx[6] * (xx[144] * xx[8] - xx[142] * xx[101]);
  xx[8] = xx[102] + state[15];
  xx[312] = xx[104];
  xx[313] = xx[115];
  xx[314] = xx[8];
  xx[614] = xx[207] * xx[104];
  xx[615] = xx[406] * xx[115];
  xx[616] = xx[8] * xx[61];
  pm_math_Vector3_cross_ra(xx + 312, xx + 614, xx + 617);
  xx[101] = xx[115] * xx[177];
  xx[128] = xx[177] * xx[104];
  xx[130] = xx[104] + xx[6] * (xx[155] * xx[101] - xx[128] * xx[177]);
  xx[131] = xx[115] - (xx[155] * xx[128] + xx[101] * xx[177]) * xx[6];
  xx[101] = xx[8] + state[17];
  xx[614] = xx[130];
  xx[615] = xx[131];
  xx[616] = xx[101];
  xx[641] = xx[130] * xx[280];
  xx[642] = xx[416] * xx[131];
  xx[643] = xx[101] * xx[159];
  pm_math_Vector3_cross_ra(xx + 614, xx + 641, xx + 644);
  xx[128] = xx[131] * state[17];
  xx[131] = xx[644] + xx[280] * xx[128];
  xx[146] = xx[130] * state[17];
  xx[147] = xx[645] - xx[416] * xx[146];
  xx[271] = xx[177] * xx[147];
  xx[280] = xx[131] * xx[177];
  xx[307] = xx[48] * state[17];
  xx[614] = - (xx[8] * xx[182]);
  xx[615] = xx[8] * xx[184];
  xx[616] = - (xx[184] * xx[115] - xx[182] * xx[104]);
  pm_math_Vector3_cross_ra(xx + 312, xx + 614, xx + 641);
  xx[309] = ((xx[130] + xx[130]) * xx[307] + xx[643]) * xx[35];
  xx[130] = xx[115] * state[15];
  xx[115] = xx[104] * state[15];
  xx[312] = xx[59] * state[15];
  xx[313] = xx[196] * state[7] * state[7];
  xx[314] = xx[144] * xx[313];
  xx[317] = xx[344] * state[7] * state[7];
  xx[320] = xx[142] * xx[317] - xx[314];
  xx[322] = xx[144] * xx[317];
  xx[614] = xx[320];
  xx[615] = - xx[322];
  xx[616] = xx[314];
  pm_math_Vector3_cross_ra(xx + 558, xx + 614, xx + 647);
  xx[329] = (xx[104] + xx[104]) * xx[312] + (xx[142] * xx[314] + xx[649]) * xx[6]
    - xx[317];
  xx[104] = xx[617] + xx[131] - (xx[155] * xx[271] + xx[280] * xx[177]) * xx[6]
    + xx[309] * xx[182] + xx[132] * xx[130] - xx[310] * xx[115] + xx[329] * xx
    [73];
  xx[131] = xx[618] + xx[147] + xx[6] * (xx[155] * xx[280] - xx[271] * xx[177])
    - xx[184] * xx[309] + xx[318] * xx[130] - xx[103] * xx[115] - xx[329] * xx
    [338];
  xx[103] = xx[641] * xx[177];
  xx[132] = xx[642] * xx[177];
  xx[147] = xx[35] * (xx[642] - (xx[155] * xx[103] + xx[132] * xx[177]) * xx[6]);
  xx[271] = xx[646] + xx[48] * xx[147];
  xx[280] = xx[271] / xx[572];
  xx[310] = xx[147] - xx[83] * xx[280];
  xx[314] = xx[35] * (xx[641] + xx[6] * (xx[155] * xx[132] - xx[103] * xx[177])
                      - (xx[8] + xx[101]) * xx[307]);
  xx[35] = xx[314] * xx[177];
  xx[101] = xx[155] * xx[35];
  xx[103] = xx[177] * xx[310];
  xx[132] = xx[310] + xx[6] * (xx[101] - xx[103] * xx[177]);
  xx[307] = xx[35] * xx[177];
  xx[35] = xx[314] - (xx[155] * xx[103] + xx[307]) * xx[6];
  xx[103] = xx[6] * (xx[647] + xx[142] * xx[320]) - (xx[102] + xx[8]) * xx[312];
  xx[8] = xx[6] * (xx[648] - xx[142] * xx[322]) - xx[313];
  xx[102] = xx[189] * xx[103] + xx[45] * xx[8];
  xx[45] = xx[619] + xx[646] - xx[159] * xx[280] + xx[184] * xx[132] - xx[182] *
    xx[35] + xx[102];
  xx[189] = state[14] + xx[58];
  if (xx[306] < xx[189])
    xx[189] = xx[306];
  xx[310] = - (xx[189] / xx[374]);
  if (xx[7] < xx[310])
    xx[310] = xx[7];
  xx[312] = xx[543] * state[15];
  xx[313] = xx[310] * xx[310] * (xx[422] - xx[6] * xx[310]) * ((- xx[189] == xx
    [306] ? xx[306] : - xx[312]) - xx[556] * xx[189]);
  if (xx[306] > xx[313])
    xx[313] = xx[306];
  xx[189] = state[14];
  if (xx[306] > xx[189])
    xx[189] = xx[306];
  xx[310] = xx[189] / xx[374];
  if (xx[7] < xx[310])
    xx[310] = xx[7];
  xx[317] = (xx[212] * xx[189] + (xx[189] == xx[306] ? xx[306] : xx[312])) * xx
    [310] * xx[310] * (xx[422] - xx[6] * xx[310]);
  if (xx[306] > xx[317])
    xx[317] = xx[306];
  xx[189] = input[3] + xx[313] - xx[317];
  xx[310] = xx[103] * xx[185] + xx[176] * xx[8];
  xx[176] = xx[132] + xx[310];
  xx[132] = (xx[189] - (xx[45] + xx[176] * xx[59])) / xx[186];
  xx[614] = xx[104];
  xx[615] = xx[131];
  xx[616] = xx[45] + xx[62] * xx[132];
  pm_math_Quaternion_xform_ra(xx + 595, xx + 614, xx + 641);
  xx[45] = xx[181] * xx[103] + xx[8] * xx[41];
  xx[41] = xx[309] + xx[338] * xx[115] + xx[73] * xx[130] + xx[180] * xx[329];
  xx[614] = xx[35] + xx[45] + xx[190] * xx[132];
  xx[615] = xx[176] + xx[156] * xx[132];
  xx[616] = xx[41];
  pm_math_Quaternion_xform_ra(xx + 595, xx + 614, xx + 642);
  pm_math_Vector3_cross_ra(xx + 364, xx + 642, xx + 614);
  xx[615] = xx[207] * xx[140];
  xx[616] = xx[406] * xx[227];
  xx[617] = xx[44] * xx[61];
  pm_math_Vector3_cross_ra(xx + 599, xx + 615, xx + 647);
  xx[35] = xx[604] - xx[674] - xx[683] + xx[21] * xx[303] * state[13];
  xx[61] = xx[605] - xx[675] - xx[684] - xx[21] * xx[300] * state[13];
  xx[21] = xx[231] * xx[61];
  xx[73] = xx[35] * xx[231];
  xx[176] = xx[591] + xx[35] - (xx[226] * xx[21] + xx[73] * xx[231]) * xx[6] +
    xx[461] * xx[339] + xx[288] * xx[370] - xx[263] * xx[148] + xx[345] * xx[409]
    + xx[368] * xx[47];
  xx[35] = xx[176] - xx[369] * xx[239];
  xx[148] = xx[382] - (xx[226] * xx[324] + xx[323] * xx[231]) * xx[6];
  xx[180] = xx[100] * xx[654] - (xx[679] + xx[688]);
  xx[100] = (xx[252] + xx[252]) * xx[553] + xx[660];
  xx[181] = xx[592] + xx[61] + xx[6] * (xx[226] * xx[73] - xx[21] * xx[231]) -
    (xx[339] * xx[148] + xx[48] * xx[180]) + xx[370] * xx[334] - xx[225] * xx
    [263] - (xx[395] * xx[409] + xx[392] * xx[47] + xx[100] * xx[407]);
  xx[21] = xx[181] + xx[394] * xx[239];
  xx[61] = xx[246] * xx[21];
  xx[73] = xx[35] * xx[246];
  xx[185] = xx[180] + xx[263] * xx[407] + xx[268] * xx[100];
  xx[100] = xx[185] * xx[249];
  xx[180] = xx[227] * state[9];
  xx[207] = xx[140] * state[9];
  xx[225] = xx[348] * state[7];
  xx[226] = xx[367] * state[7];
  xx[227] = xx[195] * xx[226];
  xx[231] = xx[193] * xx[225] - xx[227];
  xx[252] = xx[195] * xx[225];
  xx[322] = xx[231];
  xx[323] = - xx[252];
  xx[324] = xx[227];
  pm_math_Vector3_cross_ra(xx + 540, xx + 322, xx + 332);
  xx[268] = xx[6] * (xx[332] + xx[193] * xx[231]) - (xx[110] + xx[44]) * xx[399];
  xx[44] = xx[6] * (xx[333] - xx[193] * xx[252]) - xx[226];
  xx[110] = (xx[140] + xx[140]) * xx[399] + (xx[193] * xx[227] + xx[334]) * xx[6]
    - xx[225];
  xx[140] = xx[346] * xx[180] - xx[297] * xx[207] + xx[268] * xx[398] + xx[234] *
    xx[44] + xx[110] * xx[410];
  xx[225] = state[8];
  if (xx[306] < xx[225])
    xx[225] = xx[306];
  xx[226] = - (xx[225] / xx[374]);
  if (xx[7] < xx[226])
    xx[226] = xx[7];
  xx[227] = xx[543] * state[9];
  xx[231] = xx[226] * xx[226] * (xx[422] - xx[6] * xx[226]) * ((- xx[225] == xx
    [306] ? xx[306] : - xx[227]) - xx[556] * xx[225]);
  if (xx[306] > xx[231])
    xx[231] = xx[306];
  xx[225] = state[8] - xx[58];
  if (xx[306] > xx[225])
    xx[225] = xx[306];
  xx[58] = xx[225] / xx[374];
  if (xx[7] < xx[58])
    xx[58] = xx[7];
  xx[7] = (xx[212] * xx[225] + (xx[225] == xx[306] ? xx[306] : xx[227])) * xx[58]
    * xx[58] * (xx[422] - xx[6] * xx[58]);
  if (xx[306] > xx[7])
    xx[7] = xx[306];
  xx[58] = input[2] + xx[231] - xx[7];
  xx[7] = xx[237] - xx[242] * xx[239];
  xx[212] = xx[148] + xx[235] * xx[409] + xx[47] * xx[229] + xx[345] * xx[370] +
    xx[395] * xx[263];
  xx[47] = xx[212] - xx[238] * xx[239];
  xx[148] = xx[246] * xx[47];
  xx[225] = xx[246] * xx[7];
  xx[226] = xx[7] + xx[6] * (xx[204] * xx[148] - xx[225] * xx[246]);
  xx[7] = xx[47] - (xx[204] * xx[225] + xx[148] * xx[246]) * xx[6];
  xx[47] = xx[331] * xx[180] - xx[355] * xx[207] + xx[253] * xx[268] + xx[205] *
    xx[44];
  xx[148] = xx[649] + xx[230] - xx[241] * xx[239] + xx[260] * xx[226] - xx[249] *
    xx[7] + xx[47];
  xx[205] = xx[180] * xx[234] - xx[372] * xx[207] + xx[245] * xx[268] + xx[250] *
    xx[44];
  xx[225] = xx[226] + xx[205];
  xx[226] = (xx[58] - (xx[148] + xx[225] * xx[59])) / xx[257];
  xx[227] = xx[260] * xx[185];
  xx[229] = xx[408] * xx[180] - xx[151] * xx[207] + xx[411] * xx[268] + xx[372] *
    xx[44] - xx[110] * xx[99];
  xx[322] = xx[647] + xx[35] - (xx[204] * xx[61] + xx[73] * xx[246]) * xx[6] +
    xx[100] + xx[140] + xx[404] * xx[226];
  xx[323] = xx[648] + xx[21] + xx[6] * (xx[204] * xx[73] - xx[61] * xx[246]) -
    xx[227] + xx[229] + xx[397] * xx[226];
  xx[324] = xx[148] + xx[240] * xx[226];
  pm_math_Quaternion_xform_ra(xx + 585, xx + 322, xx + 329);
  xx[21] = xx[180] * xx[398] - xx[411] * xx[207] + xx[254] * xx[268] + xx[232] *
    xx[44];
  xx[35] = xx[185] + xx[180] * xx[410] + xx[99] * xx[207] + xx[269] * xx[110];
  xx[230] = xx[7] + xx[21] + xx[262] * xx[226];
  xx[231] = xx[225] + xx[256] * xx[226];
  xx[232] = xx[35];
  pm_math_Quaternion_xform_ra(xx + 585, xx + 230, xx + 252);
  pm_math_Vector3_cross_ra(xx + 413, xx + 252, xx + 230);
  xx[7] = xx[321] * state[7];
  xx[61] = xx[82] * xx[7];
  xx[73] = xx[213] * xx[7];
  xx[99] = xx[670] + xx[107] + xx[643] + xx[253] + xx[73];
  xx[107] = (xx[668] + xx[655] + xx[462] + xx[311] + xx[641] + xx[614] + xx[329]
             + xx[230] + xx[61] + xx[99] * xx[81]) / xx[161];
  xx[110] = xx[289] * xx[7];
  xx[148] = xx[162] * xx[7];
  xx[230] = xx[669] + xx[106] + xx[642] + xx[252] + xx[110] - xx[158] * xx[107];
  xx[231] = xx[99] - xx[84] * xx[107];
  xx[232] = xx[671] + xx[108] + xx[644] + xx[254] + xx[148] - xx[87] * xx[107];
  pm_math_Quaternion_xform_ra(xx + 281, xx + 230, xx + 252);
  xx[230] = - xx[252];
  xx[231] = - xx[253];
  xx[232] = - xx[254];
  solveSymmetricPosDef(xx + 531, xx + 230, 3, 1, xx + 252, xx + 311);
  xx[99] = 9.806650000000001;
  xx[106] = xx[292] - xx[301] + xx[350] - xx[359] + xx[377] - xx[386] + xx[428]
    - xx[437];
  xx[108] = xx[454] - xx[29] - xx[27] - xx[445] + xx[471] - xx[92] - xx[90] -
    xx[480] + xx[498] - xx[169] - xx[167] - xx[489] + xx[507] - xx[218] - xx[216]
    - xx[516] + xx[106] * xx[81];
  xx[26] = xx[295] - xx[302] + xx[353] - xx[360] + xx[380] - xx[387] + xx[431] -
    xx[438];
  xx[27] = xx[457] - xx[32] - xx[28] - xx[448] + xx[474] - xx[95] - xx[91] - xx
    [483] + xx[501] - xx[172] - xx[168] - xx[492] + xx[510] - xx[221] - xx[217]
    - xx[519] + xx[26] * xx[81];
  xx[89] = xx[70] - xx[228] * xx[210];
  xx[90] = xx[179] - xx[228] * xx[208];
  xx[91] = xx[82] - xx[228] * xx[88];
  xx[92] = xx[291] - xx[298] + xx[349] - xx[356] + xx[376] - xx[383] + xx[427] -
    xx[434] - xx[108] * xx[210];
  xx[93] = xx[106] - xx[108] * xx[208];
  xx[94] = xx[293] - xx[304] + xx[351] - xx[362] + xx[378] - xx[389] + xx[429] -
    xx[440] - xx[108] * xx[88];
  xx[95] = xx[294] - xx[299] + xx[352] - xx[357] + xx[379] - xx[384] + xx[430] -
    xx[435] - xx[27] * xx[210];
  xx[96] = xx[26] - xx[27] * xx[208];
  xx[97] = xx[296] - xx[305] + xx[354] - xx[363] + xx[381] - xx[390] + xx[432] -
    xx[441] - xx[27] * xx[88];
  pm_math_Matrix3x3_composeTranspose_ra(xx + 89, xx + 10, xx + 26);
  pm_math_Matrix3x3_compose_ra(xx + 10, xx + 26, xx + 88);
  xx[10] = - xx[552];
  xx[11] = xx[439];
  xx[12] = - xx[561];
  pm_math_Matrix3x3_postCross_ra(xx + 522, xx + 10, xx + 26);
  xx[437] = xx[88] - xx[26];
  xx[438] = xx[89] - xx[29];
  xx[439] = xx[90] - xx[32];
  xx[440] = xx[91] - xx[27];
  xx[441] = xx[92] - xx[30];
  xx[442] = xx[93] - xx[33];
  xx[443] = xx[94] - xx[28];
  xx[444] = xx[95] - xx[31];
  xx[445] = xx[96] - xx[34];
  xx[446] = xx[522];
  xx[447] = xx[523];
  xx[448] = xx[524];
  xx[449] = xx[525];
  xx[450] = xx[526];
  xx[451] = xx[527];
  xx[452] = xx[528];
  xx[453] = xx[529];
  xx[454] = xx[530];
  solveSymmetricPosDef(xx + 531, xx + 437, 3, 6, xx + 467, xx + 10);
  xx[10] = 1.77635683940025e-15;
  xx[11] = xx[99] * xx[476] + xx[10] * xx[482];
  xx[12] = xx[99] * xx[477] + xx[10] * xx[483];
  xx[13] = xx[99] * xx[478] + xx[10] * xx[484];
  xx[14] = xx[252] + xx[11] - xx[99];
  xx[15] = xx[253] + xx[12];
  xx[16] = xx[254] + xx[13] - xx[10];
  pm_math_Quaternion_inverseXform_ra(xx + 281, xx + 14, xx + 26);
  xx[14] = xx[107] + pm_math_Vector3_dot_ra(xx + 579, xx + 26);
  xx[15] = xx[14] * xx[193];
  xx[16] = xx[14] * xx[195];
  xx[17] = (xx[15] * xx[193] + xx[16] * xx[195]) * xx[6];
  xx[18] = xx[17] - xx[14];
  xx[29] = xx[18] + xx[180];
  xx[30] = xx[6] * (xx[16] * xx[193] - xx[15] * xx[195]);
  xx[15] = xx[30] - xx[207];
  xx[16] = xx[246] * xx[15];
  xx[31] = xx[29] * xx[246];
  xx[32] = xx[18];
  xx[33] = xx[30];
  xx[34] = - xx[17];
  xx[18] = xx[27] - xx[14] * xx[81];
  xx[27] = xx[28] + xx[7];
  xx[88] = xx[26];
  xx[89] = xx[18] + xx[14] * xx[405];
  xx[90] = xx[27] - xx[14] * xx[197];
  pm_math_Quaternion_inverseXform_ra(xx + 585, xx + 88, xx + 91);
  xx[28] = xx[226] - (pm_math_Vector3_dot_ra(xx + 549, xx + 32) + xx[258] * xx
                      [91] + xx[264] * xx[92]);
  xx[30] = xx[28] - xx[17];
  xx[32] = xx[29] + xx[6] * (xx[204] * xx[16] - xx[31] * xx[246]);
  xx[33] = xx[15] - (xx[204] * xx[31] + xx[16] * xx[246]) * xx[6];
  xx[34] = xx[30];
  xx[15] = xx[91] + xx[268] - xx[249] * xx[30];
  xx[16] = xx[92] + xx[59] * xx[28] + xx[44] + xx[260] * xx[30];
  xx[17] = xx[16] * xx[246];
  xx[29] = xx[15] * xx[246];
  xx[30] = xx[239] + pm_math_Vector3_dot_ra(xx + 574, xx + 32) + (xx[15] + xx[6]
    * (xx[204] * xx[17] - xx[29] * xx[246])) * xx[244] + xx[236] * (xx[16] -
    (xx[204] * xx[29] + xx[17] * xx[246]) * xx[6]);
  xx[15] = state[11] * state[11];
  xx[16] = xx[15] * (xx[259] - xx[48]);
  xx[17] = xx[195] * xx[16];
  xx[29] = xx[249] * xx[15];
  xx[15] = xx[195] * xx[29];
  xx[31] = xx[15] + xx[193] * xx[16];
  xx[32] = - xx[15];
  xx[33] = - xx[17];
  xx[34] = xx[31];
  pm_math_Vector3_cross_ra(xx + 540, xx + 32, xx + 88);
  xx[15] = xx[202] * state[9] * state[9];
  xx[16] = xx[6] * xx[201] * state[9] * state[9];
  xx[32] = state[9] * state[9];
  xx[33] = xx[6] * xx[248] * state[11] * state[9];
  xx[34] = xx[195] * xx[33];
  xx[70] = xx[401] * state[11] * state[9];
  xx[82] = xx[195] * xx[70];
  xx[91] = xx[34] - xx[193] * xx[70];
  xx[92] = - xx[34];
  xx[93] = xx[82];
  xx[94] = xx[91];
  pm_math_Vector3_cross_ra(xx + 540, xx + 92, xx + 95);
  xx[34] = xx[224] * state[11] * state[11];
  xx[70] = xx[6] * xx[194] * state[11] * state[11];
  xx[92] = state[17] * state[17];
  xx[93] = xx[92] * (xx[183] - xx[48]);
  xx[94] = xx[144] * xx[93];
  xx[106] = xx[182] * xx[92];
  xx[92] = xx[144] * xx[106];
  xx[107] = xx[92] + xx[142] * xx[93];
  xx[166] = - xx[92];
  xx[167] = - xx[94];
  xx[168] = xx[107];
  pm_math_Vector3_cross_ra(xx + 558, xx + 166, xx + 169);
  xx[92] = xx[153] * state[15] * state[15];
  xx[93] = xx[6] * xx[152] * state[15] * state[15];
  xx[108] = state[15] * state[15];
  xx[151] = xx[6] * xx[187] * state[17] * state[15];
  xx[152] = xx[144] * xx[151];
  xx[162] = xx[150] * state[17] * state[15];
  xx[150] = xx[144] * xx[162];
  xx[166] = xx[152] - xx[142] * xx[162];
  xx[172] = - xx[152];
  xx[173] = xx[150];
  xx[174] = xx[166];
  pm_math_Vector3_cross_ra(xx + 558, xx + 172, xx + 215);
  xx[152] = xx[175] * state[17] * state[17];
  xx[162] = xx[6] * xx[143] * state[17] * state[17];
  xx[172] = xx[26];
  xx[173] = xx[18] + xx[14] * xx[344];
  xx[174] = xx[27] - xx[14] * xx[196];
  pm_math_Quaternion_inverseXform_ra(xx + 595, xx + 172, xx + 218);
  xx[143] = (xx[14] * xx[142] * xx[142] + xx[14] * xx[144] * xx[144]) * xx[6];
  xx[167] = xx[132] - (xx[188] * xx[218] + xx[192] * xx[219] - xx[129] * xx[143]);
  xx[132] = xx[167] - xx[143];
  xx[143] = xx[219] + xx[59] * xx[167] + xx[8] + xx[184] * xx[132];
  xx[168] = xx[280] + xx[371] * xx[132] + xx[341] * (xx[143] - (xx[155] * (xx
    [218] + xx[103] - xx[182] * xx[132]) * xx[177] + xx[143] * xx[177] * xx[177])
    * xx[6]);
  xx[132] = xx[6] * xx[203] * state[9] * state[9];
  xx[88] = xx[6] * xx[154] * state[15] * state[15];
  xx[95] = xx[14] * xx[67];
  xx[143] = xx[14] * xx[69];
  xx[154] = (xx[95] * xx[67] + xx[143] * xx[69]) * xx[6];
  xx[169] = xx[154] - xx[14];
  xx[172] = xx[169] + xx[145];
  xx[173] = xx[6] * (xx[143] * xx[67] - xx[95] * xx[69]);
  xx[95] = xx[173] - xx[261];
  xx[143] = xx[123] * xx[95];
  xx[174] = xx[172] * xx[123];
  xx[218] = xx[169];
  xx[219] = xx[173];
  xx[220] = - xx[154];
  xx[221] = xx[26];
  xx[222] = xx[18] + xx[14] * xx[328];
  xx[223] = xx[27] - xx[14] * xx[71];
  pm_math_Quaternion_inverseXform_ra(xx + 621, xx + 221, xx + 230);
  xx[169] = xx[111] - (pm_math_Vector3_dot_ra(xx + 608, xx + 218) + xx[135] *
                       xx[230] + xx[141] * xx[231]);
  xx[111] = xx[169] - xx[154];
  xx[218] = xx[172] + xx[6] * (xx[78] * xx[143] - xx[174] * xx[123]);
  xx[219] = xx[95] - (xx[78] * xx[174] + xx[143] * xx[123]) * xx[6];
  xx[220] = xx[111];
  xx[95] = xx[230] + xx[315] - xx[126] * xx[111];
  xx[143] = xx[231] + xx[59] * xx[169] + xx[5] + xx[137] * xx[111];
  xx[111] = xx[143] * xx[123];
  xx[154] = xx[95] * xx[123];
  xx[172] = xx[116] + pm_math_Vector3_dot_ra(xx + 611, xx + 218) + (xx[95] + xx
    [6] * (xx[78] * xx[111] - xx[154] * xx[123])) * xx[121] + xx[112] * (xx[143]
    - (xx[78] * xx[154] + xx[111] * xx[123]) * xx[6]);
  xx[95] = xx[6] * xx[75] * state[19] * state[19];
  xx[75] = xx[76] * state[19] * state[19];
  xx[111] = xx[98] * state[21] * state[21];
  xx[116] = xx[6] * xx[68] * state[21] * state[21];
  xx[68] = state[21] * state[21];
  xx[143] = xx[68] * (xx[136] - xx[48]);
  xx[136] = xx[69] * xx[143];
  xx[154] = xx[126] * xx[68];
  xx[68] = xx[69] * xx[154];
  xx[173] = xx[68] + xx[67] * xx[143];
  xx[218] = xx[68];
  xx[219] = xx[136];
  xx[220] = - xx[173];
  pm_math_Vector3_cross_ra(xx + 566, xx + 218, xx + 221);
  xx[68] = state[19] * state[19];
  xx[143] = xx[6] * xx[125] * state[21] * state[19];
  xx[125] = xx[69] * xx[143];
  xx[174] = xx[270] * state[21] * state[19];
  xx[179] = xx[69] * xx[174];
  xx[183] = xx[67] * xx[174] - xx[125];
  xx[218] = xx[125];
  xx[219] = - xx[179];
  xx[220] = xx[183];
  pm_math_Vector3_cross_ra(xx + 566, xx + 218, xx + 230);
  xx[125] = xx[6] * xx[23] * state[25] * state[25];
  xx[23] = xx[24] * state[25] * state[25];
  xx[174] = xx[39] * state[27] * state[27];
  xx[185] = xx[6] * xx[36] * state[27] * state[27];
  xx[36] = state[27] * state[27];
  xx[187] = xx[36] * (xx[50] - xx[48]);
  xx[50] = xx[9] * xx[187];
  xx[194] = xx[49] * xx[36];
  xx[36] = xx[9] * xx[194];
  xx[201] = xx[36] + xx[4] * xx[187];
  xx[218] = xx[36];
  xx[219] = xx[50];
  xx[220] = - xx[201];
  pm_math_Vector3_cross_ra(xx + 285, xx + 218, xx + 252);
  xx[36] = state[25] * state[25];
  xx[187] = xx[6] * xx[55] * state[27] * state[25];
  xx[55] = xx[9] * xx[187];
  xx[203] = xx[211] * state[27] * state[25];
  xx[208] = xx[9] * xx[203];
  xx[210] = xx[4] * xx[203] - xx[55];
  xx[218] = xx[55];
  xx[219] = - xx[208];
  xx[220] = xx[210];
  pm_math_Vector3_cross_ra(xx + 285, xx + 218, xx + 291);
  xx[218] = xx[26];
  xx[219] = xx[18] + xx[14] * xx[275];
  xx[220] = xx[27] - xx[14] * xx[272];
  pm_math_Quaternion_inverseXform_ra(xx + 423, xx + 218, xx + 285);
  xx[18] = (xx[14] * xx[4] * xx[4] + xx[14] * xx[9] * xx[9]) * xx[6];
  xx[14] = xx[56] - (xx[64] * xx[285] + xx[66] * xx[286] - xx[419] * xx[18]);
  xx[26] = xx[14] - xx[18];
  xx[18] = xx[286] + xx[59] * xx[14] + xx[80] + xx[51] * xx[26];
  xx[27] = xx[214] + xx[371] * xx[26] + xx[341] * (xx[18] - (xx[37] * (xx[285] +
    xx[417] - xx[49] * xx[26]) * xx[42] + xx[18] * xx[42] * xx[42]) * xx[6]);
  xx[18] = xx[6] * xx[77] * state[19] * state[19];
  xx[26] = xx[6] * xx[25] * state[25] * state[25];
  xx[218] = xx[30] * xx[385] - ((xx[193] * xx[17] + xx[89]) * xx[6] - xx[29] -
    (xx[249] * xx[15] + xx[260] * xx[16] + xx[200] * xx[32]) + xx[6] * (xx[6] *
    (xx[96] - xx[193] * xx[82]) - xx[33]) - xx[48] * (xx[555] * (xx[412] * xx
    [436] + xx[402] * xx[436]) * state[9] * state[11] + xx[16] * xx[224] + xx
    [247] * xx[15] + xx[198] * xx[34] + xx[70] * xx[202]) - ((xx[142] * xx[94] +
    xx[170]) * xx[6] - xx[106] - (xx[182] * xx[92] + xx[184] * xx[93] + xx[340] *
    xx[108]) + xx[6] * (xx[6] * (xx[216] - xx[142] * xx[150]) - xx[151]) - xx[48]
    * (xx[555] * (xx[570] * xx[465] + xx[565] * xx[465]) * state[15] * state[17]
       + xx[93] * xx[175] + xx[178] * xx[92] + xx[149] * xx[152] + xx[162] * xx
       [153])) + xx[433] * xx[28]) + xx[466] * xx[167] - xx[168] * xx[571];
  xx[219] = xx[30] * xx[391] - (xx[265] * xx[32] - (xx[249] * xx[16] + xx[260] *
    xx[132]) + (xx[90] - xx[193] * xx[31]) * xx[6] + (xx[97] - xx[193] * xx[91])
    * xx[555] - (xx[132] * xx[224] + xx[247] * xx[16] + xx[191] * xx[34] + xx
                 [198] * xx[70] + xx[555] * (xx[412] * xx[402] - xx[436] * xx
    [436]) * state[9] * state[11]) * xx[48] - (xx[343] * xx[108] - (xx[182] *
    xx[93] + xx[184] * xx[88]) + (xx[171] - xx[142] * xx[107]) * xx[6] + (xx[217]
    - xx[142] * xx[166]) * xx[555] - (xx[88] * xx[175] + xx[178] * xx[93] + xx
    [138] * xx[152] + xx[149] * xx[162] + xx[555] * (xx[570] * xx[565] - xx[465]
    * xx[465]) * state[15] * state[17]) * xx[48]) + xx[396] * xx[28]) + xx[562] *
    xx[167] - xx[168] * xx[554];
  xx[220] = xx[172] * xx[603] - (xx[48] * (xx[555] * (xx[602] * xx[547] + xx[590]
    * xx[547]) * state[19] * state[21] - (xx[95] * xx[98] + xx[124] * xx[75] +
    xx[72] * xx[111] + xx[116] * xx[76])) + (xx[67] * xx[136] + xx[222]) * xx[6]
    - xx[154] - (xx[126] * xx[75] + xx[137] * xx[95] + xx[74] * xx[68]) + xx[6] *
    (xx[6] * (xx[231] - xx[67] * xx[179]) - xx[143]) - (xx[48] * (xx[555] * (xx
    [358] * xx[546] + xx[347] * xx[546]) * state[25] * state[27] - (xx[125] *
    xx[39] + xx[43] * xx[23] + xx[20] * xx[174] + xx[185] * xx[24])) + (xx[4] *
    xx[50] + xx[253]) * xx[6] - xx[194] - (xx[49] * xx[23] + xx[51] * xx[125] +
    xx[267] * xx[36]) + xx[6] * (xx[6] * (xx[292] - xx[4] * xx[208]) - xx[187]))
    + xx[564] * xx[169]) + xx[279] * xx[14] - xx[27] * xx[361];
  xx[221] = xx[172] * xx[563] - (xx[327] * xx[68] - (xx[126] * xx[95] + xx[137] *
    xx[18]) + (xx[223] - xx[67] * xx[173]) * xx[6] + (xx[67] * xx[183] + xx[232])
    * xx[555] - (xx[18] * xx[98] + xx[124] * xx[95] + xx[65] * xx[111] + xx[72] *
                 xx[116] + xx[555] * (xx[602] * xx[590] - xx[547] * xx[547]) *
                 state[19] * state[21]) * xx[48] - (xx[274] * xx[36] - (xx[49] *
    xx[125] + xx[51] * xx[26]) + (xx[254] - xx[4] * xx[201]) * xx[6] + (xx[4] *
    xx[210] + xx[293]) * xx[555] - (xx[26] * xx[39] + xx[43] * xx[125] + xx[2] *
    xx[174] + xx[20] * xx[185] + xx[555] * (xx[358] * xx[347] - xx[546] * xx[546])
    * state[25] * state[27]) * xx[48]) + xx[583] * xx[169]) + xx[548] * xx[14] -
    xx[27] * xx[255];
  memcpy(xx + 437, xx + 625, 16 * sizeof(double));
  factorAndSolveSymmetric(xx + 437, 4, xx + 23, ii + 0, xx + 218, xx + 14, xx +
    467);
  xx[2] = (xx[160] + xx[361] * xx[16] + xx[17] * xx[255]) / xx[572];
  xx[18] = xx[209] - xx[83] * xx[2];
  xx[20] = xx[42] * xx[18];
  xx[23] = xx[206] - (xx[37] * xx[20] + xx[251]) * xx[6];
  xx[24] = xx[18] + xx[6] * (xx[393] - xx[20] * xx[42]);
  xx[18] = xx[667] + xx[545] - xx[159] * xx[2] + xx[51] * xx[24] - xx[49] * xx
    [23] + xx[85];
  xx[20] = xx[24] + xx[544];
  xx[24] = (xx[421] - (xx[18] + xx[20] * xx[59]) - (xx[279] * xx[16] + xx[17] *
             xx[548])) / xx[63];
  xx[25] = xx[23] + xx[53] + xx[60] * xx[24];
  xx[26] = xx[20] + xx[38] * xx[24];
  xx[27] = xx[46];
  pm_math_Quaternion_xform_ra(xx + 423, xx + 25, xx + 28);
  xx[20] = xx[22] / xx[290];
  xx[22] = xx[700] + xx[0] + xx[290] * xx[20] + xx[420] + xx[557];
  xx[0] = (xx[603] * xx[16] + xx[17] * xx[563] - (xx[22] + xx[109])) / xx[120];
  xx[23] = xx[266] + xx[114] * xx[0];
  xx[25] = xx[113] + xx[119] * xx[0];
  xx[26] = xx[25] * xx[123];
  xx[27] = xx[23] * xx[123];
  xx[31] = xx[23] - (xx[78] * xx[26] + xx[27] * xx[123]) * xx[6];
  xx[23] = xx[25] + xx[6] * (xx[78] * xx[27] - xx[26] * xx[123]);
  xx[25] = xx[694] + xx[22] + xx[118] * xx[0] + xx[23] * xx[137] - xx[126] * xx
    [31] + xx[52];
  xx[22] = xx[23] + xx[105];
  xx[23] = (xx[57] - (xx[25] + xx[22] * xx[59]) + xx[564] * xx[16] + xx[17] *
            xx[583]) / xx[134];
  xx[32] = xx[31] + xx[19] + xx[139] * xx[23];
  xx[33] = xx[22] + xx[133] * xx[23];
  xx[34] = xx[79];
  pm_math_Quaternion_xform_ra(xx + 621, xx + 32, xx + 55);
  xx[16] = (xx[271] + xx[571] * xx[14] + xx[15] * xx[554]) / xx[572];
  xx[17] = xx[147] - xx[83] * xx[16];
  xx[19] = xx[177] * xx[17];
  xx[22] = xx[314] - (xx[155] * xx[19] + xx[307]) * xx[6];
  xx[26] = xx[17] + xx[6] * (xx[101] - xx[19] * xx[177]);
  xx[17] = xx[619] + xx[646] - xx[159] * xx[16] + xx[184] * xx[26] - xx[182] *
    xx[22] + xx[102];
  xx[19] = xx[26] + xx[310];
  xx[26] = (xx[189] - (xx[17] + xx[19] * xx[59]) - (xx[466] * xx[14] + xx[15] *
             xx[562])) / xx[186];
  xx[31] = xx[22] + xx[45] + xx[190] * xx[26];
  xx[32] = xx[19] + xx[156] * xx[26];
  xx[33] = xx[41];
  pm_math_Quaternion_xform_ra(xx + 595, xx + 31, xx + 74);
  xx[19] = xx[273] / xx[290];
  xx[22] = xx[593] + xx[1] + xx[290] * xx[19] + xx[325] + xx[388];
  xx[1] = (xx[385] * xx[14] + xx[15] * xx[391] - (xx[22] + xx[233])) / xx[243];
  xx[27] = xx[212] + xx[238] * xx[1];
  xx[31] = xx[237] + xx[242] * xx[1];
  xx[32] = xx[31] * xx[246];
  xx[33] = xx[27] * xx[246];
  xx[34] = xx[27] - (xx[204] * xx[32] + xx[33] * xx[246]) * xx[6];
  xx[27] = xx[31] + xx[6] * (xx[204] * xx[33] - xx[32] * xx[246]);
  xx[31] = xx[649] + xx[22] + xx[241] * xx[1] + xx[27] * xx[260] - xx[249] * xx
    [34] + xx[47];
  xx[22] = xx[27] + xx[205];
  xx[27] = (xx[58] - (xx[31] + xx[22] * xx[59]) + xx[433] * xx[14] + xx[15] *
            xx[396]) / xx[257];
  xx[45] = xx[34] + xx[21] + xx[262] * xx[27];
  xx[46] = xx[22] + xx[256] * xx[27];
  xx[47] = xx[35];
  pm_math_Quaternion_xform_ra(xx + 585, xx + 45, xx + 32);
  xx[45] = xx[86];
  xx[46] = xx[164];
  xx[47] = xx[18] + xx[40] * xx[24];
  pm_math_Quaternion_xform_ra(xx + 423, xx + 45, xx + 38);
  pm_math_Vector3_cross_ra(xx + 276, xx + 28, xx + 39);
  xx[14] = xx[342] - xx[308] * xx[0];
  xx[15] = xx[373] + xx[316] * xx[0];
  xx[18] = xx[15] * xx[123];
  xx[21] = xx[123] * xx[14];
  xx[45] = xx[692] + xx[14] - (xx[78] * xx[18] + xx[21] * xx[123]) * xx[6] + xx
    [3] + xx[54] + xx[326] * xx[23];
  xx[46] = xx[693] + xx[15] + xx[6] * (xx[78] * xx[21] - xx[18] * xx[123]) - xx
    [122] + xx[127] + xx[319] * xx[23];
  xx[47] = xx[25] + xx[117] * xx[23];
  pm_math_Quaternion_xform_ra(xx + 621, xx + 45, xx + 52);
  pm_math_Vector3_cross_ra(xx + 335, xx + 55, xx + 45);
  xx[46] = xx[104];
  xx[47] = xx[131];
  xx[48] = xx[17] + xx[62] * xx[26];
  pm_math_Quaternion_xform_ra(xx + 595, xx + 46, xx + 88);
  pm_math_Vector3_cross_ra(xx + 364, xx + 74, xx + 46);
  xx[3] = xx[176] + xx[369] * xx[1];
  xx[14] = xx[181] - xx[394] * xx[1];
  xx[15] = xx[14] * xx[246];
  xx[17] = xx[246] * xx[3];
  xx[89] = xx[647] + xx[3] - (xx[204] * xx[15] + xx[17] * xx[246]) * xx[6] + xx
    [100] + xx[140] + xx[404] * xx[27];
  xx[90] = xx[648] + xx[14] + xx[6] * (xx[204] * xx[17] - xx[15] * xx[246]) -
    xx[227] + xx[229] + xx[397] * xx[27];
  xx[91] = xx[31] + xx[240] * xx[27];
  pm_math_Quaternion_xform_ra(xx + 585, xx + 89, xx + 92);
  pm_math_Vector3_cross_ra(xx + 413, xx + 32, xx + 89);
  xx[3] = xx[29] + xx[56] + xx[75] + xx[33] + xx[73];
  xx[14] = (xx[38] + xx[39] + xx[52] + xx[45] + xx[88] + xx[46] + xx[92] + xx[89]
            + xx[61] + xx[3] * xx[81]) / xx[161];
  xx[38] = xx[28] + xx[55] + xx[74] + xx[32] + xx[110] - xx[158] * xx[14];
  xx[39] = xx[3] - xx[84] * xx[14];
  xx[40] = xx[30] + xx[57] + xx[76] + xx[34] + xx[148] - xx[87] * xx[14];
  pm_math_Quaternion_xform_ra(xx + 281, xx + 38, xx + 28);
  xx[31] = - xx[28];
  xx[32] = - xx[29];
  xx[33] = - xx[30];
  solveSymmetricPosDef(xx + 531, xx + 31, 3, 1, xx + 28, xx + 34);
  xx[3] = xx[28] + xx[11];
  xx[11] = xx[29] + xx[12];
  xx[12] = xx[30] + xx[13];
  xx[28] = xx[3] - xx[99];
  xx[29] = xx[11];
  xx[30] = xx[12] - xx[10];
  pm_math_Quaternion_inverseXform_ra(xx + 281, xx + 28, xx + 31);
  xx[10] = xx[14] + pm_math_Vector3_dot_ra(xx + 579, xx + 31);
  xx[13] = xx[10] * xx[193];
  xx[14] = xx[10] * xx[195];
  xx[15] = (xx[13] * xx[193] + xx[14] * xx[195]) * xx[6];
  xx[17] = xx[15] - xx[10];
  xx[18] = xx[6] * (xx[14] * xx[193] - xx[13] * xx[195]);
  xx[28] = xx[17];
  xx[29] = xx[18];
  xx[30] = - xx[15];
  xx[13] = xx[32] - xx[10] * xx[81];
  xx[14] = xx[33] + xx[7];
  xx[32] = xx[31];
  xx[33] = xx[13] + xx[10] * xx[405];
  xx[34] = xx[14] - xx[10] * xx[197];
  pm_math_Quaternion_inverseXform_ra(xx + 585, xx + 32, xx + 38);
  xx[7] = xx[27] - (pm_math_Vector3_dot_ra(xx + 549, xx + 28) + xx[258] * xx[38]
                    + xx[264] * xx[39]);
  xx[21] = xx[17] + xx[180];
  xx[17] = xx[18] - xx[207];
  xx[18] = xx[246] * xx[17];
  xx[22] = xx[21] * xx[246];
  xx[25] = xx[7] - xx[15];
  xx[27] = xx[21] + xx[6] * (xx[204] * xx[18] - xx[22] * xx[246]);
  xx[28] = xx[17] - (xx[204] * xx[22] + xx[18] * xx[246]) * xx[6];
  xx[29] = xx[25];
  xx[15] = xx[38] + xx[268] - xx[249] * xx[25];
  xx[17] = xx[39] + xx[59] * xx[7] + xx[44] + xx[260] * xx[25];
  xx[18] = xx[17] * xx[246];
  xx[21] = xx[15] * xx[246];
  xx[22] = xx[1] - (pm_math_Vector3_dot_ra(xx + 574, xx + 27) + (xx[15] + xx[6] *
    (xx[204] * xx[18] - xx[21] * xx[246])) * xx[244] + xx[236] * (xx[17] - (xx
    [204] * xx[21] + xx[18] * xx[246]) * xx[6]));
  xx[1] = xx[25] + xx[22];
  xx[27] = xx[31];
  xx[28] = xx[13] + xx[10] * xx[344];
  xx[29] = xx[14] - xx[10] * xx[196];
  pm_math_Quaternion_inverseXform_ra(xx + 595, xx + 27, xx + 32);
  xx[15] = xx[10] * xx[142];
  xx[17] = xx[10] * xx[144];
  xx[18] = (xx[15] * xx[142] + xx[17] * xx[144]) * xx[6];
  xx[21] = xx[26] - (xx[188] * xx[32] + xx[192] * xx[33] - xx[129] * xx[18]);
  xx[25] = xx[21] - xx[18];
  xx[26] = xx[33] + xx[59] * xx[21] + xx[8] + xx[184] * xx[25];
  xx[8] = xx[16] + xx[371] * xx[25] + xx[341] * (xx[26] - (xx[155] * (xx[32] +
    xx[103] - xx[182] * xx[25]) * xx[177] + xx[26] * xx[177] * xx[177]) * xx[6]);
  xx[16] = xx[10] * xx[67];
  xx[26] = xx[10] * xx[69];
  xx[27] = (xx[16] * xx[67] + xx[26] * xx[69]) * xx[6];
  xx[28] = xx[27] - xx[10];
  xx[29] = xx[6] * (xx[26] * xx[67] - xx[16] * xx[69]);
  xx[32] = xx[28];
  xx[33] = xx[29];
  xx[34] = - xx[27];
  xx[38] = xx[31];
  xx[39] = xx[13] + xx[10] * xx[328];
  xx[40] = xx[14] - xx[10] * xx[71];
  pm_math_Quaternion_inverseXform_ra(xx + 621, xx + 38, xx + 43);
  xx[16] = xx[23] - (pm_math_Vector3_dot_ra(xx + 608, xx + 32) + xx[135] * xx[43]
                     + xx[141] * xx[44]);
  xx[23] = xx[28] + xx[145];
  xx[26] = xx[29] - xx[261];
  xx[28] = xx[123] * xx[26];
  xx[29] = xx[23] * xx[123];
  xx[30] = xx[16] - xx[27];
  xx[32] = xx[23] + xx[6] * (xx[78] * xx[28] - xx[29] * xx[123]);
  xx[33] = xx[26] - (xx[78] * xx[29] + xx[28] * xx[123]) * xx[6];
  xx[34] = xx[30];
  xx[23] = xx[43] + xx[315] - xx[126] * xx[30];
  xx[26] = xx[44] + xx[59] * xx[16] + xx[5] + xx[137] * xx[30];
  xx[5] = xx[26] * xx[123];
  xx[27] = xx[23] * xx[123];
  xx[28] = xx[0] - (pm_math_Vector3_dot_ra(xx + 611, xx + 32) + (xx[23] + xx[6] *
    (xx[78] * xx[5] - xx[27] * xx[123])) * xx[121] + xx[112] * (xx[26] - (xx[78]
    * xx[27] + xx[5] * xx[123]) * xx[6]));
  xx[0] = xx[30] + xx[28];
  xx[32] = xx[31];
  xx[33] = xx[13] + xx[10] * xx[275];
  xx[34] = xx[14] - xx[10] * xx[272];
  pm_math_Quaternion_inverseXform_ra(xx + 423, xx + 32, xx + 29);
  xx[5] = xx[10] * xx[4];
  xx[13] = xx[10] * xx[9];
  xx[14] = (xx[5] * xx[4] + xx[13] * xx[9]) * xx[6];
  xx[23] = xx[24] - (xx[64] * xx[29] + xx[66] * xx[30] - xx[419] * xx[14]);
  xx[24] = xx[23] - xx[14];
  xx[26] = xx[30] + xx[59] * xx[23] + xx[80] + xx[51] * xx[24];
  xx[27] = xx[2] + xx[371] * xx[24] + xx[341] * (xx[26] - (xx[37] * (xx[29] +
    xx[417] - xx[49] * xx[24]) * xx[42] + xx[26] * xx[42] * xx[42]) * xx[6]);
  xx[29] = xx[465];
  xx[30] = xx[570];
  xx[31] = xx[465];
  xx[32] = xx[565];
  xx[33] = xx[436];
  xx[34] = xx[412];
  xx[35] = xx[436];
  xx[36] = xx[402];
  pm_math_Quaternion_inverseCompose_ra(xx + 29, xx + 33, xx + 38);
  xx[2] = xx[18] - xx[10] + xx[130];
  xx[18] = xx[6] * (xx[17] * xx[142] - xx[15] * xx[144]) - xx[115];
  xx[15] = xx[177] * xx[18];
  xx[17] = xx[2] * xx[177];
  xx[29] = xx[2] + xx[6] * (xx[155] * xx[15] - xx[17] * xx[177]) + xx[128];
  xx[30] = xx[18] - (xx[155] * xx[17] + xx[15] * xx[177]) * xx[6] - xx[146];
  xx[31] = xx[25] - xx[8];
  pm_math_Quaternion_inverseXform_ra(xx + 38, xx + 29, xx + 32);
  xx[29] = xx[546];
  xx[30] = - xx[358];
  xx[31] = xx[546];
  xx[32] = - xx[347];
  xx[38] = xx[547];
  xx[39] = - xx[602];
  xx[40] = xx[547];
  xx[41] = - xx[590];
  pm_math_Quaternion_inverseCompose_ra(xx + 29, xx + 38, xx + 43);
  xx[2] = xx[14] - xx[10] + xx[199];
  xx[14] = xx[6] * (xx[13] * xx[4] - xx[5] * xx[9]) - xx[157];
  xx[4] = xx[42] * xx[14];
  xx[5] = xx[2] * xx[42];
  xx[29] = xx[2] + xx[6] * (xx[37] * xx[4] - xx[5] * xx[42]) + xx[163];
  xx[30] = xx[14] - (xx[37] * xx[5] + xx[4] * xx[42]) * xx[6] - xx[165];
  xx[31] = xx[24] - xx[27];
  pm_math_Quaternion_inverseXform_ra(xx + 43, xx + 29, xx + 4);
  deriv[0] = state[3];
  deriv[1] = state[4];
  deriv[2] = state[5];
  deriv[3] = xx[3];
  deriv[4] = xx[11];
  deriv[5] = xx[12];
  deriv[6] = state[7];
  deriv[7] = - xx[10];
  deriv[8] = state[9];
  deriv[9] = xx[7];
  deriv[10] = state[11];
  deriv[11] = xx[22];
  deriv[12] = state[13];
  deriv[13] = xx[19] - xx[1];
  deriv[14] = state[15];
  deriv[15] = xx[21];
  deriv[16] = state[17];
  deriv[17] = - xx[8];
  deriv[18] = state[19];
  deriv[19] = xx[16];
  deriv[20] = state[21];
  deriv[21] = xx[28];
  deriv[22] = state[23];
  deriv[23] = xx[20] - xx[0];
  deriv[24] = state[25];
  deriv[25] = xx[23];
  deriv[26] = state[27];
  deriv[27] = - xx[27];
  deriv[28] = state[29];
  deriv[29] = xx[1] - xx[34];
  deriv[30] = state[31];
  deriv[31] = xx[0] - xx[6];
  errorResult[0] = xx[306];
  return NULL;
}

PmfMessageId blance_leg_1d80934b_1_numJacPerturbLoBounds(const
  RuntimeDerivedValuesBundle *rtdv, const int *eqnEnableFlags, const double
  *state, const int *modeVector, const double *input, const double *inputDot,
  const double *inputDdot, const double *discreteState, double *bounds, double
  *errorResult, NeuDiagnosticManager *neDiagMgr)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  double xx[2];
  (void) rtdvd;
  (void) rtdvi;
  (void) eqnEnableFlags;
  (void) state;
  (void) modeVector;
  (void) input;
  (void) inputDot;
  (void) inputDdot;
  (void) discreteState;
  (void) neDiagMgr;
  xx[0] = 1.0e-9;
  xx[1] = 1.0e-8;
  bounds[0] = xx[0];
  bounds[1] = xx[0];
  bounds[2] = xx[0];
  bounds[3] = xx[0];
  bounds[4] = xx[0];
  bounds[5] = xx[0];
  bounds[6] = xx[1];
  bounds[7] = xx[1];
  bounds[8] = xx[1];
  bounds[9] = xx[1];
  bounds[10] = xx[1];
  bounds[11] = xx[1];
  bounds[12] = xx[1];
  bounds[13] = xx[1];
  bounds[14] = xx[1];
  bounds[15] = xx[1];
  bounds[16] = xx[1];
  bounds[17] = xx[1];
  bounds[18] = xx[1];
  bounds[19] = xx[1];
  bounds[20] = xx[1];
  bounds[21] = xx[1];
  bounds[22] = xx[1];
  bounds[23] = xx[1];
  bounds[24] = xx[1];
  bounds[25] = xx[1];
  bounds[26] = xx[1];
  bounds[27] = xx[1];
  bounds[28] = xx[1];
  bounds[29] = xx[1];
  bounds[30] = xx[1];
  bounds[31] = xx[1];
  errorResult[0] = 0.0;
  return NULL;
}

PmfMessageId blance_leg_1d80934b_1_numJacPerturbHiBounds(const
  RuntimeDerivedValuesBundle *rtdv, const int *eqnEnableFlags, const double
  *state, const int *modeVector, const double *input, const double *inputDot,
  const double *inputDdot, const double *discreteState, double *bounds, double
  *errorResult, NeuDiagnosticManager *neDiagMgr)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  double xx[2];
  (void) rtdvd;
  (void) rtdvi;
  (void) eqnEnableFlags;
  (void) state;
  (void) modeVector;
  (void) input;
  (void) inputDot;
  (void) inputDdot;
  (void) discreteState;
  (void) neDiagMgr;
  xx[0] = +pmf_get_inf();
  xx[1] = 1.0;
  bounds[0] = xx[0];
  bounds[1] = xx[0];
  bounds[2] = xx[0];
  bounds[3] = xx[0];
  bounds[4] = xx[0];
  bounds[5] = xx[0];
  bounds[6] = xx[1];
  bounds[7] = xx[0];
  bounds[8] = xx[1];
  bounds[9] = xx[0];
  bounds[10] = xx[1];
  bounds[11] = xx[0];
  bounds[12] = xx[1];
  bounds[13] = xx[0];
  bounds[14] = xx[1];
  bounds[15] = xx[0];
  bounds[16] = xx[1];
  bounds[17] = xx[0];
  bounds[18] = xx[1];
  bounds[19] = xx[0];
  bounds[20] = xx[1];
  bounds[21] = xx[0];
  bounds[22] = xx[1];
  bounds[23] = xx[0];
  bounds[24] = xx[1];
  bounds[25] = xx[0];
  bounds[26] = xx[1];
  bounds[27] = xx[0];
  bounds[28] = xx[1];
  bounds[29] = xx[0];
  bounds[30] = xx[1];
  bounds[31] = xx[0];
  errorResult[0] = 0.0;
  return NULL;
}
